﻿    using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;

namespace Factory_Equipment_Management.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly HomeRepository _homeRepository;
        private readonly YourDbContext _context;

        public HomeController(HomeRepository homeRepository, YourDbContext context)
        {
            _homeRepository = homeRepository;
            _context = context;
        }

        public IActionResult Index(string status = "Tất cả")
        {
            var requests = _homeRepository.GetRequestsByStatus(status);

            // Lấy danh sách cho filter
            //ViewBag.Categories = _context.Categories.Select(c => c.name).Distinct().ToList();
            //ViewBag.Warehouses = _context.Warehouses.Select(w => w.name).Distinct().ToList();
            //ViewBag.Areas = _context.Areas.Select(a => a.name).Distinct().ToList();

            ViewBag.Categories = _context.Categories
    .Select(c => c.name == null ? "" : c.name)
    .Distinct()
    .ToList();
            ViewBag.Warehouses = _context.Warehouses
    .Select(w => w.name ?? "")
    .Distinct()
    .ToList();

            ViewBag.Areas = _context.Areas
                .Select(a => a.name ?? "")
                .Distinct()
                .ToList();


            //        ViewBag.Categories = _context.Categories
            //.Select(c => c.name == null ? "" : c.name)
            //.Distinct()
            //.ToList();
            //        ViewBag.Warehouses = _context.Warehouses
            //.Select(w => w.name ?? "")
            //.Distinct()
            //.ToList();

            //        ViewBag.Areas = _context.Areas
            //            .Select(a => a.name ?? "")
            //            .Distinct()
            //            .ToList();

            ViewBag.CurrentStatus = status;
            return View("~/Views/Admin/AdminHome.cshtml", requests);
        }

        // code chức năng transferRequest
        public IActionResult TransferRequests(int? id, int? idPic, string status, int page = 1, int pageSize = 10)
        {
            int totalCount;
            var transferRequests = _homeRepository.GetAllTransferRequests(id, idPic, status, page, pageSize, out totalCount);

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalCount = totalCount;
            ViewBag.CurrentId = id?.ToString() ?? "";
            ViewBag.CurrentPic = idPic?.ToString() ?? "";
            ViewBag.CurrentStatus = status ?? "";

            return View("~/Views/Admin/TransferRequests.cshtml", transferRequests);
        }
        [HttpPost]
        public IActionResult ApproveTransferRequest(int id)
        {
            int currentUserId = int.Parse(User.FindFirst("UserId")?.Value ?? "0");
            string currentUserRole = User.FindFirst(ClaimTypes.Role)?.Value ?? "";
            try
            {
                var result = _homeRepository.ApproveTransferRequest(id, currentUserId, currentUserRole);
                return result ? Ok() : BadRequest("Không thể duyệt đơn.");
            }
            catch (Exception ex)
            {
                // Trả về thông báo lỗi cho client
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult RejectTransferRequest(int id)
        {
            int currentUserId = int.Parse(User.FindFirst("UserId")?.Value ?? "0");
            string currentUserRole = User.FindFirst(ClaimTypes.Role)?.Value ?? "";
            try
            {
                var result = _homeRepository.RejectTransferRequest(id, currentUserId, currentUserRole);
                return result ? Ok() : BadRequest();
            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet]
        public IActionResult GetAreasByWarehouse(string warehouseName)
        {
            var areas = _homeRepository.GetAreasByWarehouseName(warehouseName)
                .Select(a => new { a.idArea, a.name })
                .ToList();
            return Json(areas);
        }
    }
}