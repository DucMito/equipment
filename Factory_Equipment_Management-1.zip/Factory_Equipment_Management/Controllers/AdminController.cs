﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Factory_Equipment_Management.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly HomeRepository _adminHomeRepository;
        private readonly YourDbContext _context;
        private readonly AdminRepository _adminRepository;

        public AdminController(HomeRepository adminHomeRepository, YourDbContext context, AdminRepository adminRepository)
        {
            _adminHomeRepository = adminHomeRepository;
            _context = context;
            _adminRepository = adminRepository;
        }


        public IActionResult AccountAdmin()
        {
            var staffs = _adminRepository.GetAllStaff();
            return View(staffs); 
        }
        //staff
        public IActionResult GetStaffAccounts() => Json(_adminRepository.GetAllStaff());

        [HttpPost]
        public IActionResult AddStaff(Staff staff)
        {
            var error = _adminRepository.AddStaff(staff);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult UpdateStaff([FromBody] Staff staff)
        {
            var error = _adminRepository.UpdateStaff(staff);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult DeleteStaff(int id)
        {
            _adminRepository.DeleteStaff(id);
            return Ok();
        }




        //pic
        public IActionResult GetPicAccounts() => Json(_adminRepository.GetAllPICs());

        [HttpPost]
        public IActionResult AddPic(PIC pic)
        {
            var error = _adminRepository.AddPic(pic);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult UpdatePic([FromBody] PIC pic)
        {
            var error = _adminRepository.UpdatePic(pic);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult DeletePic(int id)
        {
            _adminRepository.DeletePic(id);
            return Ok();
        }





        //manager
        public IActionResult GetManagerAccounts() => Json(_adminRepository.GetAllManagers());

        [HttpPost]
        public IActionResult AddManager(Manager manager)
        {
            var error = _adminRepository.AddManager(manager);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult UpdateManager(Manager manager)
        {
            var error = _adminRepository.UpdateManager(manager);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult DeleteManager(int id)
        {
            _adminRepository.DeleteManager(id);
            return Ok();
        }

        [HttpGet]
        public IActionResult GetWarehousesWithAreas()
        {
            var data = _context.Warehouses
                .Select(w => new
                {
                    w.idWarehouse,
                    w.name,
                    w.idPIC,
                    areas = _context.Areas
                        .Where(a => a.idWarehouse == w.idWarehouse)
                        .Select(a => new { a.idArea, a.name })
                        .ToList()
                })
                .ToList();

            return Json(data);
        }

        [HttpPost]
        public IActionResult AddWarehouse([FromBody] Warehouse warehouse)
        {
            var error = _adminRepository.AddWarehouse(warehouse);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult UpdateWarehouse([FromBody] Warehouse warehouse)
        {
            var error = _adminRepository.UpdateWarehouse(warehouse);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult DeleteWarehouse(int id)
        {
            _adminRepository.DeleteWarehouse(id);
            return Ok();
        }

        [HttpPost]
        public IActionResult AddArea([FromBody] Area area)
        {
            var error = _adminRepository.AddArea(area);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult UpdateArea([FromBody] Area area)
        {
            var error = _adminRepository.UpdateArea(area);
            if (error != null) return BadRequest(error);
            return Ok();
        }

        [HttpPost]
        public IActionResult DeleteArea(int id)
        {
            _adminRepository.DeleteArea(id);
            return Ok();
        }


    }
}