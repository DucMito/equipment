﻿using System.Collections.Generic;

namespace Factory_Equipment_Management.ViewModel
{
    public class TransferRequestInputModel
    {
        public List<int> ItemIds { get; set; }
        public string Reason { get; set; }
        public string Warehouse { get; set; }
        public string Area { get; set; }
        public string FromArea { get; set; }
        public string Sender { get; set; }
        public string SenderType { get; set; }

        public string receiverType { get; set; }
    }
}