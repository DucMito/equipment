﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Factory_Equipment_Management.Models;

namespace Factory_Equipment_Management.Service
{
    public class MaintanceAlertService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;

        public MaintanceAlertService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                using (var scope = _serviceProvider.CreateScope())
                {
                    var db = scope.ServiceProvider.GetRequiredService<YourDbContext>();

                    // Lấy danh sách email manager (admin == false)
                    var managerEmails = await db.Managers
                        .Where(m => m.admin == false && !string.IsNullOrEmpty(m.email))
                        .Select(m => m.email)
                        .ToListAsync();

                    // Lấy danh sách email admin (admin == true)
                    var adminEmails = await db.Managers
                        .Where(m => m.admin == true && !string.IsNullOrEmpty(m.email))
                        .Select(m => m.email)
                        .ToListAsync();

                    // Join để lấy thông tin PIC phụ trách từng thiết bị và lấy alert từ Category
                    var items = await (from item in db.Items
                                       join area in db.Areas on item.idArea equals area.idArea
                                       join warehouse in db.Warehouses on area.idWarehouse equals warehouse.idWarehouse
                                       join pic in db.PICs on warehouse.idPIC equals pic.idPIC into picJoin
                                       from pic in picJoin.DefaultIfEmpty()
                                       join category in db.Categories on item.idCategory equals category.idCategory
                                       select new
                                       {
                                           ItemName = item.status,
                                           item.maintanceDate,
                                           AlertMaintance = category.alertMaintance, // kiểu double?
                                           item.renewDate,
                                           AlertRenew = category.alertRenew,         // kiểu double?
                                           PICEmail = pic != null ? pic.email : null,
                                           PICName = pic != null ? pic.name : null
                                       }).ToListAsync();

                    foreach (var item in items)
                    {
                        var recipients = new List<string>();
                        if (!string.IsNullOrEmpty(item.PICEmail))
                            recipients.Add(item.PICEmail);
                        recipients.AddRange(managerEmails);
                        recipients.AddRange(adminEmails);

                        // Gửi cảnh báo bảo dưỡng
                        if (item.maintanceDate != null && item.AlertMaintance != null)
                        {
                            var alert = (DateTime.Now - item.maintanceDate.Value).Days / 30.0;
                            if (item.AlertMaintance - alert < 2)
                            {
                                await SendEmailAsync(
                                    recipients,
                                    "Cảnh báo bảo dưỡng thiết bị",
                                    $"Thiết bị \"{item.ItemName}\" sắp đến kỳ bảo dưỡng tiếp theo. Vui lòng kiểm tra và lên kế hoạch bảo dưỡng."
                                );
                            }
                        }

                        // Gửi cảnh báo bảo hành (nếu có)
                        if (item.renewDate != null && item.AlertRenew != null)
                        {
                            var renewAlert = (DateTime.Now - item.renewDate.Value).Days / 30.0;
                            if (item.AlertRenew - renewAlert < 2)
                            {
                                await SendEmailAsync(
                                    recipients,
                                    "Cảnh báo bảo hành thiết bị",
                                    $"Thiết bị \"{item.ItemName}\" sắp đến kỳ bảo hành tiếp theo. Vui lòng kiểm tra và gia hạn nếu cần."
                                );
                            }
                        }
                    }
                }
                await Task.Delay(TimeSpan.FromHours(24), stoppingToken);
            }
        }

        private async Task SendEmailAsync(IEnumerable<string> recipients, string subject, string body)
        {
            // TODO: Thực hiện gửi email ở đây
            await Task.CompletedTask;
        }
    }
}