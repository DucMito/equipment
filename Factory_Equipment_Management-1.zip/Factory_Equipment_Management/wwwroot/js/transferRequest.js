﻿document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.approve-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = btn.getAttribute('data-id');
            fetch(`/Home/ApproveTransferRequest/${id}`, { method: 'POST' })
                .then(async res => {
                    if (res.ok) {
                        location.reload();
                    } else {
                        const msg = await res.text();
                        alert(msg || 'Lỗi xử lý!');
                    }
                });
        });
    });
    document.querySelectorAll('.reject-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = btn.getAttribute('data-id');
            fetch(`/Home/RejectTransferRequest/${id}`, { method: 'POST' })
                .then(async res => {
                    if (res.ok) {
                        location.reload();
                    } else {
                        const msg = await res.text();
                        alert(msg || 'Lỗi xử lý!');
                    }
                });
        });
    });

    function loadDevices(warehouse, area, page = 1, pageSize = 10) {
        fetch(`/ItemTransferRequestArea/GetDevices?warehouse=${encodeURIComponent(warehouse)}&area=${encodeURIComponent(area)}&page=${page}&pageSize=${pageSize}`)
            .then(res => res.json())
            .then(data => {
                const tbody = document.querySelector('.transfer-table tbody');
                tbody.innerHTML = '';
                data.items.forEach(item => {
                    tbody.innerHTML += `
                        <tr>
                            <td>${item.id}</td>
                            <td>${item.deviceType}</td>
                            <td><img src="${item.imageUrl}" style="max-width:60px;"/></td>
                            <td>${item.status || ''}</td>
                            <td>${item.activedDate || ''}</td>
                            <td><input type="checkbox" value="${item.id}"/></td>
                        </tr>
                    `;
                });
            });
    }

    // Gọi khi trang tải lần đầu
    loadDevices(window.selectedWarehouse, '');

    // Gọi lại khi chọn kho/khu vực
    document.querySelectorAll('.warehouse-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const warehouse = btn.getAttribute('data-warehouse');
            loadDevices(warehouse, '');
        });
    });
    document.querySelectorAll('.area-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const area = btn.getAttribute('data-area');
            loadDevices(window.selectedWarehouse, area);
        });
    });
});