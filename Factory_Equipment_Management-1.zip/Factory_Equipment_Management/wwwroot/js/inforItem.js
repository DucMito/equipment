﻿document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('addRealCategorySelect').addEventListener('change', function () {
        const otherInput = document.getElementById('addRealCategoryOther');
        if (this.value === 'other') {
            otherInput.style.display = 'block';
        } else {
            otherInput.style.display = 'none';
            otherInput.value = '';
        }
    });

    async function loadAddRealCategories() {
        const res = await fetch('/InforItem/GetAllRealCategories');
        const categories = await res.json();
        const select = document.getElementById('addRealCategorySelect');
        select.innerHTML = '';

        categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.idRealCategory;
            opt.textContent = cat.name;
            select.appendChild(opt);
        });

        // Thêm option Other
        const otherOpt = document.createElement('option');
        otherOpt.value = 'other';
        otherOpt.textContent = 'Other...';
        select.appendChild(otherOpt);
    }
    loadAddRealCategories();

    // --- ADD ITEM
    document.getElementById('addItemForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        const realCategorySelect = document.getElementById('addRealCategorySelect');
        if (realCategorySelect.value === 'other') {
            formData.set('idRealCategory', '');
            formData.set('NewRealCategory', document.getElementById('addRealCategoryOther').value);
        } else {
            formData.set('idRealCategory', realCategorySelect.value);
            formData.set('NewRealCategory', '');
        }

        fetch('/InforItem/Add', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message || 'Thêm thành công!');
                location.reload();
            })
            .catch(() => alert('Không thể kết nối server!'));
    });

    document.getElementById('addCategoryBtn').addEventListener('click', function () {
        document.getElementById('addPopup').style.display = 'flex';
    });
    document.getElementById('closeAddPopup').addEventListener('click', function () {
        document.getElementById('addPopup').style.display = 'none';
    });


    $(document).ready(function () {
        $('#searchModelSelect').select2({
            placeholder: 'Chọn hoặc tìm model...',
            ajax: {
                url: '/InforItem/GetDeviceNames',
                dataType: 'json',
                delay: 250,
                data: function (params) {
                    return { term: params.term || '' };
                },
                processResults: function (data) {
                    return {
                        results: data.map(function (name) {
                            return { id: name, text: name };
                        })
                    };
                },
                cache: true
            },
            minimumInputLength: 0
        });
        document.getElementById('resetSearchBtn')?.addEventListener('click', function () {
            // Reset Select2
            if (window.$ && $('#searchModelSelect').length) {
                $('#searchModelSelect').val(null).trigger('change');
            }
            // Reset các input còn lại
            document.getElementById('searchMaintanceCycle').value = '';
            document.getElementById('searchDuration').value = '';
            document.getElementById('searchAlertMaintance').value = '';
            document.getElementById('searchAlertRenew').value = '';
            // Không đóng popup, chỉ xóa dữ liệu
        });

        document.getElementById('resetFilterBtn')?.addEventListener('click', function () {
            window.location.href = '/InforItem';
        });

        document.getElementById('searchCategoryBtn')?.addEventListener('click', function () {
            document.getElementById('searchCategoryPopup').style.display = 'flex';
            setTimeout(function () {
                $('#searchModelSelect').select2('open');
            }, 200);
        });

        $('#searchModelSelect').on('select2:open', function () {
            if (!$('.select2-results__option').length) {
                $('.select2-search__field').trigger('input');
            }
        });
    });

    document.getElementById('searchCategoryForm')?.addEventListener('submit', function (e) {
        e.preventDefault();
        const params = new URLSearchParams();
        const nameCategory = $('#searchModelSelect').val();
        const maintanceCycle = document.getElementById('searchMaintanceCycle').value;
        const duration = document.getElementById('searchDuration').value;
        const alertMaintance = document.getElementById('searchAlertMaintance').value;
        const alertRenew = document.getElementById('searchAlertRenew').value;

        if (nameCategory) params.append('name', nameCategory);
        if (maintanceCycle) params.append('maintanceCycle', maintanceCycle);
        if (duration) params.append('duration', duration);
        if (alertMaintance) params.append('alertMaintance', alertMaintance);
        if (alertRenew) params.append('alertRenew', alertRenew);

        window.location.href = '/InforItem?' + params.toString();
    });

    document.getElementById('searchCategoryBtn')?.addEventListener('click', function () {
        document.getElementById('searchCategoryPopup').style.display = 'flex';
    });
    document.getElementById('closeSearchCategoryPopup')?.addEventListener('click', function () {
        document.getElementById('searchCategoryPopup').style.display = 'none';
    });

    // update
    document.querySelectorAll('.update-button').forEach(btn => {
        btn.addEventListener('click', function () {
            // Đổ dữ liệu từ data-* vào form update (chỉ các trường Category/RealCategory)
            document.getElementById('updateIdCategory').value = btn.getAttribute('data-idcategory') || '';
            document.getElementById('updateModelName').value = btn.getAttribute('data-name') || '';
            document.getElementById('updateMaintanceCycle').value = btn.getAttribute('data-maintancecycle') || '';
            document.getElementById('updateDuration').value = btn.getAttribute('data-duration') || '';
            document.getElementById('updateAlertMaintance').value = btn.getAttribute('data-alertmaintance') || '';
            document.getElementById('updateAlertRenew').value = btn.getAttribute('data-alertrenew') || '';

            // Load real category select
            fetch('/InforItem/GetAllRealCategories')
                .then(res => res.json())
                .then(categories => {
                    const select = document.getElementById('updateRealCategorySelect');
                    select.innerHTML = '';
                    categories.forEach(cat => {
                        const opt = document.createElement('option');
                        opt.value = cat.idRealCategory;
                        opt.textContent = cat.name;
                        select.appendChild(opt);
                    });
                    // Thêm option Other
                    const otherOpt = document.createElement('option');
                    otherOpt.value = 'other';
                    otherOpt.textContent = 'Other...';
                    select.appendChild(otherOpt);

                    // Set selected value
                    select.value = btn.getAttribute('data-idrealcategory') || '';
                });

            document.getElementById('updateRealCategoryOther').style.display = 'none';
            document.getElementById('updateRealCategoryOther').value = '';

            document.getElementById('updatePopup').style.display = 'flex';
        });
    });

    // Xử lý submit form cập nhật (chỉ gửi các trường Category/RealCategory)
    document.getElementById('updateForm')?.addEventListener('submit', function (e) {
        e.preventDefault();
        const form = this;
        const formData = new FormData(form);

        // Xử lý realCategory: nếu chọn "other" thì lấy giá trị nhập mới
        const realCategorySelect = document.getElementById('updateRealCategorySelect');
        if (realCategorySelect.value === 'other') {
            formData.set('idRealCategory', '');
            formData.set('NewRealCategory', document.getElementById('updateRealCategoryOther').value);
        } else {
            formData.set('idRealCategory', realCategorySelect.value);
            formData.set('NewRealCategory', '');
        }

        fetch('/InforItem/Update', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message || 'Cập nhật thành công!');
                location.reload();
            })
            .catch(() => alert('Không thể kết nối server!'));
    });


    document.getElementById('closePopup')?.addEventListener('click', function () {
        document.getElementById('updatePopup').style.display = 'none';
    });
});