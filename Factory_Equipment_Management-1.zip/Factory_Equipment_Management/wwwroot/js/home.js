﻿
document.querySelectorAll('.filter-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
        document.querySelectorAll('.filter-btn').forEach(function (b) {
            b.classList.remove('active');
        });
        btn.classList.add('active');

        var status = btn.getAttribute('data-status');
        window.location.href = '/Home/Index?status=' + encodeURIComponent(status);
    });
});

document.addEventListener('DOMContentLoaded', function () {
    var warehouseSelect = document.getElementById('filterWarehouse');
    var areaSelect = document.getElementById('filterArea');
    if (warehouseSelect && areaSelect) {
        warehouseSelect.addEventListener('change', function () {
            var warehouseName = this.value;
            areaSelect.innerHTML = '<option value="">-- Khu vực --</option>';
            if (!warehouseName) return;
            fetch('/Home/GetAreasByWarehouse?warehouseName=' + encodeURIComponent(warehouseName))
                .then(res => res.json())
                .then(areas => {
                    areas.forEach(function (area) {
                        var opt = document.createElement('option');
                        opt.value = area.name;
                        opt.textContent = area.name;
                        areaSelect.appendChild(opt);
                    });
                });
        });
    }
});

