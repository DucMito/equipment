﻿namespace Factory_Equipment_Management.Models
{
    public class TranferRequest
    {
        public int? idTranferRequest { get; set; }
        public int? PIC_request { get; set; }
        public string status { get; set; }
        public string reason { get; set; }
        public DateTime date { get; set; }
        public int? fromArea { get; set; }      // <-- nullable
        public int? toArea { get; set; }        // <-- nullable
        public DateTime? date_answer { get; set; } // <-- nullable


        public string? createdByRole { get; set; }
        public int? createdById { get; set; }

        public TranferRequest() { }



    }
}
