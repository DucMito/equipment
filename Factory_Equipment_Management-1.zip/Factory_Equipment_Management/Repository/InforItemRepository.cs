﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Factory_Equipment_Management.Repository
{
    public class InforItemRepository
    {
        private readonly YourDbContext _context;

        public InforItemRepository(YourDbContext context)
        {
            _context = context;
        }

        public async Task<(List<InforItemViewModel> Items, int TotalCount)> GetPagedAsync(
                int page, int pageSize, string name = null,
                float? maintanceCycle = null,
                float? duration = null,
                double? alertMaintance = null,
                double? alertRenew = null,
                string nameRealCategory = null
            )
        {
            var query = from c in _context.Categories
                        join rc in _context.RealCategories on c.idrealCategory equals rc.idRealCategory
                        select new InforItemViewModel
                        {
                            Name = c.name,
                            idRealCategory = rc.idRealCategory,
                            nameRealCategory = rc.name,
                            MaintanceCycle = c.maintanceCycle,
                            Duration = c.duration,
                            AlertMaintance = c.alertMaintance,
                            AlertRenew = c.alertRenew,
                            IdCategory = c.idCategory
                        };

            if (!string.IsNullOrWhiteSpace(nameRealCategory))
                query = query.Where(x => x.nameRealCategory.Contains(nameRealCategory));
            if (maintanceCycle.HasValue)
                query = query.Where(x => x.MaintanceCycle == maintanceCycle);
            if (duration.HasValue)
                query = query.Where(x => x.Duration == duration);
            if (alertMaintance.HasValue)
                query = query.Where(x => x.AlertMaintance == alertMaintance);
            if (alertRenew.HasValue)
                query = query.Where(x => x.AlertRenew == alertRenew);
            if (!string.IsNullOrWhiteSpace(name))
                query = query.Where(x => x.Name.Contains(name));

            int totalCount = await query.CountAsync();
            var items = await query
                .OrderBy(x => x.nameRealCategory)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (items, totalCount);
        }
        //static byte[] StringToByteArray(string hex)
        //{
        //    if (string.IsNullOrEmpty(hex)) return new byte[0];
        //    hex = hex.Replace(" ", "").Replace("-", "");
        //    if (hex.Length % 2 != 0)
        //        throw new ArgumentException("Chuỗi hex phải có độ dài chẵn.");

        //    int numberChars = hex.Length;
        //    List<byte> bytes = new List<byte>();
        //    for (int i = 0; i < numberChars; i += 2)
        //    {
        //        string byteString = hex.Substring(i, 2);
        //        if (byte.TryParse(byteString, System.Globalization.NumberStyles.HexNumber, null, out byte b))
        //        {
        //            bytes.Add(b);
        //        }
        //        else
        //        {
        //            Console.WriteLine($"Bỏ qua cặp ký tự không hợp lệ: '{byteString}' tại vị trí {i}");
        //        }
        //    }
        //    return bytes.ToArray();
        //}

        public async Task<bool> UpdateCategoryAndRealCategoryAsync(InforItemViewModel model)
        {
            var realCategory = await _context.RealCategories
                .FirstOrDefaultAsync(rc => rc.idRealCategory == model.idRealCategory);
            if (realCategory == null)
                return false;

            if (!string.IsNullOrWhiteSpace(model.nameRealCategory))
                realCategory.name = model.nameRealCategory;
            var categories = await _context.Categories
                .Where(c => c.idCategory == model.IdCategory)
                .ToListAsync();

            if (!categories.Any())
                return false;

            foreach (var category in categories)
            {
                if (!string.IsNullOrWhiteSpace(model.Name))
                    category.name = model.Name;
                category.alertMaintance = model.AlertMaintance;
                category.alertRenew = model.AlertRenew;
                category.duration = model.Duration ?? 0f;
                category.maintanceCycle = model.MaintanceCycle ?? 0f;
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<string>> GetDeviceNamesAsync(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
                return await _context.Categories.Select(c => c.name).Distinct().ToListAsync();
            return await _context.Categories
                .Where(c => c.name.Contains(term))
                .Select(c => c.name)
                .Distinct()
                .ToListAsync();
        }

        public async Task<List<object>> GetAllRealCategoriesAsync()
        {
            return await _context.RealCategories
                .Select(rc => new { rc.idRealCategory, rc.name })
                .ToListAsync<object>();
        }

        // Lấy danh sách các giá trị duy nhất cho dropdown
        public async Task<List<float>> GetUniqueMaintanceCyclesAsync()
        {
            return await _context.Categories
                .Where(c => c.maintanceCycle > 0)
                .Select(c => c.maintanceCycle)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<float>> GetUniqueDurationsAsync()
        {
            return await _context.Categories
                .Where(c => c.duration > 0)
                .Select(c => c.duration)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<double>> GetUniqueAlertMaintancesAsync()
        {
            return await _context.Categories
                .Where(c => c.alertMaintance.HasValue && c.alertMaintance > 0)
                .Select(c => c.alertMaintance.Value)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<double>> GetUniqueAlertRenewsAsync()
        {
            return await _context.Categories
                .Where(c => c.alertRenew.HasValue && c.alertRenew > 0)
                .Select(c => c.alertRenew.Value)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<string>> GetUniqueStatusesAsync()
        {
            return await _context.Items
                .Where(i => !string.IsNullOrEmpty(i.status))
                .Select(i => i.status)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<bool> AddCategoryAndRealCategoryAsync(InforItemViewModel model)
        {
            try
            {
                int idRealCategory = model.idRealCategory;
                if (!string.IsNullOrWhiteSpace(model.NewRealCategory))
                {
                    var newRealCat = new RealCategory { name = model.NewRealCategory };
                    _context.RealCategories.Add(newRealCat);
                    await _context.SaveChangesAsync();
                    idRealCategory = newRealCat.idRealCategory;
                }

                var category = await _context.Categories
                    .FirstOrDefaultAsync(c => c.name == model.Name && c.idrealCategory == idRealCategory);

                if (category == null)
                {
                    category = new Category
                    {
                        name = model.Name,
                        idrealCategory = idRealCategory,
                        maintanceCycle = model.MaintanceCycle ?? 0f,
                        duration = model.Duration ?? 0f,
                        alertMaintance = model.AlertMaintance,
                        alertRenew = model.AlertRenew
                    };
                    _context.Categories.Add(category);
                    await _context.SaveChangesAsync();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }


    }
}