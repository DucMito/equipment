﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Drawing.Printing;
using System.Security.Claims;

namespace Factory_Equipment_Management.Repository
{
    public class ManagerDeviceRepository
    {
        private readonly YourDbContext _context;

        public ManagerDeviceRepository(YourDbContext context)
        {
            _context = context;
        }

        //    public async Task<(List<DeviceDisplayModel> Items, int TotalItems)> GetDevicesAsync(
        //int pageNumber, int pageSize, string status = null,
        //string deviceName = null, string location = null,
        //string comment = null, string serialNumber = null, string supplier = null, string contractor = null,
        //int? filterType = null, int? idRealCategory = null, string nameRealCategory = null)
        //    {
        //        var query = from item in _context.Items
        //                    join category in _context.Categories on item.idCategory equals category.idCategory into catJoin
        //                    from category in catJoin.DefaultIfEmpty()
        //                    join area in _context.Areas on item.idArea equals area.idArea into areaJoin
        //                    from area in areaJoin.DefaultIfEmpty()
        //                    join warehouse in _context.Warehouses on area.idWarehouse equals warehouse.idWarehouse into wareJoin
        //                    from warehouse in wareJoin.DefaultIfEmpty()
        //                    join realCategory in _context.RealCategories on category.idrealCategory equals realCategory.idRealCategory into realCatJoin
        //                    from realCategory in realCatJoin.DefaultIfEmpty()
        //                    select new { item, category, area, warehouse, realCategory };

        //        if (!string.IsNullOrEmpty(status))
        //            query = query.Where(d => d.item.status == status);
        //        if (!string.IsNullOrEmpty(deviceName))
        //            query = query.Where(d => d.category != null && d.category.name.Contains(deviceName));
        //        if (!string.IsNullOrEmpty(location))
        //            query = query.Where(d => d.area != null && d.area.name.Contains(location));
        //        if (!string.IsNullOrEmpty(comment))
        //            query = query.Where(d => d.item.comment != null && d.item.comment.Contains(comment));
        //        if (!string.IsNullOrEmpty(serialNumber))
        //            query = query.Where(d => d.item.serialNumber != null && d.item.serialNumber.Contains(serialNumber));
        //        if (!string.IsNullOrEmpty(supplier))
        //            query = query.Where(d => d.item.supplier != null && d.item.supplier.Contains(supplier));
        //        if (!string.IsNullOrEmpty(contractor))
        //            query = query.Where(d => d.item.contractor != null && d.item.contractor.Contains(contractor));
        //        if (idRealCategory.HasValue)
        //            query = query.Where(d => d.realCategory != null && d.realCategory.idRealCategory == idRealCategory.Value);
        //        if (!string.IsNullOrEmpty(nameRealCategory))
        //            query = query.Where(d => d.realCategory != null && d.realCategory.name != null && d.realCategory.name.Contains(nameRealCategory));
        //        if (filterType.HasValue)
        //            query = query.Where(d => d.item.type == filterType.Value);

        //        int totalItems = await query.CountAsync();

        //        var items = await query
        //.Skip((pageNumber - 1) * pageSize)
        //.Take(pageSize)
        //.AsNoTracking()
        //.ToListAsync();

        //        var result = items.Select(d => new DeviceDisplayModel
        //        {
        //            idItem = d.item.idItem,
        //            ItemName = d.category?.name ?? "",
        //            idCategory = d.item.idCategory ?? 0,
        //            Name = d.category?.name ?? "",
        //            CategoryName = d.category?.name ?? "",
        //            LocationName = d.area?.name ?? "",
        //            WarehouseName = d.warehouse?.name ?? "",
        //            image = d.item.image ?? "",
        //            status = d.item.status ?? "",
        //            activedDate = d.item.activedDate,
        //            maintanceDate = d.item.maintanceDate,
        //            dangKiem = d.item.dangKiem,
        //            renewDate = d.item.renewDate,
        //            type = d.item.type,
        //            Quantity = null,
        //            IsSelected = false,
        //            Note = null,
        //            supplier = d.item.supplier ?? "",
        //            contractor = d.item.contractor ?? "",
        //            comment = d.item.comment ?? "",
        //            serialNumber = d.item.serialNumber ?? "",
        //            idRealCategory = d.realCategory?.idRealCategory ?? 0,
        //            nameRealCategory = d.realCategory?.name ?? ""
        //        }).ToList();

        //        return (result, totalItems);
        //    }


        public async Task<List<RealCategory>> GetRealCategoriesAsync()
        {
            return await _context.RealCategories
                .OrderBy(rc => rc.name)
                .ToListAsync();
        }

        public async Task<List<Category>> GetCategoriesByRealCategoryAsync(int idRealCategory)
        {
            return await _context.Categories
                .Where(c => c.idrealCategory == idRealCategory)
                .OrderBy(c => c.name)
                .ToListAsync();
        }

        public async Task<RealCategory> GetRealCategoryByCategoryNameAsync(string categoryName)
        {
            var realCategory = await _context.Categories
                .Where(c => c.name == categoryName)
                .Join(_context.RealCategories,
                      c => c.idrealCategory,
                      rc => rc.idRealCategory,
                      (c, rc) => rc)
                .FirstOrDefaultAsync();

            return realCategory;
        }

        public async Task<(List<DeviceDisplayModel> Items, int TotalItems)> GetDevicesAsync(
    int pageNumber, int pageSize, string status = null,
    string deviceName = null, string location = null,
    string comment = null, string serialNumber = null, string supplier = null, string contractor = null,
    int? filterType = null, int? idRealCategory = null, string nameRealCategory = null)
        {
            try
            {
                // ===== NORMALIZE FILTER INPUTS =====
                deviceName = string.IsNullOrWhiteSpace(deviceName) ? null : deviceName.Trim();
                location = string.IsNullOrWhiteSpace(location) ? null : location.Trim();
                serialNumber = string.IsNullOrWhiteSpace(serialNumber) ? null : serialNumber.Trim();
                supplier = string.IsNullOrWhiteSpace(supplier) ? null : supplier.Trim();
                contractor = string.IsNullOrWhiteSpace(contractor) ? null : contractor.Trim();
                status = string.IsNullOrWhiteSpace(status) ? null : status.Trim();

                System.Diagnostics.Debug.WriteLine($"=== NORMALIZED FILTERS ===");
                System.Diagnostics.Debug.WriteLine($"deviceName: '{deviceName}'");
                System.Diagnostics.Debug.WriteLine($"location: '{location}'");
                System.Diagnostics.Debug.WriteLine($"serialNumber: '{serialNumber}'");
                System.Diagnostics.Debug.WriteLine($"supplier: '{supplier}'");
                System.Diagnostics.Debug.WriteLine($"contractor: '{contractor}'");

                var baseQuery = from item in _context.Items
                                join category in _context.Categories on item.idCategory equals category.idCategory into catJoin
                                from category in catJoin.DefaultIfEmpty()
                                join area in _context.Areas on item.idArea equals area.idArea into areaJoin
                                from area in areaJoin.DefaultIfEmpty()
                                join warehouse in _context.Warehouses on area.idWarehouse equals warehouse.idWarehouse into wareJoin
                                from warehouse in wareJoin.DefaultIfEmpty()
                                join realCategory in _context.RealCategories on category.idrealCategory equals realCategory.idRealCategory into realCatJoin
                                from realCategory in realCatJoin.DefaultIfEmpty()
                                select new { item, category, area, warehouse, realCategory };

                // ===== APPLY FILTERS WITH CASE-INSENSITIVE COMPARISON =====
                if (!string.IsNullOrEmpty(status))
                {
                    System.Diagnostics.Debug.WriteLine($"Applying status filter: '{status}'");
                    baseQuery = baseQuery.Where(d => d.item.status != null &&
                                                   d.item.status.ToLower().Trim() == status.ToLower());
                }

                if (!string.IsNullOrEmpty(deviceName))
                {
                    System.Diagnostics.Debug.WriteLine($"Applying deviceName filter: '{deviceName}'");
                    baseQuery = baseQuery.Where(d => d.category != null &&
                                                   d.category.name != null &&
                                                   d.category.name.ToLower().Contains(deviceName.ToLower()));
                }

                if (!string.IsNullOrEmpty(location))
                {
                    System.Diagnostics.Debug.WriteLine($"Applying location filter: '{location}'");
                    baseQuery = baseQuery.Where(d => d.area != null &&
                                                   d.area.name != null &&
                                                   d.area.name.ToLower().Contains(location.ToLower()));
                }

                if (!string.IsNullOrEmpty(serialNumber))
                {
                    System.Diagnostics.Debug.WriteLine($"Applying serialNumber filter: '{serialNumber}'");
                    baseQuery = baseQuery.Where(d => d.item.serialNumber != null &&
                                                   d.item.serialNumber != "No data" &&
                                                   d.item.serialNumber.ToLower().Contains(serialNumber.ToLower()));
                }

                if (!string.IsNullOrEmpty(supplier))
                {
                    System.Diagnostics.Debug.WriteLine($"Applying supplier filter: '{supplier}'");
                    baseQuery = baseQuery.Where(d => d.item.supplier != null &&
                                                   d.item.supplier != "No data" &&
                                                   d.item.supplier.ToLower().Contains(supplier.ToLower()));
                }

                if (!string.IsNullOrEmpty(contractor))
                {
                    System.Diagnostics.Debug.WriteLine($"Applying contractor filter: '{contractor}'");
                    baseQuery = baseQuery.Where(d => d.item.contractor != null &&
                                                   d.item.contractor != "No data" &&
                                                   d.item.contractor.ToLower().Contains(contractor.ToLower()));
                }

                if (filterType.HasValue)
                {
                    System.Diagnostics.Debug.WriteLine($"Applying type filter: {filterType}");
                    baseQuery = baseQuery.Where(d => d.item.type == filterType.Value);
                }

                if (idRealCategory.HasValue)
                {
                    System.Diagnostics.Debug.WriteLine($"Applying idRealCategory filter: {idRealCategory}");
                    baseQuery = baseQuery.Where(d => d.realCategory != null &&
                                                   d.realCategory.idRealCategory == idRealCategory.Value);
                }

                int totalItems = await baseQuery.CountAsync();
                System.Diagnostics.Debug.WriteLine($"Final total items: {totalItems}");

                var rawItems = await baseQuery
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .AsNoTracking()
                    .ToListAsync();

                System.Diagnostics.Debug.WriteLine($"Items retrieved for page: {rawItems.Count}");

                var result = rawItems.Select(d => new DeviceDisplayModel
                {
                    idItem = d.item.idItem,
                    ItemName = d.category?.name?.Trim() ?? "",
                    idCategory = d.item.idCategory.HasValue ? d.item.idCategory.Value : 0,
                    Name = d.category?.name?.Trim() ?? "",
                    CategoryName = d.category?.name?.Trim() ?? "",
                    LocationName = d.area?.name?.Trim() ?? "",
                    WarehouseName = d.warehouse?.name?.Trim() ?? "",
                    image = d.item.image ?? "",
                    status = d.item.status?.Trim() ?? "",
                    activedDate = d.item.activedDate,
                    maintanceDate = d.item.maintanceDate,
                    dangKiem = d.item.dangKiem,
                    renewDate = d.item.renewDate,
                    type = d.item.type,
                    Quantity = null,
                    IsSelected = false,
                    Note = null,
                    supplier = d.item.supplier ?? "No data",
                    contractor = d.item.contractor ?? "No data",
                    comment = d.item.comment ?? "No data",
                    serialNumber = d.item.serialNumber ?? "No data",
                    idRealCategory = d.realCategory?.idRealCategory ?? 0,
                    nameRealCategory = d.realCategory?.name?.Trim() ?? ""
                }).ToList();

                // ===== LOG SOME SAMPLE DATA FOR DEBUG =====
                if (result.Any())
                {
                    var firstItem = result.First();
                    System.Diagnostics.Debug.WriteLine($"Sample item - Category: '{firstItem.CategoryName}', Supplier: '{firstItem.supplier}', Serial: '{firstItem.serialNumber}'");
                }

                return (result, totalItems);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"GetDevicesAsync error: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"Stack trace: {ex.StackTrace}");
                return (new List<DeviceDisplayModel>(), 0);
            }
        }

        //Cập nhật
        //public async Task<(List<DeviceDisplayModel> Items, int TotalItems)> GetDevicesAsync(
        //    int pageNumber, int pageSize, string status = null,
        //    string deviceName = null, string location = null,
        //    string comment = null, string serialNumber = null, string supplier = null, string contractor = null,
        //    int? filterType = null, int? idRealCategory = null, string nameRealCategory = null)
        //{
        //    try
        //    {
        //        // ===== ALTERNATIVE: FETCH RAW DATA FIRST ĐỂ TRÁNH NULL COALESCING ISSUES =====
        //        var baseQuery = from item in _context.Items
        //                        join category in _context.Categories on item.idCategory equals category.idCategory into catJoin
        //                        from category in catJoin.DefaultIfEmpty()
        //                        join area in _context.Areas on item.idArea equals area.idArea into areaJoin
        //                        from area in areaJoin.DefaultIfEmpty()
        //                        join warehouse in _context.Warehouses on area.idWarehouse equals warehouse.idWarehouse into wareJoin
        //                        from warehouse in wareJoin.DefaultIfEmpty()
        //                        join realCategory in _context.RealCategories on category.idrealCategory equals realCategory.idRealCategory into realCatJoin
        //                        from realCategory in realCatJoin.DefaultIfEmpty()
        //                        select new { item, category, area, warehouse, realCategory };

        //        // Apply basic filters
        //        if (!string.IsNullOrEmpty(status))
        //            baseQuery = baseQuery.Where(d => d.item.status == status);
        //        if (filterType.HasValue)
        //            baseQuery = baseQuery.Where(d => d.item.type == filterType.Value);

        //        int totalItems = await baseQuery.CountAsync();

        //        var rawItems = await baseQuery
        //            .Skip((pageNumber - 1) * pageSize)
        //            .Take(pageSize)
        //            .AsNoTracking()
        //            .ToListAsync();

        //        var result = rawItems.Select(d => new DeviceDisplayModel
        //        {
        //            idItem = d.item.idItem,
        //            ItemName = d.category?.name ?? "",
        //            idCategory = d.item.idCategory.HasValue ? d.item.idCategory.Value : 0,
        //            Name = d.category?.name ?? "",
        //            CategoryName = d.category?.name ?? "",
        //            LocationName = d.area?.name ?? "",
        //            WarehouseName = d.warehouse?.name ?? "",
        //            image = d.item.image ?? "",
        //            status = d.item.status ?? "",
        //            activedDate = d.item.activedDate,
        //            maintanceDate = d.item.maintanceDate,
        //            dangKiem = d.item.dangKiem,
        //            renewDate = d.item.renewDate,
        //            type = d.item.type,
        //            Quantity = null,
        //            IsSelected = false,
        //            Note = null,
        //            supplier = d.item.supplier ?? "No data",
        //            contractor = d.item.contractor ?? "No data",
        //            comment = d.item.comment ?? "No data",
        //            serialNumber = d.item.serialNumber ?? "No data",
        //            idRealCategory = d.realCategory?.idRealCategory ?? 0,
        //            nameRealCategory = d.realCategory?.name ?? ""
        //        }).ToList();

        //        if (!string.IsNullOrEmpty(deviceName))
        //            result = result.Where(d => d.CategoryName.Contains(deviceName, StringComparison.OrdinalIgnoreCase)).ToList();
        //        if (!string.IsNullOrEmpty(location))
        //            result = result.Where(d => d.LocationName.Contains(location, StringComparison.OrdinalIgnoreCase)).ToList();
        //        if (!string.IsNullOrEmpty(comment))
        //            result = result.Where(d => d.comment.Contains(comment, StringComparison.OrdinalIgnoreCase)).ToList();
        //        if (!string.IsNullOrEmpty(serialNumber))
        //            result = result.Where(d => d.serialNumber.Contains(serialNumber, StringComparison.OrdinalIgnoreCase)).ToList();
        //        if (!string.IsNullOrEmpty(supplier))
        //            result = result.Where(d => d.supplier.Contains(supplier, StringComparison.OrdinalIgnoreCase)).ToList();
        //        if (!string.IsNullOrEmpty(contractor))
        //            result = result.Where(d => d.contractor.Contains(contractor, StringComparison.OrdinalIgnoreCase)).ToList();
        //        if (idRealCategory.HasValue)
        //            result = result.Where(d => d.idRealCategory == idRealCategory.Value).ToList();

        //        return (result, totalItems);
        //    }
        //    catch (Exception ex)
        //    {
        //        System.Diagnostics.Debug.WriteLine($"GetDevicesAsync error: {ex.Message}");
        //        return (new List<DeviceDisplayModel>(), 0);
        //    }
        //}


        public async Task<bool> ChangeStatusAsync(int id, ClaimsPrincipal user)
        {
            var role = user.Claims.FirstOrDefault(c => c.Type == System.Security.Claims.ClaimTypes.Role)?.Value;
            if (role != "Admin" && role != "Manager") return false;

            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return false;

            item.status = "Dự phòng";
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Item> GetByIdAsync(int? idItem)
        {
            return await _context.Items.FirstOrDefaultAsync(d => d.idItem == idItem);
        }

        public async Task UpdateAsync(Item device)
        {
            _context.Items.Update(device);
            await _context.SaveChangesAsync();
        }

        public static string ImageFileToHex(IFormFile imageFile)
        {
            using (var ms = new MemoryStream())
            {
                imageFile.CopyTo(ms);
                byte[] bytes = ms.ToArray();
                return BitConverter.ToString(bytes).Replace("-", "");
            }
        }

        //public async Task<(bool Success, string Message)> UpdateDeviceAsync(IFormCollection form, IFormFile imageFile)
        //{
        //    try
        //    {
        //        int idItem = int.Parse(form["idItem"]);
        //        int idCategory = int.Parse(form["idCategory"]);
        //        int? idArea = string.IsNullOrEmpty(form["idArea"]) ? null : int.Parse(form["idArea"]);
        //        string status = form["status"];
        //        string itemName = form["ItemName"];
        //        DateTime? activedDate = string.IsNullOrEmpty(form["activedDate"]) ? null : DateTime.Parse(form["activedDate"]);
        //        DateTime? maintanceDate = string.IsNullOrEmpty(form["maintanceDate"]) ? null : DateTime.Parse(form["maintanceDate"]);
        //        DateTime? renewDate = string.IsNullOrEmpty(form["renewDate"]) ? null : DateTime.Parse(form["renewDate"]);
        //        string comment = form["comment"];
        //        string serialNumber = form["serialNumber"];
        //        string supplier = form["supplier"];
        //        string contractor = form["contractor"];

        //        var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == idItem);
        //        if (item == null) return (false, "Thiết bị không tồn tại.");

        //        if (idArea != null && !await _context.Areas.AnyAsync(a => a.idArea == idArea))
        //            return (false, "Khu vực không hợp lệ.");

        //        if (!await _context.Categories.AnyAsync(c => c.idCategory == idCategory))
        //            return (false, "Danh mục không hợp lệ.");

        //        if (imageFile != null && imageFile.Length > 0)
        //        {
        //            item.image = ImageFileToHex(imageFile);
        //        }

        //        // Cập nhật các trường khác
        //        item.idCategory = idCategory != 0 ? idCategory : item.idCategory;
        //        item.idArea = idArea.HasValue ? idArea : item.idArea;
        //        item.status = !string.IsNullOrEmpty(status) ? status : item.status;
        //        item.po = !string.IsNullOrEmpty(itemName) ? itemName : item.po;
        //        item.activedDate = activedDate.HasValue ? activedDate : item.activedDate;
        //        item.maintanceDate = maintanceDate.HasValue ? maintanceDate : item.maintanceDate;
        //        item.renewDate = renewDate.HasValue ? renewDate : item.renewDate;
        //        item.comment = comment != null ? (comment == "" ? null : comment) : item.comment;
        //        item.serialNumber = serialNumber != null ? (serialNumber == "" ? null : serialNumber) : item.serialNumber;
        //        item.supplier = supplier != null ? (supplier == "" ? null : supplier) : item.supplier;
        //        item.contractor = contractor != null ? (contractor == "" ? null : contractor) : item.contractor;

        //        await _context.SaveChangesAsync();
        //        return (true, "Cập nhật thiết bị thành công!");
        //    }
        //    catch (Exception ex)
        //    {
        //        return (false, "Lỗi cập nhật: " + ex.Message);
        //    }
        //}

        // Delete items


        public async Task<(bool Success, string Message)> UpdateDeviceAsync(IFormCollection form, IFormFile imageFile)
        {
            try
            {
                // ===== SAFE PARSING ĐỂ TRÁNH DBNull CAST EXCEPTION =====
                int idItem = int.Parse(form["idItem"].ToString());
                int idCategory = int.Parse(form["idCategory"].ToString());

                // Safe parse cho idArea
                int? idArea = null;
                var idAreaValue = form["idArea"].ToString();
                if (!string.IsNullOrEmpty(idAreaValue) && int.TryParse(idAreaValue, out int areaId))
                {
                    idArea = areaId;
                }

                // ===== SAFE PARSING CHO STRING FIELDS =====
                string status = form["status"].ToString() ?? "";
                string itemName = form["ItemName"].ToString() ?? "";

                // ===== LOGIC MỚI: TRỐNG THÌ "No data", CÓ DỮ LIỆU THÌ LẤY =====
                string comment = string.IsNullOrWhiteSpace(form["comment"].ToString()) ? "No data" : form["comment"].ToString().Trim();
                string serialNumber = string.IsNullOrWhiteSpace(form["serialNumber"].ToString()) ? "No data" : form["serialNumber"].ToString().Trim();
                string supplier = string.IsNullOrWhiteSpace(form["supplier"].ToString()) ? "No data" : form["supplier"].ToString().Trim();
                string contractor = string.IsNullOrWhiteSpace(form["contractor"].ToString()) ? "No data" : form["contractor"].ToString().Trim();
                string po = string.IsNullOrWhiteSpace(itemName) ? "No data" : itemName.Trim(); // PO từ ItemName field

                // Safe parse cho DateTime fields
                DateTime? activedDate = null;
                var activedDateValue = form["activedDate"].ToString();
                if (!string.IsNullOrEmpty(activedDateValue) && DateTime.TryParse(activedDateValue, out DateTime activeDate))
                {
                    activedDate = activeDate;
                }

                DateTime? maintanceDate = null;
                var maintanceDateValue = form["maintanceDate"].ToString();
                if (!string.IsNullOrEmpty(maintanceDateValue) && DateTime.TryParse(maintanceDateValue, out DateTime maintDate))
                {
                    maintanceDate = maintDate;
                }

                DateTime? renewDate = null;
                var renewDateValue = form["renewDate"].ToString();
                if (!string.IsNullOrEmpty(renewDateValue) && DateTime.TryParse(renewDateValue, out DateTime renDate))
                {
                    renewDate = renDate;
                }

                var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == idItem);
                if (item == null) return (false, "Thiết bị không tồn tại.");

                if (idArea != null && !await _context.Areas.AnyAsync(a => a.idArea == idArea))
                    return (false, "Khu vực không hợp lệ.");

                if (!await _context.Categories.AnyAsync(c => c.idCategory == idCategory))
                    return (false, "Danh mục không hợp lệ.");

                if (imageFile != null && imageFile.Length > 0)
                {
                    item.image = ImageFileToHex(imageFile);
                }

                item.idCategory = idCategory != 0 ? idCategory : item.idCategory;
                item.idArea = idArea;
                item.status = !string.IsNullOrEmpty(status) ? status : item.status;
                item.activedDate = activedDate ?? item.activedDate;
                item.maintanceDate = maintanceDate ?? item.maintanceDate;
                item.renewDate = renewDate ?? item.renewDate;


                item.po = po;                   
                item.comment = comment;          
                item.serialNumber = serialNumber;
                item.supplier = supplier;        
                item.contractor = contractor;   

                await _context.SaveChangesAsync();
                return (true, "Cập nhật thiết bị thành công!");
            }
            catch (Exception ex)
            {
                return (false, "Lỗi cập nhật: " + ex.Message);
            }
        }
        public async Task<bool> DeleteDeviceAsync(int id)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return false;
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}