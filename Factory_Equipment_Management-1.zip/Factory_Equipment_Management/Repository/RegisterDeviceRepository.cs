﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Factory_Equipment_Management.Repository
{
    public class RegisterDeviceRepository
    {
        private readonly YourDbContext _context;
        public RegisterDeviceRepository(YourDbContext context)
        {
            _context = context;
        }


        public List<RegisterDeviceListItemViewModel> GetRegisterDeviceList(int page, int pageSize, out int totalCount, string status = null)
        {
            var query = from device in _context.RegisterDevices
                        join request in _context.RegisterDeviceRequests
                            on device.idRegisterDeviceRequest equals request.idRegisterDeviceRequest
                        select new
                        {
                            idRegisterDevice = device.idRegisterDevice,
                            name = device.name ?? "",
                            num = device.num,
                            status = request.status ?? "",
                            date = request.date,
                            imageHex = device.image ?? ""
                        };

            if (!string.IsNullOrEmpty(status))
                query = query.Where(x => x.status == status);

            totalCount = query.Count();

            var data = query
                .OrderByDescending(x => x.date)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            // Chuyển đổi hex sang base64 ở đây (trên dữ liệu đã lấy về)
            return data.Select(x => new RegisterDeviceListItemViewModel
            {
                idRegisterDevice = x.idRegisterDevice,
                name = x.name,
                num = x.num,
                status = x.status,
                date = x.date,
                image = ConvertHexToBase64Image(x.imageHex)
            }).ToList();
        }

        // Thêm hàm này vào class RegisterDeviceRepository
        private string ConvertHexToBase64Image(string hex)
        {
            if (string.IsNullOrEmpty(hex) || hex == "No data")
                return null;
            try
            {
                byte[] bytes = Enumerable.Range(0, hex.Length / 2)
                    .Select(x => Convert.ToByte(hex.Substring(x * 2, 2), 16))
                    .ToArray();
                // Nếu bạn chắc chắn là PNG, đổi image/png thành image/jpeg nếu là jpeg
                return "data:image/png;base64," + Convert.ToBase64String(bytes);
            }
            catch
            {
                return null;
            }
        }

        public bool AddRegisterDevice(RegisterDeviceCreateViewModel model)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {
                // 1. RealCategory
                var realCategory = _context.RealCategories
                    .FirstOrDefault(rc => rc.idRealCategory == model.IdRealCategory);
                if (realCategory == null)
                {
                    realCategory = new RealCategory
                    {
                        idRealCategory = model.IdRealCategory,
                        name = "No data"
                    };
                    _context.RealCategories.Add(realCategory);
                    _context.SaveChanges();
                }

                // 2. Category
                var category = _context.Categories
                    .FirstOrDefault(c => c.idCategory == model.CategoryId);
                if (category == null)
                {
                    category = new Category
                    {
                        idCategory = model.CategoryId,
                        name = model.Name,
                        idrealCategory = realCategory.idRealCategory,
                        alertMaintance = model.AlertMaintaince.HasValue ? (double)model.AlertMaintaince.Value : 0,
                        alertRenew = model.AlertRenew.HasValue ? (double)model.AlertRenew.Value : 0,
                        duration = model.MaintainceCycle.HasValue ? (float)model.MaintainceCycle.Value : 0,
                        maintanceCycle = model.MaintainceCycle.HasValue ? (float)model.MaintainceCycle.Value : 0
                    };
                    _context.Categories.Add(category);
                    _context.SaveChanges();
                }

                // 3. Lấy thông tin cũ từ item (nếu có)
                var oldItem = _context.Items
                    .Where(i => i.idCategory == model.CategoryId)
                    .OrderByDescending(i => i.idItem)
                    .FirstOrDefault();

                // Xử lý ảnh: ưu tiên ảnh upload mới, nếu không có thì lấy từ oldItem
                string imageHex = "No data";
                if (model.Image != null && model.Image.Length > 0)
                {
                    using var ms = new MemoryStream();
                    model.Image.CopyTo(ms);
                    byte[] bytes = ms.ToArray();
                    imageHex = BitConverter.ToString(bytes).Replace("-", "");
                }
                else if (oldItem != null && !string.IsNullOrEmpty(oldItem.image))
                {
                    imageHex = oldItem.image;
                }
                DateTime? dangKiem = model.DangKiemDate ?? oldItem?.dangKiem;

                // 4. RegisterDeviceRequest (tạo mới mỗi lần)
                var request = new RegisterDeviceRequest
                {
                    date = DateTime.Now,
                    status = "Approve"
                };
                _context.RegisterDeviceRequests.Add(request);
                _context.SaveChanges();

                // 5. RegisterDevice
                var device = new RegisterDevice
                {
                    idCategory = category.idCategory,
                    name = category.name,
                    num = model.Num,
                    image = imageHex,
                    idRegisterDeviceRequest = request.idRegisterDeviceRequest,
                    maintanceCycle = model.MaintainceCycle.HasValue ? (int)model.MaintainceCycle.Value : 0,
                    renewCycle = model.RenewCycle.HasValue ? (int)model.RenewCycle.Value : 0,
                    po = model.PO,
                    alertMaintance = model.AlertMaintaince.HasValue ? (int)model.AlertMaintaince.Value : 0,
                    alertRenew = model.AlertRenew.HasValue ? (int)model.AlertRenew.Value : 0,
                    dangKiem = dangKiem,
                    type = model.Type == 1,
                    idRealCategory = realCategory.idRealCategory,
                    realCategoryName = realCategory.name
                };
                _context.RegisterDevices.Add(device);
                _context.SaveChanges();

                // 6. Lưu vào bảng item (num bản ghi)
                for (int i = 0; i < model.Num; i++)
                {
                    var item = new Item
                    {
                        idCategory = category.idCategory,
                        image = imageHex,
                        active = false,
                        status = "Dự phòng",
                        receivedDate = null,
                        activedDate = null,
                        idArea = null,
                        maintanceDate = null,
                        renewDate = null,
                        maintanceRequested = false,
                        po = model.PO ?? "No data",
                        dangKiem = dangKiem,
                        type = model.Type,
                        contractor = string.IsNullOrWhiteSpace(model.Contractor) ? "No data" : model.Contractor,
                        serialNumber = string.IsNullOrWhiteSpace(model.SerialNumber) ? "No data" : model.SerialNumber,
                        supplier = string.IsNullOrWhiteSpace(model.Supplier) ? "No data" : model.Supplier,
                        comment = string.IsNullOrWhiteSpace(model.Comment) ? "No data" : model.Comment
                    };
                    _context.Items.Add(item);
                }
                _context.SaveChanges();

                transaction.Commit();
                return true;
            }
            catch
            {
                transaction.Rollback();
                return false;
            }
        }

        public async Task<CategoryInfoViewModel?> GetCategoryInfoAsync(int categoryId)
        {
            var oldItem = await _context.Items
                .Where(i => i.idCategory == categoryId)
                .OrderByDescending(i => i.idItem)
                .FirstOrDefaultAsync();

            return await _context.Categories
                .Where(c => c.idCategory == categoryId)
                .Select(c => new CategoryInfoViewModel
                {
                    idCategory = c.idCategory,
                    name = c.name,
                    alertMaintance = c.alertMaintance ?? 0,
                    alertRenew = c.alertRenew ?? 0,
                    duration = c.duration,
                    maintanceCycle = c.maintanceCycle,
                    idrealCategory = c.idrealCategory,
                    realCategoryName = _context.RealCategories
                        .Where(rc => rc.idRealCategory == c.idrealCategory)
                        .Select(rc => rc.name)
                        .FirstOrDefault(),
                    image = oldItem != null ? oldItem.image : null,
                    type = oldItem != null ? oldItem.type : (int?)null,
                    dangKiem = oldItem != null ? oldItem.dangKiem : null
                })
                .FirstOrDefaultAsync();
        }



        public List<CategorySimpleViewModel> GetCategoriesByRealCategory(int realCategoryId)
        {
            return _context.Categories
                .Where(c => c.idrealCategory == realCategoryId)
                .Select(c => new CategorySimpleViewModel
                {
                    idCategory = c.idCategory,
                    name = c.name
                })
                .ToList();
        }

        public RealCategorySimpleViewModel? GetRealCategoryByCategoryId(int categoryId)
        {
            var category = _context.Categories.FirstOrDefault(c => c.idCategory == categoryId);
            if (category == null) return null;
            var realCategory = _context.RealCategories.FirstOrDefault(rc => rc.idRealCategory == category.idrealCategory);
            if (realCategory == null) return null;
            return new RealCategorySimpleViewModel
            {
                idRealCategory = realCategory.idRealCategory,
                name = realCategory.name
            };
        }

        // phân trang 
        public async Task<(List<RegisterDeviceRequestModel> Requests, int TotalCount)> GetPagedRequestsAsync(int page, int pageSize, string status)
        {
            var query = _context.RegisterDeviceRequests.AsQueryable();
            if (!string.IsNullOrEmpty(status))
                query = query.Where(x => x.status == status);

            int totalCount = await query.CountAsync();

            var data = await query
                .OrderByDescending(x => x.date)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (data.Select(x => new RegisterDeviceRequestModel
            {
                idRegisterDeviceRequest = x.idRegisterDeviceRequest,
                date = x.date,
                status = x.status
            }).ToList(), totalCount);
        }

    }
}