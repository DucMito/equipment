﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Factory_Equipment_Management.Migrations
{
    /// <inheritdoc />
    public partial class UpdateCategory_AddMaintanceCycleAndDuration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "duration",
                table: "item");

            migrationBuilder.DropColumn(
                name: "maintaneceCycle",
                table: "item");

            migrationBuilder.AddColumn<float>(
                name: "duration",
                table: "category",
                type: "float",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "maintaneceCycle",
                table: "category",
                type: "float",
                nullable: false,
                defaultValue: 0f);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "duration",
                table: "category");

            migrationBuilder.DropColumn(
                name: "maintaneceCycle",
                table: "category");

            migrationBuilder.AddColumn<float>(
                name: "duration",
                table: "item",
                type: "float",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "maintaneceCycle",
                table: "item",
                type: "float",
                nullable: false,
                defaultValue: 0f);
        }
    }
}
