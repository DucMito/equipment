﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Factory_Equipment_Management.Repository
{
    public class InforItemRepository
    {
        private readonly YourDbContext _context;

        public InforItemRepository(YourDbContext context)
        {
            _context = context;
        }

        public async Task<(List<InforItemViewModel> Items, int TotalCount)> GetPagedAsync(
    int page, int pageSize, string name = null,
    float? maintanceCycle = null,
    float? duration = null,
    double? alertMaintance = null,
    double? alertRenew = null, int? idRealCategory = null,
    string nameRealCategory = null,
    string status = null // Thêm tham số này
)
        {
            var query = from c in _context.Categories
                        join rc in _context.RealCategories on c.idrealCategory equals rc.idRealCategory
                        join i in _context.Items on c.idCategory equals i.idCategory into itemGroup
                        from item in itemGroup.DefaultIfEmpty()
                        select new InforItemViewModel
                        {
                            Name = c.name,
                            idRealCategory = rc.idRealCategory,
                            nameRealCategory = rc.name,
                            MaintanceCycle = c.maintanceCycle,
                            Duration = c.duration,
                            AlertMaintance = c.alertMaintance,
                            AlertRenew = c.alertRenew,
                            Status = item != null ? item.status : "No data",
                            IdCategory = c.idCategory
                        };

            if (!string.IsNullOrWhiteSpace(nameRealCategory))
                query = query.Where(x => x.nameRealCategory.Contains(nameRealCategory));
            if (maintanceCycle.HasValue)
                query = query.Where(x => x.MaintanceCycle == maintanceCycle);
            if (duration.HasValue)
                query = query.Where(x => x.Duration == duration);
            if (alertMaintance.HasValue)
                query = query.Where(x => x.AlertMaintance == alertMaintance);
            if (alertRenew.HasValue)
                query = query.Where(x => x.AlertRenew == alertRenew);
            if (idRealCategory.HasValue)
                query = query.Where(x => x.idRealCategory == idRealCategory.Value);
            if (!string.IsNullOrWhiteSpace(status))
                query = query.Where(x => x.Status == status);
            if (!string.IsNullOrWhiteSpace(name))
                query = query.Where(x => x.Name.Contains(name));

            int totalCount = await query.CountAsync();
            var items = await query
                .OrderBy(x => x.nameRealCategory)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (items, totalCount);
        }
        // Hàm chuyển đổi chuỗi hex sang mảng byte (nếu cần)
        static byte[] StringToByteArray(string hex)
        {
            if (string.IsNullOrEmpty(hex)) return new byte[0];
            hex = hex.Replace(" ", "").Replace("-", "");
            if (hex.Length % 2 != 0)
                throw new ArgumentException("Chuỗi hex phải có độ dài chẵn.");

            int numberChars = hex.Length;
            List<byte> bytes = new List<byte>();
            for (int i = 0; i < numberChars; i += 2)
            {
                string byteString = hex.Substring(i, 2);
                if (byte.TryParse(byteString, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                {
                    bytes.Add(b);
                }
                else
                {
                    Console.WriteLine($"Bỏ qua cặp ký tự không hợp lệ: '{byteString}' tại vị trí {i}");
                    // Nếu muốn throw thì giữ nguyên, nếu muốn bỏ qua thì chỉ log
                }
            }
            return bytes.ToArray();
        }

        public async Task<bool> UpdateCategoryAndRealCategoryAsync(InforItemViewModel model)
        {
            // Tìm realCategory theo id
            var realCategory = await _context.RealCategories
                .FirstOrDefaultAsync(rc => rc.idRealCategory == model.idRealCategory);
            if (realCategory == null)
                return false;

            // Cập nhật tên realCategory nếu có thay đổi
            if (!string.IsNullOrWhiteSpace(model.nameRealCategory))
                realCategory.name = model.nameRealCategory;

            // Tìm tất cả category liên kết với realCategory này
            var categories = await _context.Categories
                .Where(c => c.idrealCategory == model.idRealCategory)
                .ToListAsync();

            if (!categories.Any())
                return false;

            // Cập nhật tên category và các trường khác cho tất cả category thuộc realCategory này
            foreach (var category in categories)
            {
                if (!string.IsNullOrWhiteSpace(model.Name))
                    category.name = model.Name;
                category.alertMaintance = model.AlertMaintance;
                category.alertRenew = model.AlertRenew;
                category.duration = model.Duration ?? 0f;
                category.maintanceCycle = model.MaintanceCycle ?? 0f;
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<string>> GetDeviceNamesAsync(string term)
        {
            return await _context.Categories
                .Where(c => c.name.Contains(term))
                .Select(c => c.name)
                .ToListAsync();
        }

        public async Task<List<object>> GetAllRealCategoriesAsync()
        {
            return await _context.RealCategories
                .Select(rc => new { rc.idRealCategory, rc.name })
                .ToListAsync<object>();
        }

        // Lấy danh sách các giá trị duy nhất cho dropdown
        public async Task<List<float>> GetUniqueMaintanceCyclesAsync()
        {
            return await _context.Categories
                .Where(c => c.maintanceCycle > 0)
                .Select(c => c.maintanceCycle)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<float>> GetUniqueDurationsAsync()
        {
            return await _context.Categories
                .Where(c => c.duration > 0)
                .Select(c => c.duration)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<double>> GetUniqueAlertMaintancesAsync()
        {
            return await _context.Categories
                .Where(c => c.alertMaintance.HasValue && c.alertMaintance > 0)
                .Select(c => c.alertMaintance.Value)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<double>> GetUniqueAlertRenewsAsync()
        {
            return await _context.Categories
                .Where(c => c.alertRenew.HasValue && c.alertRenew > 0)
                .Select(c => c.alertRenew.Value)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<string>> GetUniqueStatusesAsync()
        {
            return await _context.Items
                .Where(i => !string.IsNullOrEmpty(i.status))
                .Select(i => i.status)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<bool> AddItemAsync(InforItemViewModel model)
        {
            try
            {
                // Xử lý realCategory: chọn hoặc thêm mới
                int idRealCategory = model.idRealCategory;
                if (!string.IsNullOrWhiteSpace(model.NewRealCategory))
                {
                    var newRealCat = new RealCategory { name = model.NewRealCategory };
                    _context.RealCategories.Add(newRealCat);
                    await _context.SaveChangesAsync();
                    idRealCategory = newRealCat.idRealCategory;
                }

                // Tạo mới Category nếu chưa có (theo tên do user nhập)
                var category = await _context.Categories
                    .FirstOrDefaultAsync(c => c.name == model.Name && c.idrealCategory == idRealCategory);

                if (category == null)
                {
                    category = new Category
                    {
                        name = model.Name,
                        idrealCategory = idRealCategory,
                        maintanceCycle = model.MaintanceCycle ?? 0f,
                        duration = model.Duration ?? 0f,
                        alertMaintance = model.AlertMaintance,
                        alertRenew = model.AlertRenew
                    };
                    _context.Categories.Add(category);
                    await _context.SaveChangesAsync();
                }

                // Xử lý ảnh upload: chuyển sang hex
                string imageHex = "No data";
                if (model.ImageFile != null && model.ImageFile.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        await model.ImageFile.CopyToAsync(ms);
                        byte[] imageBytes = ms.ToArray();
                        imageHex = BitConverter.ToString(imageBytes).Replace("-", "");
                    }
                }

                // Helper: nếu null hoặc rỗng thì trả về "No data"
                string NoDataIfNull(string? s) => string.IsNullOrWhiteSpace(s) ? "No data" : s;

                // Tạo mới Item
                var item = new Item
                {
                    idCategory = category.idCategory,
                    image = imageHex,
                    active = true,
                    status = NoDataIfNull(model.Status),
                    receivedDate = DateTime.TryParse(model.receivedDate, out var rd) ? rd : null,
                    activedDate = null,
                    idArea = null,
                    maintanceDate = null,
                    renewDate = null,
                    maintanceRequested = null,
                    po = NoDataIfNull(model.PO),
                    dangKiem = null,
                    type = model.Type ?? 0,
                    comment = NoDataIfNull(model.Comment),
                    serialNumber = NoDataIfNull(model.SerialNumber),
                    contractor = NoDataIfNull(model.Contractor),
                    supplier = NoDataIfNull(model.Supplier)
                };

                _context.Items.Add(item);
                await _context.SaveChangesAsync();

                return true;
            }
            catch
            {
                return false;
            }
        }


    }
}