﻿document.addEventListener("DOMContentLoaded", function () {

    var btnAddDevice = document.getElementById('btnAddDevice');
    var addDeviceModal = document.getElementById('addDeviceModal');
    var closeAddDeviceModal = document.getElementById('closeAddDeviceModal');

    if (btnAddDevice && addDeviceModal && closeAddDeviceModal) {
        // Khi mở modal
        btnAddDevice.onclick = function () {
            document.body.classList.add('modal-open');
            addDeviceModal.style.display = 'flex';

            var form = document.getElementById('addDeviceForm');
            if (form) form.reset();


            var imagePreview = document.getElementById('add_image_preview');
            if (imagePreview) imagePreview.src = '';
            var imageInput = document.getElementById('add_image');
            if (imageInput) imageInput.value = '';
            var typeInput = document.getElementById('add_type');
            if (typeInput) typeInput.value = '';
            var dangKiemInput = document.getElementById('add_dangKiem');
            if (dangKiemInput) dangKiemInput.value = '';
        };
        // Khi đóng modal
        closeAddDeviceModal.onclick = function () {
            document.body.classList.remove('modal-open');
            addDeviceModal.style.display = 'none';
        };
        window.onclick = function (event) {
            if (event.target === addDeviceModal) {
                addDeviceModal.style.display = 'none';
            }
        };
    }

    // Hiển thị alert khi thêm thiết bị thành công/thất bại
    var alertMsg = document.getElementById('alert-message-data');
    if (alertMsg && alertMsg.value) {
        alert(alertMsg.value);
    }

    // Xử lý khi chọn category để tự động fill thông tin
    var categorySelect = document.getElementById('add_category');
    if (categorySelect) {
        categorySelect.addEventListener('change', async function () {
            const categoryId = this.value;
            // Các trường cần fill
            const realCategoryInput = document.getElementById('add_realCategory');
            const idRealCategoryInput = document.getElementById('add_idRealCategory');
            const maintainceCycleInput = document.getElementById('add_maintainceCycle');
            const renewCycleInput = document.getElementById('add_renewCycle');
            const alertMaintainceInput = document.getElementById('add_alertMaintaince');
            const alertRenewInput = document.getElementById('add_alertRenew');
            const durationInput = document.getElementById('add_duration');
            // Các trường lấy từ item
            const imageInput = document.getElementById('add_image');
            const imagePreview = document.getElementById('add_image_preview');
            const typeInput = document.getElementById('add_type');
            const dangKiemInput = document.getElementById('add_dangKiem');

            if (!categoryId) {
                // Xóa dữ liệu nếu chưa chọn
                if (realCategoryInput) realCategoryInput.value = '';
                if (idRealCategoryInput) idRealCategoryInput.value = '';
                if (maintainceCycleInput) maintainceCycleInput.value = '';
                if (renewCycleInput) renewCycleInput.value = '';
                if (alertMaintainceInput) alertMaintainceInput.value = '';
                if (alertRenewInput) alertRenewInput.value = '';
                if (durationInput) durationInput.value = '';
                if (imageInput) imageInput.value = '';
                if (imagePreview) imagePreview.src = '';
                if (typeInput) typeInput.value = '';
                if (dangKiemInput) dangKiemInput.value = '';
                return;
            }
            try {
                const res = await fetch(`/RegisterDevice/GetCategoryInfo?categoryId=${categoryId}`);
                if (!res.ok) {
                    alert('Không lấy được thông tin thiết bị!');
                    return;
                }
                const data = await res.json();
                if (realCategoryInput) realCategoryInput.value = data.realCategoryName || '';
                if (idRealCategoryInput) idRealCategoryInput.value = data.idrealCategory || '';
                if (maintainceCycleInput) maintainceCycleInput.value = data.maintanceCycle || '';
                if (renewCycleInput) renewCycleInput.value = data.renewCycle || data.duration || '';
                if (alertMaintainceInput) alertMaintainceInput.value = data.alertMaintance || '';
                if (alertRenewInput) alertRenewInput.value = data.alertRenew || '';
                if (durationInput) durationInput.value = data.duration || '';
                // Xử lý ảnh hex sang base64 để preview
                if (imageInput) imageInput.value = data.image || '';
                if (imagePreview) {
                    if (data.image && data.image !== "No data") {
                        // Chuyển hex sang base64
                        function hexToBase64(hex) {
                            if (!hex) return "";
                            const bytes = [];
                            for (let c = 0; c < hex.length; c += 2)
                                bytes.push(parseInt(hex.substr(c, 2), 16));
                            return "data:image/png;base64," + btoa(String.fromCharCode.apply(null, bytes));
                        }
                        imagePreview.src = hexToBase64(data.image);
                    } else {
                        imagePreview.src = "";
                    }
                }
                if (typeInput) typeInput.value = data.type === 1 ? "Tài sản cố định" : (data.type === 0 ? "Tài sản log" : "");
                if (dangKiemInput) dangKiemInput.value = data.dangKiem ? data.dangKiem.substring(0, 10) : '';
            } catch (e) {
                alert('Lỗi khi lấy thông tin thiết bị!');
            }
        });
    }
});