﻿document.addEventListener('DOMContentLoaded', function () {

    document.getElementById('addRealCategorySelect').addEventListener('change', function () {
        const otherInput = document.getElementById('addRealCategoryOther');
        if (this.value === 'other') {
            otherInput.style.display = 'block';
        } else {
            otherInput.style.display = 'none';
            otherInput.value = '';
        }
    });

    async function loadAddRealCategories() {
        const res = await fetch('/InforItem/GetAllRealCategories');
        const categories = await res.json();
        const select = document.getElementById('addRealCategorySelect');
        select.innerHTML = '';

        categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.idRealCategory;
            opt.textContent = cat.name;
            select.appendChild(opt);
        });

        // Thêm option Other
        const otherOpt = document.createElement('option');
        otherOpt.value = 'other';
        otherOpt.textContent = 'Other...';
        select.appendChild(otherOpt);
    }
    loadAddRealCategories();

    // --- ADD ITEM: Submit form ---
    document.getElementById('addItemForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        const realCategorySelect = document.getElementById('addRealCategorySelect');
        if (realCategorySelect.value === 'other') {
            formData.set('idRealCategory', '');
            formData.set('NewRealCategory', document.getElementById('addRealCategoryOther').value);
        } else {
            formData.set('idRealCategory', realCategorySelect.value);
            formData.set('NewRealCategory', '');
        }

        fetch('/InforItem/Add', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message || 'Thêm thành công!');
                location.reload();
            })
            .catch(() => alert('Không thể kết nối server!'));
    });

    document.getElementById('addCategoryBtn').addEventListener('click', function () {
        document.getElementById('addPopup').style.display = 'flex';
    });
    document.getElementById('closeAddPopup').addEventListener('click', function () {
        document.getElementById('addPopup').style.display = 'none';
    });

    document.getElementById('searchModelName')?.addEventListener('input', function () {
        const term = this.value;
        if (term.length < 1) return;
        fetch('/InforItem/GetDeviceNames?term=' + encodeURIComponent(term))
            .then(res => res.json())
            .then(data => {
                const datalist = document.getElementById('categoryNameList');
                datalist.innerHTML = '';
                data.forEach(name => {
                    const opt = document.createElement('option');
                    opt.value = name;
                    datalist.appendChild(opt);
                });
            });
    });

    document.getElementById('searchCategoryForm')?.addEventListener('submit', function (e) {
        e.preventDefault();
        const params = new URLSearchParams();
        const nameCategory = document.getElementById('searchModelName').value;
        const maintanceCycle = document.getElementById('searchMaintanceCycle').value;
        const duration = document.getElementById('searchDuration').value;
        const alertMaintance = document.getElementById('searchAlertMaintance').value;
        const alertRenew = document.getElementById('searchAlertRenew').value;
        const status = document.getElementById('searchStatus').value;

        if (nameCategory) params.append('name', nameCategory);
        if (maintanceCycle) params.append('maintanceCycle', maintanceCycle);
        if (duration) params.append('duration', duration);
        if (alertMaintance) params.append('alertMaintance', alertMaintance);
        if (alertRenew) params.append('alertRenew', alertRenew);
        if (status) params.append('status', status);

        window.location.href = '/InforItem?' + params.toString();
    });

    document.getElementById('searchCategoryBtn')?.addEventListener('click', function () {
        document.getElementById('searchCategoryPopup').style.display = 'flex';
    });
    document.getElementById('closeSearchCategoryPopup')?.addEventListener('click', function () {
        document.getElementById('searchCategoryPopup').style.display = 'none';
    });

    document.getElementById('resetFilterBtn')?.addEventListener('click', function () {
        window.location.href = '/InforItem';
    });

    document.getElementById('updateRealCategorySelect').addEventListener('change', function () {
        const otherInput = document.getElementById('updateRealCategoryOther');
        if (this.value === 'other') {
            otherInput.style.display = 'block';
        } else {
            otherInput.style.display = 'none';
            otherInput.value = '';
        }
    });

    document.querySelectorAll('.update-button').forEach(btn => {
        btn.addEventListener('click', function () {
            document.getElementById('updateIdCategory').value = btn.getAttribute('data-idcategory') || '';
            document.getElementById('updateModelName').value = btn.getAttribute('data-name') || '';
            document.getElementById('updatePO').value = btn.getAttribute('data-po') || '';
            document.getElementById('updateType').value = btn.getAttribute('data-type') || '';
            document.getElementById('updateStatus').value = btn.getAttribute('data-status') || '';
            document.getElementById('updateComment').value = btn.getAttribute('data-comment') || '';
            document.getElementById('updateSerialNumber').value = btn.getAttribute('data-serialnumber') || '';
            document.getElementById('updateContractor').value = btn.getAttribute('data-contractor') || '';
            document.getElementById('updateSupplier').value = btn.getAttribute('data-supplier') || '';
            document.getElementById('updateReceivedDate').value = btn.getAttribute('data-receiveddate') || '';
            document.getElementById('updateMaintanceCycle').value = btn.getAttribute('data-maintancecycle') || '';
            document.getElementById('updateDuration').value = btn.getAttribute('data-duration') || '';
            document.getElementById('updateAlertMaintance').value = btn.getAttribute('data-alertmaintance') || '';
            document.getElementById('updateAlertRenew').value = btn.getAttribute('data-alertrenew') || '';

            async function loadUpdateRealCategories(selectedId) {
                const res = await fetch('/InforItem/GetAllRealCategories');
                const categories = await res.json();
                const select = document.getElementById('updateRealCategorySelect');
                select.innerHTML = '';

                categories.forEach(cat => {
                    const opt = document.createElement('option');
                    opt.value = cat.idRealCategory;
                    opt.textContent = cat.name;
                    select.appendChild(opt);
                });
                const otherOpt = document.createElement('option');
                otherOpt.value = 'other';
                otherOpt.textContent = 'Other...';
                select.appendChild(otherOpt);

                if (selectedId) {
                    select.value = selectedId;
                } else {
                    select.selectedIndex = 0;
                }
            }
            loadUpdateRealCategories(btn.getAttribute('data-idrealcategory'));

            document.getElementById('updateRealCategoryOther').style.display = 'none';
            document.getElementById('updateRealCategoryOther').value = '';

            document.getElementById('updatePopup').style.display = 'flex';
        });
    });

    document.getElementById('closePopup').addEventListener('click', function () {
        document.getElementById('updatePopup').style.display = 'none';
    });
});