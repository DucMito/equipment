﻿//using Factory_Equipment_Management.Models;
//using Factory_Equipment_Management.Repository;
//using Factory_Equipment_Management.ViewModel;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;

//namespace Factory_Equipment_Management.Controllers
//{
//    [Authorize(Roles = "Admin,Manager,PIC")]
//    public class RegisterDeviceController : Controller
//    {
//        private readonly RegisterDeviceRepository _repository;
//        private readonly YourDbContext _context;

//        public RegisterDeviceController(RegisterDeviceRepository repository, YourDbContext context)
//        {
//            _repository = repository;
//            _context = context;
//        }

//        public async Task<IActionResult> Index(int page = 1)
//        {
//            int pageSize = 10;
//            var (items, totalCount) = await _repository.GetPagedItemsAsync(page, pageSize);

//            var statusList = await _context.Items
//                .Select(i => i.status)
//                .Distinct()
//                .ToListAsync();

//            // Lấy danh sách RealCategory
//            var realCategories = await _context.RealCategories.ToListAsync();
//            ViewBag.RealCategories = realCategories;

//            ViewBag.CurrentPage = page;
//            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
//            ViewBag.StatusList = statusList;

//            return View("RegisterDevice", items);
//        }

//        [HttpPost]
//        public async Task<IActionResult> Create()
//        {
//            var form = Request.Form;
//            var file = Request.Form.Files["image"];
//            if (file == null || file.Length == 0)
//                return BadRequest(new { success = false, message = "Vui lòng chọn file ảnh." });

//            string imageHex;
//            using (var ms = new MemoryStream())
//            {
//                await file.CopyToAsync(ms);
//                byte[] imageBytes = ms.ToArray();
//                imageHex = BitConverter.ToString(imageBytes).Replace("-", "");
//            }

//            int.TryParse(form["idrealCategory"], out var idrealCategory);

//            // Gán "không có dữ liệu" nếu để trống
//            string GetOrDefault(string value) => string.IsNullOrWhiteSpace(value) ? "" : value;

//            var model = new RegisterDeviceRequestInputModel
//            {
//                name = form["name"],
//                image = imageHex,
//                status = form["status"],
//                po = GetOrDefault(form["po"]),
//                type = int.TryParse(form["type"], out var t) ? t : 0,
//                comment = GetOrDefault(form["comment"]),
//                serialNumber = GetOrDefault(form["serialNumber"]),
//                contractor = GetOrDefault(form["contractor"]),
//                supplier = GetOrDefault(form["supplier"]),
//                idrealCategory = idrealCategory
//            };

//            var success = await _repository.AddItemAndCategoryAsync(model);
//            if (success)
//                return Ok(new { success = true, message = "Thêm thiết bị thành công!" });
//            else
//                return BadRequest(new { success = false, message = "Thêm thiết bị thất bại!" });
//        }
//    }
//}