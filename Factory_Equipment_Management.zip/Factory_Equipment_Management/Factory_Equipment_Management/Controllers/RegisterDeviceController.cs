﻿using Factory_Equipment_Management.Repository;
using Microsoft.AspNetCore.Mvc;
using Factory_Equipment_Management.ViewModel;

public class RegisterDeviceController : Controller
{
    private readonly RegisterDeviceRepository _repository;

    public RegisterDeviceController(RegisterDeviceRepository repository)
    {
        _repository = repository;
    }

    public async Task<IActionResult> Index(int page = 1, int pageSize = 10)
    {
        var pagedResult = await _repository.GetPagedRegisterDeviceRequestsAsync(page, pageSize);
        ViewBag.PageSize = pageSize;
        return View(pagedResult); // Để mặc định, sẽ tìm Index.cshtml
    }
}