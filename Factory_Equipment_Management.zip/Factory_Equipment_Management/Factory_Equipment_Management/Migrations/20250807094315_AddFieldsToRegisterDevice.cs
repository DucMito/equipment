﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Factory_Equipment_Management.Migrations
{
    /// <inheritdoc />
    public partial class AddFieldsToRegisterDevice : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Comment",
                table: "registerdevice",
                type: "longtext",
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AddColumn<string>(
                name: "Contractor",
                table: "registerdevice",
                type: "longtext",
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AddColumn<string>(
                name: "SerialNumber",
                table: "registerdevice",
                type: "longtext",
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AddColumn<string>(
                name: "Supplier",
                table: "registerdevice",
                type: "longtext",
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Comment",
                table: "registerdevice");

            migrationBuilder.DropColumn(
                name: "Contractor",
                table: "registerdevice");

            migrationBuilder.DropColumn(
                name: "SerialNumber",
                table: "registerdevice");

            migrationBuilder.DropColumn(
                name: "Supplier",
                table: "registerdevice");
        }
    }
}
