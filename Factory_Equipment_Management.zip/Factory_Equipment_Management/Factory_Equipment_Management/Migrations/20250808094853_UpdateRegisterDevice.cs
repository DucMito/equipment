﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Factory_Equipment_Management.Migrations
{
    /// <inheritdoc />
    public partial class UpdateRegisterDevice : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_registerdevice_registerdevicerequest_idRegisterDeviceRequest",
                table: "registerdevice");

            migrationBuilder.AlterColumn<int>(
                name: "renewCycle",
                table: "registerdevice",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "realCategoryName",
                table: "registerdevice",
                type: "longtext",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "longtext")
                .Annotation("MySql:CharSet", "utf8mb4")
                .OldAnnotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AlterColumn<int>(
                name: "maintanceCycle",
                table: "registerdevice",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "idRegisterDeviceRequest",
                table: "registerdevice",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "idRealCategory",
                table: "registerdevice",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "alertRenew",
                table: "registerdevice",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "alertMaintance",
                table: "registerdevice",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_registerdevice_registerdevicerequest_idRegisterDeviceRequest",
                table: "registerdevice",
                column: "idRegisterDeviceRequest",
                principalTable: "registerdevicerequest",
                principalColumn: "idRegisterDeviceRequest");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_registerdevice_registerdevicerequest_idRegisterDeviceRequest",
                table: "registerdevice");

            migrationBuilder.AlterColumn<int>(
                name: "renewCycle",
                table: "registerdevice",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "registerdevice",
                keyColumn: "realCategoryName",
                keyValue: null,
                column: "realCategoryName",
                value: "");

            migrationBuilder.AlterColumn<string>(
                name: "realCategoryName",
                table: "registerdevice",
                type: "longtext",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "longtext",
                oldNullable: true)
                .Annotation("MySql:CharSet", "utf8mb4")
                .OldAnnotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AlterColumn<int>(
                name: "maintanceCycle",
                table: "registerdevice",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "idRegisterDeviceRequest",
                table: "registerdevice",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "idRealCategory",
                table: "registerdevice",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "alertRenew",
                table: "registerdevice",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "alertMaintance",
                table: "registerdevice",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_registerdevice_registerdevicerequest_idRegisterDeviceRequest",
                table: "registerdevice",
                column: "idRegisterDeviceRequest",
                principalTable: "registerdevicerequest",
                principalColumn: "idRegisterDeviceRequest",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
