﻿namespace Factory_Equipment_Management.Models
{
    public class PIC
    {
        public int idPIC { get; set; }
        public string name { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public bool accountantPIC { get; set; }

        // Constructor không tham số
        public PIC() { }

        // Constructor có tham số
        public PIC(int idPIC, string name, string username, string password, string email, bool accountantPIC)
        {
            this.idPIC = idPIC;
            this.name = name;
            this.username = username;
            this.password = password;
            this.email = email;
            this.accountantPIC = accountantPIC;
        }
    }
}
