﻿namespace Factory_Equipment_Management.Models
{
    public class CheckHistory
    {
        public int idCheck { get; set; }
        public int idItem { get; set; }
        public int idStaff { get; set; }
        public DateTime dateStart { get; set; }
        public DateTime dateEnd { get; set; }
        public string result { get; set; }
        public string describes { get; set; }
        public byte[] image { get; set; }

        public CheckHistory() { }

        public CheckHistory(int idCheck, int idItem, int idStaff, DateTime dateStart, DateTime dateEnd, string result, string describes, byte[] image)
        {
            this.idCheck = idCheck;
            this.idItem = idItem;
            this.idStaff = idStaff;
            this.dateStart = dateStart;
            this.dateEnd = dateEnd;
            this.result = result;
            this.describes = describes;
            this.image = image;
        }
    }

}
