﻿namespace Factory_Equipment_Management.Models
{
    public class Area
    {
        public int idArea { get; set; }
        public int idWarehouse { get; set; }
        public string name { get; set; }

        public Area() { }

        public Area(int idArea, int idWarehouse, string name)
        {
            this.idArea = idArea;
            this.idWarehouse = idWarehouse;
            this.name = name;
        }
    }
}
