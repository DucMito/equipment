﻿document.addEventListener('DOMContentLoaded', function () {
    var warehouseAreas = window.warehouseAreas || {};
    var selectedWarehouse = window.selectedWarehouse || null;
    var currentUserId = window.currentUserId || null;

    let currentPage = 1;
    const pageSize = 10;
    let currentMode = 'area';

    // --- Thêm hàm cập nhật trạng thái nút chuyển ---
    function updateTransferButtonState() {
        const btn = document.getElementById('btnTransferRequest');
        if (!btn) return;
        if (currentMode === 'new' && window.currentUserRole !== "Admin" && window.currentUserRole !== "Manager") {
            btn.disabled = true;
            btn.title = "Chỉ Admin hoặc Manager mới được chuyển sản phẩm mới!";
        } else {
            btn.disabled = false;
            btn.title = "";
        }
    }

    // Hàm fetch và render thiết bị theo kho/area
    function fetchAndRenderDevices(warehouse, area, page = 1) {
        if (!warehouse || !area) {
            renderDeviceTable([]);
            renderPagination(0, 1, pageSize);
            return;
        }
        fetch(`/ItemTransferRequestArea/GetDevices?warehouse=${encodeURIComponent(warehouse)}&area=${encodeURIComponent(area)}&page=${page}&pageSize=${pageSize}`)
            .then(res => res.json())
            .then(data => {
                renderDeviceTable(data.items);
                renderPagination(data.totalCount, page, pageSize, warehouse, area);
            });
    }

    // Hàm fetch và render sản phẩm mới
    function fetchAndRenderNewProducts(page = 1) {
        fetch(`/ItemTransferRequestArea/GetNewProducts?page=${page}&pageSize=${pageSize}`)
            .then(res => res.json())
            .then(data => {
                renderDeviceTable(data.items);
                renderPagination(data.totalCount, page, pageSize);
            });
    }

    // Render phân trang
    function renderPagination(totalCount, currentPage, pageSize, warehouse, area) {
        const totalPages = Math.ceil(totalCount / pageSize);
        const paginationDiv = document.getElementById('pagination');
        if (!paginationDiv) return;
        paginationDiv.innerHTML = '';

        if (totalPages <= 1) return;

        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement('button');
            btn.textContent = i;
            btn.className = 'btn btn-page' + (i === currentPage ? ' active' : '');
            btn.onclick = () => {
                if (currentMode === 'new') {
                    fetchAndRenderNewProducts(i);
                } else {
                    fetchAndRenderDevices(warehouse, area, i);
                }
            };
            paginationDiv.appendChild(btn);
        }
    }

    // Render area buttons (trên)
    function renderAreaButtons(warehouse) {
        const areaDiv = document.getElementById('area-buttons');
        areaDiv.innerHTML = '';
        if (warehouseAreas[warehouse]) {
            warehouseAreas[warehouse].forEach(function (area, idx) {
                const btn = document.createElement('button');
                btn.className = 'btn btn-tab area-btn' + (idx === 0 ? ' active' : '');
                btn.type = 'button';
                btn.textContent = area;
                btn.setAttribute('data-area', area);
                areaDiv.appendChild(btn);
            });
        }
        // Gắn lại sự kiện click cho area-btn
        document.querySelectorAll('.area-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                document.querySelectorAll('.area-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                // Gọi fetch
                const warehouse = document.querySelector('.warehouse-btn.active')?.getAttribute('data-warehouse');
                const area = this.getAttribute('data-area');
                currentMode = 'area';
                fetchAndRenderDevices(warehouse, area);
                updateTransferButtonState();
            });
        });
    }

    // Render bảng thiết bị
    function renderDeviceTable(devices) {
        const tbody = document.querySelector('.transfer-table tbody');
        tbody.innerHTML = '';
        if (!devices || devices.length === 0) {
            const tr = document.createElement('tr');
            const td = document.createElement('td');
            td.colSpan = 6;
            td.textContent = 'Không có dữ liệu';
            tr.appendChild(td);
            tbody.appendChild(tr);
            return;
        }
        devices.forEach(device => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
            <td>${device.idItem ?? device.id ?? ''}</td>
            <td>${device.deviceType ?? device.name ?? ''}</td>
            <td>${device.imageUrl ? `<img src="${device.imageUrl}" alt="" class="device-img">` : ''}</td>
            <td>${device.status ?? ''}</td>
            <td>${device.activedDate ?? ''}</td>
            <td>
                <input type="checkbox" class="device-select" data-id="${device.idItem ?? device.id}">
            </td>
        `;
            tbody.appendChild(tr);
        });
    }

    // Sự kiện click cho button kho (trên)
    document.querySelectorAll('.warehouse-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.warehouse-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const warehouse = btn.getAttribute('data-warehouse');
            renderAreaButtons(warehouse);
            // KHÔNG renderAreaSelect(warehouse) nữa
            // Chọn area đầu tiên nếu có
            const areaBtn = document.querySelector('.area-btn');
            let area = '';
            if (areaBtn) {
                area = areaBtn.getAttribute('data-area');
            }
            currentMode = 'area';
            fetchAndRenderDevices(warehouse, area);
            updateTransferButtonState();
        });
    });

    // Sự kiện click "Sản phẩm mới"
    document.getElementById('btnNewProducts')?.addEventListener('click', function () {
        currentPage = 1;
        currentMode = 'new';
        // Bỏ active các warehouse-btn và area-btn
        document.querySelectorAll('.warehouse-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.area-btn').forEach(b => b.classList.remove('active'));
        fetchAndRenderNewProducts(currentPage);
        updateTransferButtonState();
    });

    // Sự kiện click "Tạo yêu cầu bàn giao"
    document.getElementById('btnTransferRequest')?.addEventListener('click', function () {
        // Lấy danh sách id sản phẩm được chọn
        const checked = Array.from(document.querySelectorAll('.device-select:checked'));
        if (checked.length === 0) {
            alert('Vui lòng chọn ít nhất một thiết bị!');
            return;
        }
        const itemIds = checked.map(cb => Number(cb.getAttribute('data-id')));
        const reason = document.getElementById('reason').value;
        const warehouse = document.getElementById('warehouse').value;
        const area = document.getElementById('area').value;

        // Lấy fromArea từ button area đang active phía trên
        const fromAreaBtn = document.querySelector('.area-btn.active');
        const fromArea = fromAreaBtn ? fromAreaBtn.getAttribute('data-area') : null;

        // Kiểm tra quyền khi ở chế độ "Sản phẩm mới"
        if (currentMode === 'new') {
            if (window.currentUserRole !== "Admin" && window.currentUserRole !== "Manager") {
                alert('Chỉ Admin hoặc Manager mới được chuyển sản phẩm mới!');
                return;
            }
        }

        const btn = document.getElementById('btnTransferRequest');
        btn.disabled = true;
        btn.textContent = 'Đang gửi...';

        fetch('/ItemTransferRequestArea/CreateTransferRequest', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ItemIds: itemIds,
                Reason: reason,
                Warehouse: warehouse,
                Area: area,
                FromArea: fromArea,
                Sender: currentUserId,
                SenderType: window.currentUserRole // Thêm dòng này
            })
        })
            .then(res => res.ok ? res : res.text().then(msg => Promise.reject(msg)))
            .then(() => {
                alert('Tạo yêu cầu bàn giao thành công!');
                // Bỏ chọn các checkbox
                document.querySelectorAll('.device-select:checked').forEach(cb => cb.checked = false);
            })
            .catch(msg => alert(msg || 'Lỗi tạo yêu cầu bàn giao'))
            .finally(() => {
                btn.disabled = false;
                btn.textContent = 'Yêu cầu chuyển đến';
            });
    });

    // --- XỬ LÝ CHỌN SELECT WAREHOUSE PHÍA DƯỚI ---
    const warehouseSelect = document.getElementById('warehouse');
    const areaSelect = document.getElementById('area');

    if (warehouseSelect && areaSelect) {
        warehouseSelect.addEventListener('change', function () {
            const selected = this.value;
            // Render lại select area phía dưới theo warehouse đã chọn
            areaSelect.innerHTML = '';
            if (warehouseAreas[selected]) {
                warehouseAreas[selected].forEach(function (area) {
                    const option = document.createElement('option');
                    option.value = area;
                    option.textContent = area;
                    areaSelect.appendChild(option);
                });
            }
        });
    }

    // Sau khi đã có window.currentUserRole và window.picWarehouses
    if (window.currentUserRole === "PIC" && Array.isArray(window.picWarehouses)) {
        // Ẩn hoặc disable các warehouse không phụ trách trong select phía dưới
        if (warehouseSelect) {
            Array.from(warehouseSelect.options).forEach(opt => {
                if (!window.picWarehouses.includes(opt.value)) {
                    opt.disabled = true;
                    opt.style.display = "none";
                }
            });
            // Nếu warehouse đang chọn không thuộc quyền, chọn lại warehouse đầu tiên thuộc quyền
            if (!window.picWarehouses.includes(warehouseSelect.value) && window.picWarehouses.length > 0) {
                warehouseSelect.value = window.picWarehouses[0];
                warehouseSelect.dispatchEvent(new Event('change'));
            }
        }

        // Ẩn/disable các warehouse-btn phía trên
        document.querySelectorAll('.warehouse-btn').forEach(btn => {
            if (!window.picWarehouses.includes(btn.getAttribute('data-warehouse'))) {
                btn.disabled = true;
                btn.style.display = "none";
            }
        });
    }

    // Render mặc định khi load trang
    function initialRender() {
        let warehouse = selectedWarehouse;
        if (!warehouse || !warehouseAreas[warehouse]) {
            const firstBtn = document.querySelector('.warehouse-btn');
            if (firstBtn) {
                warehouse = firstBtn.getAttribute('data-warehouse');
                firstBtn.classList.add('active');
            }
        } else {
            // Đánh dấu active cho warehouse-btn tương ứng
            document.querySelectorAll('.warehouse-btn').forEach(function (btn) {
                if (btn.getAttribute('data-warehouse') === warehouse) {
                    btn.classList.add('active');
                }
            });
        }
        renderAreaButtons(warehouse);
        // KHÔNG renderAreaSelect(warehouse) ở đây nữa
        // Chọn area đầu tiên nếu có
        const areaBtn = document.querySelector('.area-btn');
        let area = '';
        if (areaBtn) {
            area = areaBtn.getAttribute('data-area');
        }
        currentMode = 'area';
        fetchAndRenderDevices(warehouse, area);

        // Render select warehouse và area phía dưới theo giá trị mặc định
        if (warehouseSelect && areaSelect) {
            const selected = warehouseSelect.value;
            areaSelect.innerHTML = '';
            if (warehouseAreas[selected]) {
                warehouseAreas[selected].forEach(function (area) {
                    const option = document.createElement('option');
                    option.value = area;
                    option.textContent = area;
                    areaSelect.appendChild(option);
                });
            }
        }
        updateTransferButtonState();
    }

    initialRender();
});