﻿document.addEventListener('DOMContentLoaded', function () {
    // Xử lý filter-btn nếu có
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const status = this.textContent.trim();
            window.location.href = `/RegisterDevice/RegisterDevice?status=${encodeURIComponent(status)}`;
        });
    });

    // Xử lý hiện/ẩn form Add item
    const showAddFormBtn = document.getElementById('showAddForm');
    const addItemForm = document.getElementById('addItemForm');
    const cancelAddFormBtn = document.getElementById('cancelAddForm');

    if (showAddFormBtn && addItemForm && cancelAddFormBtn) {
        showAddFormBtn.onclick = function () {
            addItemForm.style.display = 'block';
        };
        cancelAddFormBtn.onclick = function () {
            addItemForm.style.display = 'none';
        };
    }
});