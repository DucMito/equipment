﻿document.addEventListener('DOMContentLoaded', function () {
    // Lắng nghe sự kiện click trên các nút phân trang
    document.body.addEventListener('click', function (e) {
        if (e.target.classList.contains('page-btn') && e.target.tagName === 'A') {
            e.preventDefault();
            const url = e.target.getAttribute('href');
            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(response => response.text())
                .then(html => {
                    // Tạo một DOM ảo để lấy phần nội dung cần thay thế
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newTable = doc.querySelector('.register-device-table-wrapper');
                    const newPagination = doc.querySelector('.pagination');

                    // Thay thế bảng và phân trang
                    document.querySelector('.register-device-table-wrapper').innerHTML = newTable.innerHTML;
                    document.querySelector('.pagination').innerHTML = newPagination.innerHTML;
                });
        }
    });
});