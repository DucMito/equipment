﻿document.addEventListener("DOMContentLoaded", function () {
    // Xử lý submit form upload ảnh
    const addDeviceForm = document.getElementById('addDeviceForm');
    if (addDeviceForm) {
        addDeviceForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = new FormData(addDeviceForm);

            try {
                const response = await fetch('/RegisterDevice/Create', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                if (result.success) {
                    alert('Gửi yêu cầu thành công!');
                    window.location.reload();
                } else {
                    if (result.errors && Array.isArray(result.errors)) {
                        // Hiển thị lỗi chi tiết
                        const errorMessages = result.errors.map(e => {
                            if (typeof e === "string") return e;
                            if (e.ErrorMessage) return e.ErrorMessage;
                            if (e.Errors && Array.isArray(e.Errors)) {
                                return e.Errors.map(er => er.ErrorMessage || er).join('\n');
                            }
                            return JSON.stringify(e);
                        });
                        alert(errorMessages.join('\n'));
                    } else {
                        alert(result.message || 'Có lỗi xảy ra khi gửi yêu cầu!');
                    }
                }
            } catch (err) {
                alert('Không thể gửi yêu cầu. Vui lòng thử lại!');
                console.log(err);
            }
        });
    }


    // Modal logic
    const openBtn = document.getElementById('openAddDeviceModal');
    const modal = document.getElementById('addDeviceModal');
    const closeBtn = document.getElementById('closeAddDeviceModal');

    if (openBtn && modal && closeBtn) {
        openBtn.addEventListener('click', function () {
            modal.classList.add('active');
        });
        closeBtn.addEventListener('click', function () {
            modal.classList.remove('active');
        });
        // Đóng modal khi click ra ngoài nội dung
        modal.addEventListener('click', function (e) {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    }
});