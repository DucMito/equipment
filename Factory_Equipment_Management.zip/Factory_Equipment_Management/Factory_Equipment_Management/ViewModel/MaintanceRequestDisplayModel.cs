﻿namespace Factory_Equipment_Management.ViewModel
{
    public class MaintanceRequestDisplayModel
    {
        public int idMaintanceRequest { get; set; }
        public DateTime? date { get; set; }
        public string categoryName { get; set; }
        public int? idCategory { get; set; }
        public int? idItem { get; set; }
        public string staffName { get; set; }
        public string status { get; set; }
        public string reason { get; set; }
        public decimal? budgetEstimate { get; set; }
        public string type { get; set; }
        public string image { get; set; }
        public string areaName { get; set; }
        public string warehouseName { get; set; }
        public int? idArea { get; set; }
        public int? idWarehouse { get; set; }
        public string extend { get; set; }
        public string email { get; set; }
        public int? typeCategory { get; set; }
    }
}
