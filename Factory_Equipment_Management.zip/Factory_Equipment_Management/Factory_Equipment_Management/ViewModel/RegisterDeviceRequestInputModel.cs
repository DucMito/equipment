﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Factory_Equipment_Management.ViewModel
{
    public class RegisterDeviceRequestInputModel
    {
        public string Name { get; set; }
        public int Num { get; set; }
        public string ImageHex { get; set; }
        public string Status { get; set; }
        public int Type { get; set; }
        //
        public int? idRegisterDevice { get; set; }
        public string categoryName { get; set; }
        public int idRegisterDeviceRequest { get; set; }
        public int? maintanceCycle { get; set; }
        public int? renewCycle { get; set; }
        public string po { get; set; }
        public int? alertMaintance { get; set; }
        public int? alertRenew { get; set; }
        public DateTime? dangKiem { get; set; }
        public int idRealCategory { get; set; }
        public string realCategoryName { get; set; }
        public string? Contractor { get; set; }
        public string? SerialNumber { get; set; }
        public string? Supplier { get; set; }
        public string? Comment { get; set; }




    }
}