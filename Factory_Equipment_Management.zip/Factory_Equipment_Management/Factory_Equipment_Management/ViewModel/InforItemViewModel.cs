﻿namespace Factory_Equipment_Management.ViewModel
{
    public class InforItemViewModel
    {
        public int? IdCategory { get; set; }
        public string Name { get; set; }
        public string ImageBase64 { get; set; }
        public IFormFile ImageFile { get; set; }

        public string StatusOther { get; set; }
        public float? MaintanceCycle { get; set; }
        public float? Duration { get; set; }
        public double? AlertMaintance { get; set; }
        public double? AlertRenew { get; set; }
        public string serialNumber { get; set; }
        public string receivedDate { get; set; }
        public string supplier { get; set; }
        public int idRealCategory { get; set; }
        public string nameRealCategory { get; set; }

        public int? Type { get; set; } // 1: tài sản cố định, 0: log
        public string NewRealCategory { get; set; } // dùng cho trường hợp chọn Other

        // Các trường mới cho Item
        public string Status { get; set; }
        public string PO { get; set; }
        public string Comment { get; set; }
        public string SerialNumber { get; set; }
        public string Contractor { get; set; }
        public string Supplier { get; set; }
        public string Image { get; set; }
    }
}