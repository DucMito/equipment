﻿//using System.ComponentModel.DataAnnotations;
//using Microsoft.AspNetCore.Http;

//public class RegisterDeviceRequestInputModel
//{

//    public string name { get; set; } // name của bảng category

//    public string image { get; set; }

//    [Required(ErrorMessage = "Vui lòng chọn file ảnh.")]
//    public IFormFile ImageFile { get; set; }


//    public string status { get; set; }

//    public string po { get; set; }

//    public int type { get; set; }

//    public string comment { get; set; }

//    public string serialNumber { get; set; }

//    public string contractor { get; set; }

//    public string supplier { get; set; }

//    // Thêm trường này để chọn RealCategory
//    public int idrealCategory { get; set; }

//}