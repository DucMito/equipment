﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace Factory_Equipment_Management.Repository
{
    public class RegisterDeviceRepository
    {
        private readonly YourDbContext _context;

        public RegisterDeviceRepository(YourDbContext context)
        {
            _context = context;
        }

        public async Task<PagedResult<RegisterDeviceRequestInputModel>> GetPagedRegisterDeviceRequestsAsync(int page, int pageSize)
        {
            var query = from device in _context.RegisterDevice
                        join req in _context.RegisterDeviceRequest
                            on device.idRegisterDeviceRequest equals req.idRegisterDeviceRequest
                        select new RegisterDeviceRequestInputModel
                        {
                            Name = device.name,
                            Num = device.num,
                            ImageHex = device.image,
                            Status = req.status,
                            Type = device.type ? 1 : 0
                        };

            int totalCount = await query.CountAsync();
            int totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            var items = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return new PagedResult<RegisterDeviceRequestInputModel>
            {
                Items = items,
                TotalPages = totalPages,
                CurrentPage = page,
                TotalCount = totalCount
            };
        }
    }
}