﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Drawing.Printing;
using System.Security.Claims;

namespace Factory_Equipment_Management.Repository
{
    public class ManagerDeviceRepository
    {
        private readonly YourDbContext _context;

        public ManagerDeviceRepository(YourDbContext context)
        {
            _context = context;
        }

        public async Task<(List<DeviceDisplayModel> Items, int TotalItems)> GetDevicesAsync(
    int pageNumber, int pageSize, string status = null,
    string deviceName = null, string location = null,
    string comment = null, string serialNumber = null, string supplier = null, string contractor = null,
    int? filterType = null, int? idRealCategory = null, string nameRealCategory = null)
        {
            var query = from item in _context.Items
                        join category in _context.Categories on item.idCategory equals category.idCategory into catJoin
                        from category in catJoin.DefaultIfEmpty()
                        join area in _context.Areas on item.idArea equals area.idArea into areaJoin
                        from area in areaJoin.DefaultIfEmpty()
                        join warehouse in _context.Warehouses on area.idWarehouse equals warehouse.idWarehouse into wareJoin
                        from warehouse in wareJoin.DefaultIfEmpty()
                        join realCategory in _context.RealCategories on category.idrealCategory equals realCategory.idRealCategory into realCatJoin
                        from realCategory in realCatJoin.DefaultIfEmpty()
                        select new { item, category, area, warehouse, realCategory };

            if (!string.IsNullOrEmpty(status))
                query = query.Where(d => d.item.status == status);
            if (!string.IsNullOrEmpty(deviceName))
                query = query.Where(d => d.category != null && d.category.name.Contains(deviceName));
            if (!string.IsNullOrEmpty(location))
                query = query.Where(d => d.area != null && d.area.name.Contains(location));
            if (!string.IsNullOrEmpty(comment))
                query = query.Where(d => d.item.comment != null && d.item.comment.Contains(comment));
            if (!string.IsNullOrEmpty(serialNumber))
                query = query.Where(d => d.item.serialNumber != null && d.item.serialNumber.Contains(serialNumber));
            if (!string.IsNullOrEmpty(supplier))
                query = query.Where(d => d.item.supplier != null && d.item.supplier.Contains(supplier));
            if (!string.IsNullOrEmpty(contractor))
                query = query.Where(d => d.item.contractor != null && d.item.contractor.Contains(contractor));
            if (idRealCategory.HasValue)
                query = query.Where(d => d.realCategory != null && d.realCategory.idRealCategory == idRealCategory.Value);
            if (!string.IsNullOrEmpty(nameRealCategory))
                query = query.Where(d => d.realCategory != null && d.realCategory.name != null && d.realCategory.name.Contains(nameRealCategory));
            if (filterType.HasValue)
                query = query.Where(d => d.item.type == filterType.Value);

            int totalItems = await query.CountAsync();

            var items = await query
    .Skip((pageNumber - 1) * pageSize)
    .Take(pageSize)
    .AsNoTracking()
    .ToListAsync();

            var result = items.Select(d => new DeviceDisplayModel
            {
                idItem = d.item.idItem,
                ItemName = d.category?.name ?? "",
                idCategory = d.item.idCategory ?? 0,
                Name = d.category?.name ?? "",
                CategoryName = d.category?.name ?? "",
                LocationName = d.area?.name ?? "",
                WarehouseName = d.warehouse?.name ?? "",
                image = d.item.image ?? "",
                status = d.item.status ?? "",
                activedDate = d.item.activedDate,
                maintanceDate = d.item.maintanceDate,
                dangKiem = d.item.dangKiem,
                renewDate = d.item.renewDate,
                type = d.item.type,
                Quantity = null,
                IsSelected = false,
                Note = null,
                supplier = d.item.supplier ?? "",
                contractor = d.item.contractor ?? "",
                comment = d.item.comment ?? "",
                serialNumber = d.item.serialNumber ?? "",
                idRealCategory = d.realCategory?.idRealCategory ?? 0,
                nameRealCategory = d.realCategory?.name ?? ""
            }).ToList();

            return (result, totalItems);
        }

        public async Task<bool> ChangeStatusAsync(int id, ClaimsPrincipal user)
        {
            var role = user.Claims.FirstOrDefault(c => c.Type == System.Security.Claims.ClaimTypes.Role)?.Value;
            if (role != "Admin" && role != "Manager") return false;

            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return false;

            item.status = "Dự phòng";
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Item> GetByIdAsync(int? idItem)
        {
            return await _context.Items.FirstOrDefaultAsync(d => d.idItem == idItem);
        }

        public async Task UpdateAsync(Item device)
        {
            _context.Items.Update(device);
            await _context.SaveChangesAsync();
        }

        public static string ImageFileToHex(IFormFile imageFile)
        {
            using (var ms = new MemoryStream())
            {
                imageFile.CopyTo(ms);
                byte[] bytes = ms.ToArray();
                return BitConverter.ToString(bytes).Replace("-", "");
            }
        }

        public async Task<(bool Success, string Message)> UpdateDeviceAsync(IFormCollection form, IFormFile imageFile)
        {
            try
            {
                int idItem = int.Parse(form["idItem"]);
                int idCategory = int.Parse(form["idCategory"]);
                int? idArea = string.IsNullOrEmpty(form["idArea"]) ? null : int.Parse(form["idArea"]);
                string status = form["status"];
                string itemName = form["ItemName"];
                DateTime? activedDate = string.IsNullOrEmpty(form["activedDate"]) ? null : DateTime.Parse(form["activedDate"]);
                DateTime? maintanceDate = string.IsNullOrEmpty(form["maintanceDate"]) ? null : DateTime.Parse(form["maintanceDate"]);
                DateTime? renewDate = string.IsNullOrEmpty(form["renewDate"]) ? null : DateTime.Parse(form["renewDate"]);
                string comment = form["comment"];
                string serialNumber = form["serialNumber"];
                string supplier = form["supplier"];
                string contractor = form["contractor"];

                var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == idItem);
                if (item == null) return (false, "Thiết bị không tồn tại.");

                if (idArea != null && !await _context.Areas.AnyAsync(a => a.idArea == idArea))
                    return (false, "Khu vực không hợp lệ.");

                if (!await _context.Categories.AnyAsync(c => c.idCategory == idCategory))
                    return (false, "Danh mục không hợp lệ.");

                // Xử lý ảnh upload: chỉ lưu hex vào DB
                if (imageFile != null && imageFile.Length > 0)
                {
                    item.image = ImageFileToHex(imageFile);
                }

                // Cập nhật các trường khác
                item.idCategory = idCategory != 0 ? idCategory : item.idCategory;
                item.idArea = idArea.HasValue ? idArea : item.idArea;
                item.status = !string.IsNullOrEmpty(status) ? status : item.status;
                item.po = !string.IsNullOrEmpty(itemName) ? itemName : item.po;
                item.activedDate = activedDate.HasValue ? activedDate : item.activedDate;
                item.maintanceDate = maintanceDate.HasValue ? maintanceDate : item.maintanceDate;
                item.renewDate = renewDate.HasValue ? renewDate : item.renewDate;
                item.comment = comment != null ? (comment == "" ? null : comment) : item.comment;
                item.serialNumber = serialNumber != null ? (serialNumber == "" ? null : serialNumber) : item.serialNumber;
                item.supplier = supplier != null ? (supplier == "" ? null : supplier) : item.supplier;
                item.contractor = contractor != null ? (contractor == "" ? null : contractor) : item.contractor;

                await _context.SaveChangesAsync();
                return (true, "Cập nhật thiết bị thành công!");
            }
            catch (Exception ex)
            {
                return (false, "Lỗi cập nhật: " + ex.Message);
            }
        }

        // Delete items
        public async Task<bool> DeleteDeviceAsync(int id)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return false;
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}