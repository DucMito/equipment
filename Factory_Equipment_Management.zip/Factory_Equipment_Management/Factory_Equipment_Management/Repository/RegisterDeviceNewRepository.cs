﻿//using Factory_Equipment_Management.Models;
//using Factory_Equipment_Management.ViewModel;
//using Microsoft.EntityFrameworkCore;
//using System.Collections.Generic;
//using System.Linq;

//namespace Factory_Equipment_Management.Repository
//{
//    public class RegisterDeviceRepository
//    {
//        private readonly YourDbContext _context;
//        public RegisterDeviceRepository(YourDbContext context)
//        {
//            _context = context;
//        }

//        // Lấy danh sách phân trang, chuyển hex sang base64 để hiển thị
//        public async Task<(List<RegisterDeviceRequestInputModel> Items, int TotalCount)> GetPagedItemsAsync(int page, int pageSize)
//        {
//            var totalCount = await _context.Items.CountAsync();

//            var data = await (from item in _context.Items
//                              join cat in _context.Categories on item.idCategory equals cat.idCategory into gj
//                              from cat in gj.DefaultIfEmpty()
//                              orderby item.idItem descending
//                              select new RegisterDeviceRequestInputModel
//                              {
//                                  name = cat != null ? cat.name : "",
//                                  image = item.image, // hex
//                                  status = item.status,
//                                  po = item.po,
//                                  type = item.type ?? 0,
//                                  comment = item.comment,
//                                  serialNumber = item.serialNumber,
//                                  contractor = item.contractor,
//                                  supplier = item.supplier
//                              })
//                              .Skip((page - 1) * pageSize)
//                              .Take(pageSize)
//                              .ToListAsync();

//            // Chuyển hex sang base64 để hiển thị ảnh
//            foreach (var d in data)
//            {
//                d.image = HexToBase64(d.image);
//            }

//            return (data, totalCount);
//        }

//        // Lưu thiết bị và tạo category nếu chưa có
//        public async Task<bool> AddItemAndCategoryAsync(RegisterDeviceRequestInputModel model)
//        {
//            var category = await _context.Categories.FirstOrDefaultAsync(c => c.name == model.name);
//            if (category == null)
//            {
//                category = new Category
//                {
//                    name = model.name,
//                    idrealCategory = model.idrealCategory, // Gán đúng realCategory
//                                                           // Có thể gán thêm các trường khác nếu cần
//                };
//                _context.Categories.Add(category);
//                await _context.SaveChangesAsync();
//            }

//            var item = new Item
//            {
//                idCategory = category.idCategory,
//                image = model.image, // hex
//                status = model.status,
//                po = model.po,
//                type = model.type,
//                comment = model.comment,
//                serialNumber = model.serialNumber,
//                contractor = model.contractor,
//                supplier = model.supplier
//            };

//            _context.Items.Add(item);
//            await _context.SaveChangesAsync();
//            return true;
//        }

//        // Chuyển hex sang base64 để hiển thị ảnh
//        public static string HexToBase64(string hex)
//        {
//            if (string.IsNullOrEmpty(hex)) return "";
//            byte[] bytes = Enumerable.Range(0, hex.Length)
//                .Where(x => x % 2 == 0)
//                .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
//                .ToArray();
//            return Convert.ToBase64String(bytes);
//        }
//    }
//}