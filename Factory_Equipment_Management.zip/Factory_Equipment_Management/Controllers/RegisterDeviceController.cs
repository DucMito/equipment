﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Factory_Equipment_Management.Controllers
{
    [Authorize(Roles = "Admin,Manager,PIC")]
    public class RegisterDeviceController : Controller
    {
        private readonly RegisterDeviceRepository _repository;
        private readonly YourDbContext _context;

        public RegisterDeviceController(RegisterDeviceRepository repository, YourDbContext context)
        {
            _repository = repository;
            _context = context;
        }

        public IActionResult Index(int page = 1, string status = null)
        {
            int pageSize = 8;
            int totalCount;
            var deviceList = _repository.GetRegisterDeviceList(page, pageSize, out totalCount, status);

            var viewModel = new RegisterDeviceViewModel
            {
                DeviceList = deviceList,
                CurrentPage = page,
                TotalPages = (int)Math.Ceiling((double)totalCount / pageSize)
            };

            // Truyền categories cho view
            var categories = _context.Categories
    .Select(c => new {
        idCategory = c.idCategory,
        name = c.name ?? "" // hoặc ?? "Không xác định"
    })
    .ToList();
            ViewBag.Categories = categories;

            // Truyền realCategories cho view
            var realCategories = _context.RealCategories
                .Select(rc => new { rc.idRealCategory, rc.name })
                .ToList();
            ViewBag.RealCategories = realCategories;

            return View("RegisterDevice", viewModel);
        }

        [HttpGet]
        public async Task<IActionResult> GetCategoryInfo(int categoryId)
        {
            var categoryInfo = await _repository.GetCategoryInfoAsync(categoryId);
            if (categoryInfo == null)
                return NotFound();
            return Json(categoryInfo);
        }


        [HttpPost]
        public IActionResult Create(RegisterDeviceCreateViewModel model)
        {
            var result = _repository.AddRegisterDevice(model);
            if (result)
            {
                TempData["AlertMessage"] = "Thêm thiết bị thành công!";
                TempData["AlertType"] = "success";
                return RedirectToAction("Index");
            }
            TempData["AlertMessage"] = "Thêm thiết bị thất bại!";
            TempData["AlertType"] = "error";
            return RedirectToAction("Index");
        }

    }
}