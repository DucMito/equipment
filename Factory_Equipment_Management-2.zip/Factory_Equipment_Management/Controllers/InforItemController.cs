﻿using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


[Authorize(Roles = "Admin,Manager,PIC")]
public class InforItemController : Controller
{
    private readonly InforItemRepository _repository;

    public InforItemController(InforItemRepository repository)
    {
        _repository = repository;
    }

    [HttpGet]
    public async Task<IActionResult> Index(
    int page = 1, int pageSize = 10,
    string name = null,
    float? maintanceCycle = null,
    float? duration = null,
    double? alertMaintance = null,
    double? alertRenew = null,
    string nameRealCategory = null
)
    {
        var (items, totalCount) = await _repository.GetPagedAsync(
            page, pageSize, name, maintanceCycle, duration, alertMaintance, alertRenew, nameRealCategory);

        ViewBag.CurrentPage = page;
        ViewBag.PageSize = pageSize;
        ViewBag.TotalCount = totalCount;
        return View("~/Views/InforItem.cshtml", items);
    }

    [HttpPost]
    public async Task<IActionResult> Update(InforItemViewModel model)
    {
        // Chỉ cập nhật Category và RealCategory
        var success = await _repository.UpdateCategoryAndRealCategoryAsync(model);
        if (success)
            return Ok(new { message = "Cập nhật thành công!" });
        else
            return BadRequest("Cập nhật thất bại!");
    }

    [HttpGet]
    public async Task<IActionResult> GetDeviceNames(string term, string realCategory)
    {
        var names = await _repository.GetDeviceNamesAsync(term, realCategory);
        return Json(names);
    }

    [HttpGet]
    public async Task<IActionResult> GetAllRealCategories(string term)
    {
        var realCategories = await _repository.GetAllRealCategoriesAsync(term);
        return Json(realCategories);
    }

    [HttpPost]
    public async Task<IActionResult> Add(InforItemViewModel model)
    {
        if (string.IsNullOrWhiteSpace(model.Name))
            return BadRequest(new { message = "Tên model (category) không được để trống." });

        // Chỉ truyền các trường liên quan Category/RealCategory
        var success = await _repository.AddCategoryAndRealCategoryAsync(model);
        if (success)
            return Ok(new { message = "Thêm loại thiết bị thành công!" });
        else
            return BadRequest(new { message = "Thêm loại thiết bị thất bại!" });
    }


    [HttpGet]
    public async Task<IActionResult> GetRealCategoryByModel(string modelName)
    {
        // Lấy realCategory name theo model (category name)
        var realCategory = await _repository.GetRealCategoryNameByModelAsync(modelName);
        return Json(realCategory ?? "");
    }

    //[HttpPost]
    //public async Task<IActionResult> Add(InforItemViewModel model)
    //{
    //    try
    //    {
    //        // Xử lý trạng thái: nếu có StatusOther thì ưu tiên lấy giá trị này
    //        if (!string.IsNullOrWhiteSpace(model.StatusOther))
    //            model.Status = model.StatusOther;

    //        // Xử lý ảnh upload: đã nhận qua model.ImageFile

    //        if (string.IsNullOrWhiteSpace(model.Name))
    //            return BadRequest(new { message = "Tên thiết bị không được để trống." });

    //        var success = await _repository.AddItemAsync(model);
    //        if (success)
    //            return Ok(new { message = "Thêm thiết bị thành công!" });
    //        else
    //            return BadRequest(new { message = "Thêm thiết bị thất bại!" });
    //    }
    //    catch (Exception ex)
    //    {
    //        return StatusCode(500, new { message = ex.ToString() });
    //    }
    //}

    //// Delete items
    //[HttpPost]
    //public async Task<IActionResult> Delete(int idCategory)
    //{
    //    try
    //    {
    //        var success = await _repository.DeleteCategoryAsync(idCategory);
    //        if (success)
    //            return Ok(new { message = "Xóa thành công!" });
    //        else
    //            return BadRequest("Không tìm thấy hoặc xóa thất bại!");
    //    }
    //    catch (Exception ex)
    //    {
    //        // Trả về lỗi chi tiết cho client (chỉ nên làm khi debug)
    //        return StatusCode(500, ex.ToString());
    //    }
    //}
}