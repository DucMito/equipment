﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Factory_Equipment_Management.Controllers
{
    [Authorize]
    public class ManagerDeviceController : Controller
    {
        private readonly ItemDetailRepository _itemDetailRepository;
        private readonly ManagerDeviceRepository _repository;
        private readonly YourDbContext _context;

        public ManagerDeviceController(
            ManagerDeviceRepository repository,
            YourDbContext context,
            ItemDetailRepository itemDetailRepository
        )
        {
            _repository = repository;
            _context = context;
            _itemDetailRepository = itemDetailRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetItemImage(int id)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null || string.IsNullOrEmpty(item.image))
            {
                // Trả về ảnh mặc định nếu không có ảnh
                var defaultPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "no-image.jpg");
                var defaultBytes = System.IO.File.ReadAllBytes(defaultPath);
                return File(defaultBytes, "image/jpeg");
            }

            try
            {
                string hex = item.image.Replace("-", "").Replace(" ", "");
                if (string.IsNullOrEmpty(hex) || hex.Length < 10) // Kiểm tra hex hợp lệ
                {
                    var defaultPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "no-image.jpg");
                    var defaultBytes = System.IO.File.ReadAllBytes(defaultPath);
                    return File(defaultBytes, "image/jpeg");
                }

                if (hex.Length % 2 != 0)
                    hex = "0" + hex;

                int numberChars = hex.Length;
                byte[] bytes = new byte[numberChars / 2];
                for (int i = 0; i < numberChars; i += 2)
                {
                    bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
                }

                return File(bytes, "image/png");
            }
            catch
            {
                var defaultPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "no-image.jpg");
                var defaultBytes = System.IO.File.ReadAllBytes(defaultPath);
                return File(defaultBytes, "image/jpeg");
            }
        }

        //[HttpGet]
        //public async Task<IActionResult> Index(
        //    string status, int pageNumber = 1, int pageSize = 8,
        //    string filterDeviceName = null, string filterLocation = null,
        //    string filterModel = null,
        //    string filterSerialNumber = null,
        //    string filterSupplier = null,
        //    string filterContractor = null,
        //    int? filterType = null)
        //{
        //    var userRole = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value ?? "";
        //    var (items, totalItems) = await _repository.GetDevicesAsync(
        //        pageNumber, pageSize, status,
        //        filterDeviceName, filterLocation,
        //        // filterActivedDate, filterMaintanceDate, filterRenewDate, // Không cần
        //        filterModel, filterSerialNumber, filterSupplier, filterContractor, filterType); ;

        //    // Truyền danh sách kho về ViewBag để render dropdown
        //    ViewBag.Warehouses = await _context.Warehouses.ToListAsync();
        //    ViewBag.Categories = await _context.Categories.ToListAsync();
        //    ViewBag.StatusList = await _context.Items
        //        .Where(i => i.status != null && i.status != "")
        //        .Select(i => i.status)
        //        .Distinct()
        //        .ToListAsync();

        //    var viewModel = new ManagerDeviceViewModel
        //    {
        //        UserRole = userRole,
        //        Items = items,
        //        PageNumber = pageNumber,
        //        PageSize = pageSize,
        //        TotalItems = totalItems,
        //        TotalPages = (int)Math.Ceiling((double)totalItems / pageSize),
        //        FilterDeviceName = filterDeviceName,
        //        FilterLocation = filterLocation,
        //        FilterSerialNumber = filterSerialNumber,
        //        FilterSupplier = filterSupplier,
        //        FilterContractor = filterContractor,
        //        FilterType = filterType
        //    };
        //    return View("ManagerDevice", viewModel);
        //}


        [Authorize(Roles = "Admin,Manager,PIC")]
        [HttpPost]
        public async Task<IActionResult> ChangeStatus(int id)
        {
            var result = await _repository.ChangeStatusAsync(id, User);
            return Json(new { success = result });
        }

        [HttpGet("/ManagerDevice/Detail/{id}")]
        public async Task<IActionResult> Detail(int id)
        {
            var model = await _itemDetailRepository.GetItemDetailAsync(id);
            if (model == null) return NotFound();
            return View("~/Views/ItemDetails.cshtml", model);
        }



        [HttpPost]
        public async Task<IActionResult> ToggleStatus(int id)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return NotFound();

            item.status = item.status == "Hoạt động" ? "Dự phòng" : "Hoạt động";
            await _context.SaveChangesAsync();
            return Json(new { status = item.status });
        }

        [HttpGet]
        public async Task<IActionResult> GetRealCategories()
        {
            var realCategories = await _repository.GetRealCategoriesAsync();
            return Json(realCategories.Select(rc => new { rc.idRealCategory, rc.name }));
        }

        [HttpGet]
        public async Task<IActionResult> GetCategoriesByRealCategory(int idRealCategory)
        {
            var categories = await _repository.GetCategoriesByRealCategoryAsync(idRealCategory);
            return Json(categories.Select(c => new { c.idCategory, c.name }));
        }

        [HttpGet]
        public async Task<IActionResult> GetRealCategoryByCategory(string categoryName)
        {
            if (string.IsNullOrEmpty(categoryName))
                return Json(null);

            var realCategory = await _repository.GetRealCategoryByCategoryNameAsync(categoryName);
            if (realCategory == null)
                return Json(null);

            return Json(new { realCategory.idRealCategory, realCategory.name });
        }


        [HttpGet]
        public async Task<IActionResult> Index(
            string status, int pageNumber = 1, int pageSize = 8,
            string filterDeviceName = null, string filterLocation = null,
            string filterModel = null,
            string filterSerialNumber = null,
            string filterSupplier = null,
            string filterContractor = null,
            int? filterType = null,
            int? filterRealCategory = null)
        {
            var userRole = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value ?? "";
            var (items, totalItems) = await _repository.GetDevicesAsync(
                pageNumber, pageSize, status,
                filterDeviceName, filterLocation,
                filterModel, filterSerialNumber, filterSupplier, filterContractor,
                filterType, filterRealCategory); 
            ViewBag.Warehouses = await _context.Warehouses.ToListAsync();
            ViewBag.Categories = await _context.Categories.ToListAsync();
            ViewBag.RealCategories = await _repository.GetRealCategoriesAsync();
            ViewBag.StatusList = await _context.Items
                .Where(i => i.status != null && i.status != "")
                .Select(i => i.status)
                .Distinct()
                .ToListAsync();

            var viewModel = new ManagerDeviceViewModel
            {
                UserRole = userRole,
                Items = items,
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalItems = totalItems,
                TotalPages = (int)Math.Ceiling((double)totalItems / pageSize),
                FilterDeviceName = filterDeviceName,
                FilterLocation = filterLocation,
                FilterSerialNumber = filterSerialNumber,
                FilterSupplier = filterSupplier,
                FilterContractor = filterContractor,
                FilterType = filterType
            };
            return View("ManagerDevice", viewModel);
        }

    //    public async Task<IActionResult> ManagerDevice(string status, int pageNumber = 1, int pageSize = 8)
    //    {
    //        var userRole = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value ?? "";
    //        var (items, totalItems) = await _repository.GetDevicesAsync(pageNumber, pageSize, status);
    //        ViewBag.Warehouses = await _context.Warehouses.ToListAsync();
    //        //ViewBag.Categories = await _context.Categories.ToListAsync();
    //        ViewBag.Categories = await _context.Categories
    //.Select(c => new {
    //    c.idCategory,
    //    name = c.name ?? ""
    //})
    //.ToListAsync();
    //        ViewBag.StatusList = await _context.Items
    //             .Where(i => i.status != null && i.status != "")
    //             .Select(i => i.status)
    //             .Distinct()
    //             .ToListAsync();
    //        var model = new ManagerDeviceViewModel
    //        {
    //            UserRole = userRole,
    //            Items = items,
    //            PageNumber = pageNumber,
    //            PageSize = pageSize,
    //            TotalItems = totalItems,
    //            TotalPages = (int)Math.Ceiling((double)totalItems / pageSize)
    //        };
    //        return View(model);
    //    }

        [HttpGet]
        public async Task<IActionResult> GetAreasByWarehouse(int idWarehouse)
        {
            var areas = await _context.Areas
                .Where(a => a.idWarehouse == idWarehouse)
                .Select(a => new { a.idArea, a.name })
                .ToListAsync();
            return Json(areas);
        }

        // Controllers\ManagerDeviceController.cs
        [HttpGet]
        public async Task<IActionResult> GetItemDetailJson(int id)
        {
            var item = await _repository.GetByIdAsync(id);
            if (item == null) return NotFound();

            int? idWarehouse = null;
            string realCategoryName = "";

            if (item.idArea != null)
            {
                var area = await _context.Areas.FirstOrDefaultAsync(a => a.idArea == item.idArea);
                idWarehouse = area?.idWarehouse;
            }

            var category = await _context.Categories.FirstOrDefaultAsync(c => c.idCategory == item.idCategory);
            if (category != null)
            {
                var realCategory = await _context.RealCategories.FirstOrDefaultAsync(r => r.idRealCategory == category.idrealCategory);
                if (realCategory != null)
                    realCategoryName = realCategory.name;
            }

            return Json(new
            {
                idItem = item.idItem,
                itemName = item.po,
                status = item.status,
                activedDate = item.activedDate,
                maintanceDate = item.maintanceDate,
                renewDate = item.renewDate,
                idArea = item.idArea,
                idCategory = item.idCategory,
                idWarehouse = idWarehouse,
                comment = item.comment == null ? "" : item.comment,
                serialNumber = item.serialNumber,
                supplier = item.supplier,
                contractor = item.contractor,
                image = item.image,
                realCategoryName = realCategoryName
            });
        }

        [Authorize(Roles = "Admin,Manager,PIC")]
        [HttpPost]
        public async Task<IActionResult> UpdateDevice()
        {
            var form = Request.Form;
            var imageFile = Request.Form.Files["image"];
            var (success, message) = await _repository.UpdateDeviceAsync(form, imageFile);
            return Json(new { success, message });
        }

        [Authorize(Roles = "Admin,Manager,PIC")]
        [HttpPost]
        public async Task<IActionResult> DeleteDevice(int id)
        {
            var result = await _repository.DeleteDeviceAsync(id);
            if (result)
                return Ok();
            return NotFound();
        }


        [Authorize(Roles = "Admin,Manager,PIC")]
        [HttpPost]
        public async Task<IActionResult> CreateMaintanceRequest([FromForm] CreateMaintanceRequestModel model)
        {
            // Xác định idPIC theo role
            var roleClaim = User.Claims.FirstOrDefault(c => c.Type == System.Security.Claims.ClaimTypes.Role)?.Value;
            if (roleClaim == "Admin")
            {
                model.idPIC = 100;
            }
            else if (roleClaim == "Manager")
            {
                model.idPIC = 99;
            }
            else
            {
                var userIdClaim = User.Claims.FirstOrDefault(c => c.Type == System.Security.Claims.ClaimTypes.NameIdentifier);
                if (userIdClaim == null) return Unauthorized();
                model.idPIC = int.Parse(userIdClaim.Value);
            }

            // Xử lý mặc định các trường string
            model.status = "Đang bảo dưỡng";
            model.reason ??= "No data";
            model.type ??= "No data";
            model.reasonManager ??= "No data";
            if (model.date == default) model.date = DateTime.Now;
            if (model.extend == 0) model.extend = 0;

            var (success, message) = await _repository.CreateMaintanceRequestAsync(model);
            return Json(new { success, message });
        }

    }
}