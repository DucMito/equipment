﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Factory_Equipment_Management.Controllers
{
    [Authorize(Roles = "Admin,Manager,PIC")]
    public class RegisterDeviceController : Controller
    {
        private readonly RegisterDeviceRepository _repository;
        private readonly YourDbContext _context;

        public RegisterDeviceController(RegisterDeviceRepository repository, YourDbContext context)
        {
            _repository = repository;
            _context = context;
        }

        public IActionResult Index(int page = 1, string status = null)
        {
            int pageSize = 8;
            int totalCount;
            var deviceList = _repository.GetRegisterDeviceList(page, pageSize, out totalCount, status);

            var viewModel = new RegisterDeviceViewModel
            {
                DeviceList = deviceList,
                CurrentPage = page,
                TotalPages = (int)Math.Ceiling((double)totalCount / pageSize)
            };

            // Truyền categories cho view
            var categories = _context.Categories
    .Select(c => new {
        idCategory = c.idCategory,
        name = c.name ?? "",
        idrealCategory = c.idrealCategory // Thêm dòng này
    })
    .ToList();
            ViewBag.Categories = categories;

            // Truyền realCategories cho view
            var realCategories = _context.RealCategories
                .Select(rc => new { rc.idRealCategory, rc.name })
                .ToList();
            ViewBag.RealCategories = realCategories;

            return View("RegisterDevice", viewModel);
        }

        [HttpGet]
        public async Task<IActionResult> GetCategoryInfo(int categoryId)
        {
            var categoryInfo = await _repository.GetCategoryInfoAsync(categoryId);
            if (categoryInfo == null)
                return NotFound();
            return Json(categoryInfo);
        }


        [HttpGet]
        public async Task<IActionResult> GetCategoriesByRealCategory(int realCategoryId)
        {
            var categories = await _context.Categories
                .Where(c => c.idrealCategory == realCategoryId)
                .Select(c => new { idCategory = c.idCategory, name = c.name })
                .ToListAsync();
            return Json(categories);
        }

        [HttpGet]
        public IActionResult GetRealCategoryByCategoryId(int categoryId)
        {
            var realCategory = _repository.GetRealCategoryByCategoryId(categoryId);
            if (realCategory == null) return NotFound();
            return Json(realCategory);
        }


        [HttpPost]
        public IActionResult Create(RegisterDeviceCreateViewModel model)
        {
            var result = _repository.AddRegisterDevice(model);
            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                if (result)
                    return Json(new { success = true, message = "Thêm thiết bị thành công!" });
                else
                    return Json(new { success = false, message = "Thêm thiết bị thất bại!" });
            }

            if (result)
            {
                TempData["AlertMessage"] = "Thêm thiết bị thành công!";
                TempData["AlertType"] = "success";
                return RedirectToAction("Index");
            }
            TempData["AlertMessage"] = "Thêm thiết bị thất bại!";
            TempData["AlertType"] = "error";
            return RedirectToAction("Index");
        }

    }
}