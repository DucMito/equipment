﻿using Factory_Equipment_Management.DTO.MailDTO;
using Factory_Equipment_Management.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Factory_Equipment_Management.ServiceMail
{
    public class MaintanceReminderService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<MaintanceReminderService> _logger;

        public MaintanceReminderService(IServiceProvider serviceProvider, ILogger<MaintanceReminderService> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using (var scope = _serviceProvider.CreateScope())
                    {
                        var dbContext = scope.ServiceProvider.GetRequiredService<YourDbContext>();
                        var emailService = scope.ServiceProvider.GetRequiredService<IEmailServiceEmail>();

                        var targetDate = DateTime.Today.AddDays(60);

                        var items = await dbContext.Items
                            .Where(i => i.maintanceDate.HasValue && i.maintanceDate.Value.Date == targetDate)
                            .ToListAsync(stoppingToken);

                        foreach (var item in items)
                        {
                            var category = await dbContext.Categories.FindAsync(new object[] { item.idCategory }, cancellationToken: stoppingToken);
                            var realCategory = category != null
                                ? await dbContext.RealCategories.FindAsync(new object[] { category.idrealCategory }, cancellationToken: stoppingToken)
                                : null;

                            var emailContent = $@"
                                    <div style='font-family: Arial, sans-serif; font-size: 14px; color: #333; max-width: 600px; margin: 0 auto;'>
                                        <!-- Header với logo và tiêu đề -->
                                        <div style='background: linear-gradient(135deg, #005baa, #007acc); padding: 25px; text-align: center; border-radius: 10px 10px 0 0;'>
                                            <div style='font-size: 24px; color: white; font-weight: bold; margin-bottom: 5px;'>
                                                🔧 HỆ THỐNG QUẢN LÝ THIẾT BỊ
                                            </div>
                                            <div style='font-size: 18px; color: #e3f2fd; font-weight: 600;'>
                                                ⚠️ THÔNG BÁO NHẮC BẢO DƯỠNG THIẾT BỊ
                                            </div>
                                        </div>

                                        <!-- Nội dung chính -->
                                        <div style='background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; border: 1px solid #e9ecef;'>
                                            <!-- Thông báo khẩn cấp -->
                                            <div style='background: linear-gradient(135deg, #fff3cd, #ffeaa7); border: 2px solid #ffc107; border-radius: 8px; padding: 20px; margin-bottom: 25px; text-align: center;'>
                                                <div style='font-size: 20px; color: #856404; font-weight: bold; margin-bottom: 10px;'>
                                                    🚨 CẢNH BÁO: THIẾT BỊ SẮP ĐẾN HẠN BẢO DƯỠNG
                                                </div>
                                                <div style='font-size: 16px; color: #856404; font-weight: 600;'>
                                                    ⏰ Còn <span style='color: #d32f2f; font-size: 18px; font-weight: bold;'>60 ngày</span> nữa là đến hạn bảo dưỡng định kỳ
                                                </div>
                                            </div>

                                            <!-- Thông tin thiết bị -->
                                            <div style='background: white; border-radius: 8px; padding: 25px; margin-bottom: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
                                                <h3 style='color: #005baa; font-size: 18px; margin-bottom: 20px; border-bottom: 2px solid #005baa; padding-bottom: 10px;'>
                                                    📋 THÔNG TIN CHI TIẾT THIẾT BỊ
                                                </h3>
                                                <table style='border-collapse: collapse; width: 100%; margin-bottom: 16px;'>
                                                    <tr style='background: #f8f9fa;'>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; font-weight: bold; color: #495057; width: 35%;'>🏷️ Danh mục thiết bị</td>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; color: #2c3e50; font-weight: 500;'>{category?.name ?? "N/A"}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; font-weight: bold; color: #495057;'>📂 Danh mục cha</td>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; color: #2c3e50; font-weight: 500;'>{realCategory?.name ?? "N/A"}</td>
                                                    </tr>
                                                    <tr style='background: #f8f9fa;'>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; font-weight: bold; color: #495057;'>🔢 Serial Number</td>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; color: #2c3e50; font-weight: 500; font-family: monospace;'>{item.serialNumber ?? "N/A"}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; font-weight: bold; color: #495057;'>📄 Purchase Order</td>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; color: #2c3e50; font-weight: 500;'>{item.po ?? "N/A"}</td>
                                                    </tr>
                                                    <tr style='background: #f8f9fa;'>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; font-weight: bold; color: #495057;'>👷 Contractor</td>
                                                        <td style='padding: 12px 15px; border: 1px solid #dee2e6; color: #2c3e50; font-weight: 500;'>{item.contractor ?? "N/A"}</td>
                                                    </tr>
                                                </table>
                                            </div>

                                            <!-- Hướng dẫn hành động -->
                                            <div style='background: linear-gradient(135deg, #e3f2fd, #bbdefb); border: 2px solid #2196f3; border-radius: 8px; padding: 20px; margin-bottom: 25px;'>
                                                <h4 style='color: #1565c0; font-size: 16px; margin-bottom: 15px;'>
                                                    📋 HÀNH ĐỘNG CẦN THỰC HIỆN:
                                                </h4>
                                                <ul style='color: #1565c0; margin: 0; padding-left: 20px;'>
                                                    <li style='margin-bottom: 8px;'>✅ Kiểm tra lịch bảo dưỡng định kỳ</li>
                                                    <li style='margin-bottom: 8px;'>✅ Liên hệ nhà cung cấp để lên lịch bảo dưỡng</li>
                                                    <li style='margin-bottom: 8px;'>✅ Chuẩn bị phụ tùng thay thế nếu cần thiết</li>
                                                    <li style='margin-bottom: 8px;'>✅ Cập nhật trạng thái bảo dưỡng trong hệ thống</li>
                                                </ul>
                                            </div>

                                            <!-- Footer -->
                                            <div style='text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef;'>
                                                <div style='color: #6c757d; font-size: 12px; margin-bottom: 10px;'>
                                                    📧 Email này được gửi tự động từ hệ thống quản lý thiết bị
                                                </div>
                                                <div style='color: #495057; font-size: 14px; font-weight: 600;'>
                                                    🔔 Vui lòng không trả lời email này
                                                </div>
                                                <div style='color: #6c757d; font-size: 12px; margin-top: 10px;'>
                                                    ⏰ Thời gian gửi: {DateTime.Now:dd/MM/yyyy HH:mm:ss}
                                                </div>
                                            </div>
                                        </div>
                                    </div>";

                            var emailRequest = new EmailRequestDTO
                            {
                                Subject = "Nhắc bảo dưỡng thiết bị",
                                EmailContent = emailContent,
                                SendTo = new List<string> { "nguyen.van.minh.a3n@ap.denso.com" }
                            };

                            await emailService.SendEmailAsync(emailRequest);
                            _logger.LogInformation("Đã gửi email nhắc bảo dưỡng cho thiết bị: {SerialNumber}", item.serialNumber);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Lỗi khi gửi email nhắc bảo dưỡng");
                }

                // Chờ đến ngày hôm sau (24h)
                await Task.Delay(TimeSpan.FromDays(1), stoppingToken);
            }
        }
    }
}