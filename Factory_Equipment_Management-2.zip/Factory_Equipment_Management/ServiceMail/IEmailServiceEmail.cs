using Factory_Equipment_Management.DTO.MailDTO;

namespace Factory_Equipment_Management.ServiceMail
{
    public interface IEmailServiceEmail
    {
        Task<bool> SendEmailAsync(EmailRequestDTO emailRequest);
    }
}