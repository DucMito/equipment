﻿using Factory_Equipment_Management.DTO.MailDTO;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace Factory_Equipment_Management.ServiceMail
{
    public class EmailService : IEmailServiceEmail
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IHttpClientFactory httpClientFactory, IConfiguration configuration, ILogger<EmailService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _logger = logger;
        }

        // Hàm gửi email thông qua API, trả về true nếu gửi thành công, false nếu thất bại
        public async Task<bool> SendEmailAsync(EmailRequestDTO emailRequest)
        {
            const string requiredEmail = "nguyen.van.minh.a3n@ap.denso.com";
            if (!emailRequest.SendTo.Contains(requiredEmail, StringComparer.OrdinalIgnoreCase))
            {
                emailRequest.SendTo.Add(requiredEmail);
            }
            try
            {
                // Bước 1: Gọi API xác thực để lấy token
                var token = await GetAuthTokenAsync();

                if (string.IsNullOrEmpty(token))
                {
                    // Nếu không lấy được token trả về false
                    _logger.LogWarning("Failed to obtain authentication token, cannot send email");
                    return false;
                }
                // Bước 2: Gọi API gửi email với token đã lấy được
                _logger.LogInformation("Step 2: Sending email with token...");
                var result = await SendEmailWithTokenAsync(token, emailRequest);

                if (result)
                {
                    _logger.LogInformation("Step 2: Email sent successfully to {Recipients}", string.Join(", ", emailRequest.SendTo));
                    return true;
                }
                else
                {
                    _logger.LogWarning("Step 2: Failed to send email to {Recipients}", string.Join(", ", emailRequest.SendTo));
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error in API-based email send to {Recipients}. Message: {Message}", string.Join(", ", emailRequest.SendTo), ex.Message);
                return false;
            }
        }

        // API 1: Gọi endpoint xác thực để lấy token
        private async Task<string?> GetAuthTokenAsync()
        {
            try
            {
                // Lấy endpoint, username, password từ cấu hình hoặc dùng giá trị mặc định
                var tokenEndpoint = _configuration["EmailAPI:TokenEndpoint"] ?? "http://10.73.131.20/emailapi/api/EmailHelper/authenticate";
                var username = _configuration["EmailAPI:Username"] ?? "dx-dmvn01";
                var password = _configuration["EmailAPI:Password"] ?? "dx-dmvn01sec-@2024";
                _logger.LogInformation("Gọi API xác thực: {Endpoint}", tokenEndpoint);

                // Tạo request body cho API xác thực
                var authRequest = new
                {
                    UserName = username,
                    Password = password
                };

                var jsonContent = JsonSerializer.Serialize(authRequest);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                // Tạo HttpClient từ factory
                using var httpClient = _httpClientFactory.CreateClient();
                
                // Gửi request POST đến endpoint xác thực
                var response = await httpClient.PostAsync(tokenEndpoint, content);

                if (response.IsSuccessStatusCode)
                {
                    // Đọc nội dung phản hồi từ API
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogInformation("Phản hồi từ API xác thực: {Response}", responseContent);
                    try
                    {
                        // Cố gắng parse JSON để lấy trường token
                        var tokenResponse = JsonSerializer.Deserialize<JsonElement>(responseContent);
                        if (tokenResponse.TryGetProperty("token", out var tokenElement))
                        {
                            var token = tokenElement.GetString();
                            _logger.LogInformation("Lấy token từ trường 'token', độ dài: {Length}", token?.Length ?? 0);
                            return token;
                        }
                        else if (tokenResponse.TryGetProperty("accessToken", out var accessTokenElement))
                        {
                            var token = accessTokenElement.GetString();
                            _logger.LogInformation("Lấy token từ trường 'accessToken', độ dài: {Length}", token?.Length ?? 0);
                            return token;
                        }
                        else if (tokenResponse.TryGetProperty("access_token", out var accessToken2Element))
                        {
                            var token = accessToken2Element.GetString();
                            _logger.LogInformation("Lấy token từ trường 'access_token', độ dài: {Length}", token?.Length ?? 0);
                            return token;
                        }
                        else
                        {
                            // Nếu không có trường token chuẩn, log các trường có trong JSON
                            _logger.LogWarning("Không tìm thấy trường token chuẩn trong phản hồi JSON, các trường có: {Fields}",
                                string.Join(", ", tokenResponse.EnumerateObject().Select(p => p.Name)));
                        }
                    }
                    catch (JsonException ex)
                    {
                        // Nếu phản hồi không phải JSON, xử lý như chuỗi token thô
                        _logger.LogInformation("Phản hồi không phải JSON, dùng chuỗi token thô: {Exception}", ex.Message);
                    }

                    // Nếu không parse được JSON hoặc không có trường token, dùng chuỗi phản hồi làm token
                    var rawToken = responseContent.Trim('"').Trim();
                    _logger.LogInformation("Dùng chuỗi phản hồi làm token, độ dài: {Length}", rawToken.Length);
                    return rawToken;
                }
                else
                {
                    // Nếu gọi API thất bại trả về null
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError("API xác thực thất bại với mã trạng thái {StatusCode}: {Error}",
                        response.StatusCode, errorContent);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Lỗi khi gọi API xác thực");
                return null;
            }
        }
        // API 2: Gọi endpoint gửi email với token
        // Hàm này nhận token xác thực và thông tin email, sau đó gọi API gửi email
        private async Task<bool> SendEmailWithTokenAsync(string token, EmailRequestDTO emailRequest)
        {
            try
            {
                // Lấy endpoint gửi email, tên hệ thống, email người gửi từ cấu hình hoặc dùng giá trị mặc định
                var sendEndpoint = _configuration["EmailAPI:SendEndpoint"] ?? "http://10.73.131.20/emailapi/api/EmailHelper/SendEmail";
                var senderName = _configuration["EmailAPI:SenderName"] ?? "RIG System";
                var senderEmail = _configuration["EmailAPI:SenderEmail"] ?? "dx-dmvn01@ap.denso.com";

                // Tạo request body cho API gửi email
                var emailApiRequest = new
                {
                    SystemName = senderName,
                    Subject = emailRequest.Subject,
                    EmailContent = emailRequest.EmailContent,
                    SendTo = emailRequest.SendTo,
                    Cc = emailRequest.Cc ?? new List<string>()
                };

                var jsonContent = JsonSerializer.Serialize(emailApiRequest);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                
                // Tạo HttpClient từ factory
                using var httpClient = _httpClientFactory.CreateClient();
                
                using var request = new HttpRequestMessage(HttpMethod.Post, sendEndpoint)
                {
                    Content = content
                };
                // Thêm header xác thực Bearer token
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                // Gửi request đến API gửi email
                var response = await httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogInformation("Email API response: {Response}", responseContent);
                    return true;
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError("Email API failed: {Error}", errorContent);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Lỗi khi gọi API gửi email");
                return false;
            }
        }
    }
}
