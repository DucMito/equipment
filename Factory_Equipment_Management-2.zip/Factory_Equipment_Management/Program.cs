﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ServiceMail;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<YourDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("DefaultConnection"))
    )
);

builder.Services.AddScoped<RegisterDeviceRepository>();
builder.Services.AddScoped<HomeRepository>();
builder.Services.AddScoped<AdminRepository>();
builder.Services.AddScoped<ManagerDeviceRepository>();
builder.Services.AddScoped<ItemTransferRequestAreaRepository>();
builder.Services.AddScoped<ItemDetailRepository>();
builder.Services.AddScoped<InforItemRepository>();

// Chỉ cần cấu hình session 1 lần, set timeout 60 phút
builder.Services.AddSession(options => {
    options.IdleTimeout = TimeSpan.FromMinutes(60);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Chỉ cần cấu hình ControllersWithViews 1 lần
builder.Services.AddControllersWithViews()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    });

// Cookie authentication timeout 60 phút
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(60);
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.Cookie.SameSite = SameSiteMode.Strict;
    });

builder.Services.AddHostedService<Factory_Equipment_Management.ServiceMail.MaintanceReminderService>();
builder.Services.AddScoped<IEmailServiceEmail, EmailService>();
builder.Services.AddHttpClient();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.MapControllers();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

// Bật session middleware
app.UseSession();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(name: "default", pattern: "{controller=Account}/{action=Login}/{id?}");
app.MapControllerRoute(name: "managerDevice", pattern: "{controller=ManagerDevice}/{action=ManagerDevice}/{id?}");
app.MapControllerRoute(name: "account", pattern: "{controller=Account}/{action=Login}/{id?}");
app.MapControllerRoute(name: "home", pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapControllerRoute(name: "managerItemAdmin", pattern: "{controller=ManagerItemAdmin}/{action=Index}/{id?}");
app.MapControllerRoute(name: "admin", pattern: "{controller=Admin}/{action=Index}/{id?}");
app.MapControllerRoute(name: "registerDeviceCreate", pattern: "RegisterDevice/Create", defaults: new { controller = "RegisterDevice", action = "Create" });

app.Run();