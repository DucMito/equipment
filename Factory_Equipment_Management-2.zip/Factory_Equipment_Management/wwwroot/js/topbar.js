﻿document.addEventListener("DOMContentLoaded", function () {
    const sideMenu = document.getElementById("sideMenu");
    const userBtn = document.querySelector('.topbar-right .user');
    const modal = document.getElementById('userInfoModal');
    const userInfoContent = document.getElementById('userInfoContent');
    const closeBtn = document.getElementById('closeUserInfoModal');
    const logo = document.getElementById('menuToggle'); // Đúng id logo

    // KHÔNG tự động mở menu khi tải trang
    if (sideMenu) {
        sideMenu.classList.remove("open");
    }

    // Toggle side menu khi bấm vào logo
    if (logo && sideMenu) {
        logo.addEventListener('click', function () {
            sideMenu.classList.toggle("open");
        });
    }

    // Đóng menu khi click vào các link trong menu
    if (sideMenu) {
        sideMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', function () {
                sideMenu.classList.remove("open");
            });
        });
    }

    // Hàm hiển thị thông tin người dùng
    function showUserInfoModal() {
        fetch('/Account/UserInfo')
            .then(res => res.json())
            .then(data => {
                if (data.error) {
                    userInfoContent.innerHTML = `<p style="color:red">${data.error}</p>`;
                } else {
                    userInfoContent.innerHTML = `
                        <p><b>Họ tên:</b> ${data.name}</p>
                        <p><b>Tên đăng nhập:</b> ${data.username}</p>
                        <p><b>Email:</b> ${data.email}</p>
                        <p><b>Quyền:</b> ${data.role}</p>
                    `;
                }
                modal.classList.add('show');
            });
    }

    // Gán sự kiện click cho nút người dùng
    if (userBtn) {
        userBtn.addEventListener('click', showUserInfoModal);
    }

    // Gán sự kiện đóng modal
    if (closeBtn) {
        closeBtn.onclick = function () {
            modal.classList.remove('show');
        }
    }

    // Đóng modal khi click ra ngoài
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.classList.remove('show');
        }
    }
});