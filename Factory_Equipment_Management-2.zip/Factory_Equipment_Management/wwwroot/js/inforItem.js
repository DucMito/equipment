﻿//document.addEventListener('DOMContentLoaded', function () {
//    document.getElementById('addRealCategorySelect').addEventListener('change', function () {
//        const otherInput = document.getElementById('addRealCategoryOther');
//        if (this.value === 'other') {
//            otherInput.style.display = 'block';
//        } else {
//            otherInput.style.display = 'none';
//            otherInput.value = '';
//        }
//    });

//    async function loadAddRealCategories() {
//        const res = await fetch('/InforItem/GetAllRealCategories');
//        const categories = await res.json();
//        const select = document.getElementById('addRealCategorySelect');
//        select.innerHTML = '';

//        categories.forEach(cat => {
//            const opt = document.createElement('option');
//            opt.value = cat.idRealCategory;
//            opt.textContent = cat.name;
//            select.appendChild(opt);
//        });

//        // Thêm option Other
//        const otherOpt = document.createElement('option');
//        otherOpt.value = 'other';
//        otherOpt.textContent = 'Other...';
//        select.appendChild(otherOpt);
//    }
//    loadAddRealCategories();

//    // --- ADD ITEM
//    document.getElementById('addItemForm').addEventListener('submit', function (e) {
//        e.preventDefault();
//        const formData = new FormData(this);

//        const realCategorySelect = document.getElementById('addRealCategorySelect');
//        if (realCategorySelect.value === 'other') {
//            formData.set('idRealCategory', '');
//            formData.set('NewRealCategory', document.getElementById('addRealCategoryOther').value);
//        } else {
//            formData.set('idRealCategory', realCategorySelect.value);
//            formData.set('NewRealCategory', '');
//        }

//        fetch('/InforItem/Add', {
//            method: 'POST',
//            body: formData
//        })
//            .then(res => res.json())
//            .then(data => {
//                alert(data.message || 'Thêm thành công!');
//                location.reload();
//            })
//            .catch(() => alert('Không thể kết nối server!'));
//    });

//    document.getElementById('addCategoryBtn').addEventListener('click', function () {
//        document.getElementById('addPopup').style.display = 'flex';
//    });
//    document.getElementById('closeAddPopup').addEventListener('click', function () {
//        document.getElementById('addPopup').style.display = 'none';
//    });


//    $(document).ready(function () {
//        // Load RealCategory cho select2
//        $('#searchRealCategorySelect').select2({
//            placeholder: 'Chọn hoặc tìm Category...',
//            ajax: {
//                url: '/InforItem/GetAllRealCategories',
//                dataType: 'json',
//                processResults: function (data) {
//                    return {
//                        results: data.map(function (cat) {
//                            return { id: cat.name, text: cat.name, realCategoryId: cat.idRealCategory };
//                        })
//                    };
//                },
//                cache: true
//            },
//            allowClear: true,
//            width: '100%'
//        });



//        // Sửa lại hàm khởi tạo select2 cho Model
//        function initModelSelect2() {
//            $('#searchModelSelect').select2({
//                placeholder: 'Chọn hoặc tìm model...',
//                ajax: {
//                    url: '/InforItem/GetDeviceNames',
//                    dataType: 'json',
//                    delay: 250,
//                    data: function (params) {
//                        var realCategory = $('#searchRealCategorySelect').val() || '';
//                        return { term: params.term || '', realCategory: realCategory };
//                    },
//                    processResults: function (data) {
//                        return {
//                            results: data.map(function (name) {
//                                return { id: name, text: name };
//                            })
//                        };
//                    },
//                    cache: true
//                },
//                allowClear: true,
//                width: '100%'
//            });
//        }

//        // Khởi tạo lần đầu
//        initModelSelect2();

//        // Khi chọn lại Category, khởi tạo lại select2 cho Model
//        $('#searchRealCategorySelect').on('change', function () {
//            $('#searchModelSelect').val(null).trigger('change').off().select2('destroy');
//            initModelSelect2();
//        });

//        // Khi clear Model, reset luôn Category
//        $('#searchModelSelect').on('select2:clear', function () {
//            $('#searchRealCategorySelect').val(null).trigger('change');
//        });

//        // Model select2, sẽ filter theo realCategory nếu có
//        //function initModelSelect2(realCategoryName) {
//        //    $('#searchModelSelect').select2({
//        //        placeholder: 'Chọn hoặc tìm model...',
//        //        ajax: {
//        //            url: '/InforItem/GetDeviceNames',
//        //            dataType: 'json',
//        //            delay: 250,
//        //            data: function (params) {
//        //                // Gửi thêm realCategoryName để server lọc
//        //                return { term: params.term || '', realCategory: realCategoryName || '' };
//        //            },
//        //            processResults: function (data) {
//        //                return {
//        //                    results: data.map(function (name) {
//        //                        return { id: name, text: name };
//        //                    })
//        //                };
//        //            },
//        //            cache: true
//        //        },
//        //        allowClear: true,
//        //        width: '100%'
//        //    });
//        //}
//        //initModelSelect2();

//        //$('#searchRealCategorySelect').on('change', function () {
//        //    var realCategoryName = $(this).val() || '';
//        //    $('#searchModelSelect').val(null).trigger('change').off().select2('destroy');
//        //    initModelSelect2(realCategoryName);
//        //});

//        $('#searchModelSelect').on('select2:select', function (e) {
//            var modelName = e.params.data.id;
//            var modelText = e.params.data.text;
//            // Gọi API lấy realCategory theo model
//            $.get('/InforItem/GetRealCategoryByModel', { modelName: modelName }, function (realCategoryName) {
//                if (realCategoryName) {
//                    var $realCategorySelect = $('#searchRealCategorySelect');
//                    // Đảm bảo option tồn tại
//                    var exists = $realCategorySelect.find("option[value='" + realCategoryName + "']").length > 0;
//                    if (!exists) {
//                        var option = new Option(realCategoryName, realCategoryName, true, true);
//                        $realCategorySelect.append(option);
//                    }
//                    $realCategorySelect.val(realCategoryName).trigger('change');
//                }
//                // Đảm bảo option model vẫn tồn tại và được chọn
//                var $modelSelect = $('#searchModelSelect');
//                var existsModel = $modelSelect.find("option[value='" + modelName + "']").length > 0;
//                if (!existsModel) {
//                    var optionModel = new Option(modelText, modelName, true, true);
//                    $modelSelect.append(optionModel);
//                }
//                $modelSelect.val(modelName).trigger('change.select2');
//            });
//        });

//        document.getElementById('resetSearchBtn')?.addEventListener('click', function () {
//            window.location.href = '/InforItem';
//        });

//        document.getElementById('resetBtn')?.addEventListener('click', function () {
//            // Reset select2 fields
//            if (window.jQuery) {
//                $('#searchRealCategorySelect').val(null).trigger('change');
//                $('#searchModelSelect').val(null).trigger('change');
//            } else {
//                document.getElementById('searchRealCategorySelect').value = '';
//                document.getElementById('searchModelSelect').value = '';
//            }

//            // Reset input fields
//            document.getElementById('searchMaintanceCycle').value = '';
//            document.getElementById('searchDuration').value = '';
//            document.getElementById('searchAlertMaintance').value = '';
//            document.getElementById('searchAlertRenew').value = '';
//        });


//        document.getElementById('searchCategoryForm')?.addEventListener('submit', function (e) {
//            e.preventDefault();
//            const params = new URLSearchParams();
//            const nameCategory = $('#searchModelSelect').val();
//            const realCategoryName = $('#searchRealCategorySelect').val();
//            const maintanceCycle = document.getElementById('searchMaintanceCycle').value;
//            const duration = document.getElementById('searchDuration').value;
//            const alertMaintance = document.getElementById('searchAlertMaintance').value;
//            const alertRenew = document.getElementById('searchAlertRenew').value;

//            if (nameCategory) params.append('name', nameCategory);
//            if (realCategoryName) params.append('nameRealCategory', realCategoryName);
//            if (maintanceCycle) params.append('maintanceCycle', maintanceCycle);
//            if (duration) params.append('duration', duration);
//            if (alertMaintance) params.append('alertMaintance', alertMaintance);
//            if (alertRenew) params.append('alertRenew', alertRenew);

//            window.location.href = '/InforItem?' + params.toString();
//        });
//    });

//    document.getElementById('searchCategoryBtn')?.addEventListener('click', function () {
//        document.getElementById('searchCategoryPopup').style.display = 'flex';
//    });
//    document.getElementById('closeSearchCategoryPopup')?.addEventListener('click', function () {
//        document.getElementById('searchCategoryPopup').style.display = 'none';
//    });

//    // update
//    document.querySelectorAll('.update-button').forEach(btn => {
//        btn.addEventListener('click', function () {
//            document.getElementById('updateIdCategory').value = btn.getAttribute('data-idcategory') || '';
//            document.getElementById('updateModelName').value = btn.getAttribute('data-name') || '';
//            document.getElementById('updateMaintanceCycle').value = btn.getAttribute('data-maintancecycle') || '';
//            document.getElementById('updateDuration').value = btn.getAttribute('data-duration') || '';
//            document.getElementById('updateAlertMaintance').value = btn.getAttribute('data-alertmaintance') || '';
//            document.getElementById('updateAlertRenew').value = btn.getAttribute('data-alertrenew') || '';

//            fetch('/InforItem/GetAllRealCategories')
//                .then(res => res.json())
//                .then(categories => {
//                    const select = document.getElementById('updateRealCategorySelect');
//                    select.innerHTML = '';
//                    categories.forEach(cat => {
//                        const opt = document.createElement('option');
//                        opt.value = cat.idRealCategory;
//                        opt.textContent = cat.name;
//                        select.appendChild(opt);
//                    });
//                    // Thêm option Other
//                    const otherOpt = document.createElement('option');
//                    otherOpt.value = 'other';
//                    otherOpt.textContent = 'Other...';
//                    select.appendChild(otherOpt);

//                    // Set selected value
//                    select.value = btn.getAttribute('data-idrealcategory') || '';
//                });

//            document.getElementById('updateRealCategoryOther').style.display = 'none';
//            document.getElementById('updateRealCategoryOther').value = '';

//            document.getElementById('updatePopup').style.display = 'flex';
//        });
//    });

//    // Xử lý submit form cập nhật (chỉ gửi các trường Category/RealCategory)
//    document.getElementById('updateForm')?.addEventListener('submit', function (e) {
//        e.preventDefault();
//        const form = this;
//        const formData = new FormData(form);

//        const realCategorySelect = document.getElementById('updateRealCategorySelect');
//        if (realCategorySelect.value === 'other') {
//            formData.set('idRealCategory', '');
//            formData.set('NewRealCategory', document.getElementById('updateRealCategoryOther').value);
//        } else {
//            formData.set('idRealCategory', realCategorySelect.value);
//            formData.set('NewRealCategory', '');
//        }

//        fetch('/InforItem/Update', {
//            method: 'POST',
//            body: formData
//        })
//            .then(res => res.json())
//            .then(data => {
//                alert(data.message || 'Cập nhật thành công!');
//                location.reload();
//            })
//            .catch(() => alert('Không thể kết nối server!'));
//    });


//    document.getElementById('closePopup')?.addEventListener('click', function () {
//        document.getElementById('updatePopup').style.display = 'none';
//    });
//});


document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('addRealCategorySelect').addEventListener('change', function () {
        const otherInput = document.getElementById('addRealCategoryOther');
        if (this.value === 'other') {
            otherInput.style.display = 'block';
        } else {
            otherInput.style.display = 'none';
            otherInput.value = '';
        }
    });

    async function loadAddRealCategories() {
        const res = await fetch('/InforItem/GetAllRealCategories');
        const categories = await res.json();
        const select = document.getElementById('addRealCategorySelect');
        select.innerHTML = '';

        categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.idRealCategory;
            opt.textContent = cat.name;
            select.appendChild(opt);
        });

        // Thêm option Other
        const otherOpt = document.createElement('option');
        otherOpt.value = 'other';
        otherOpt.textContent = 'Other...';
        select.appendChild(otherOpt);
    }
    loadAddRealCategories();

    // --- ADD ITEM
    document.getElementById('addItemForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        const realCategorySelect = document.getElementById('addRealCategorySelect');
        if (realCategorySelect.value === 'other') {
            formData.set('idRealCategory', '');
            formData.set('NewRealCategory', document.getElementById('addRealCategoryOther').value);
        } else {
            formData.set('idRealCategory', realCategorySelect.value);
            formData.set('NewRealCategory', '');
        }

        fetch('/InforItem/Add', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message || 'Thêm thành công!');
                location.reload();
            })
            .catch(() => alert('Không thể kết nối server!'));
    });

    document.getElementById('addCategoryBtn').addEventListener('click', function () {
        document.getElementById('addPopup').style.display = 'flex';
    });
    document.getElementById('closeAddPopup').addEventListener('click', function () {
        document.getElementById('addPopup').style.display = 'none';
    });

    $(document).ready(function () {
        // Load RealCategory cho select2
        $('#searchRealCategorySelect').select2({
            placeholder: 'Chọn hoặc tìm Category...',
            ajax: {
                url: '/InforItem/GetAllRealCategories',
                dataType: 'json',
                processResults: function (data) {
                    return {
                        results: data.map(function (cat) {
                            return { id: cat.name, text: cat.name, realCategoryId: cat.idRealCategory };
                        })
                    };
                },
                cache: true
            },
            allowClear: true,
            width: '100%'
        });

        // Hàm khởi tạo Model Select2 với sự kiện
        function initModelSelect2() {
            // Destroy select2 cũ nếu có
            if ($('#searchModelSelect').hasClass('select2-hidden-accessible')) {
                $('#searchModelSelect').select2('destroy');
            }

            // Khởi tạo Select2 mới
            $('#searchModelSelect').select2({
                placeholder: 'Chọn hoặc tìm model...',
                ajax: {
                    url: '/InforItem/GetDeviceNames',
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        var realCategory = $('#searchRealCategorySelect').val() || '';
                        return { term: params.term || '', realCategory: realCategory };
                    },
                    processResults: function (data) {
                        return {
                            results: data.map(function (name) {
                                return { id: name, text: name };
                            })
                        };
                    },
                    cache: true
                },
                allowClear: true,
                width: '100%'
            });

            // GÁN SỰ KIỆN select2:select SAU KHI KHỞI TẠO
            $('#searchModelSelect').off('select2:select').on('select2:select', function (e) {
                var modelName = e.params.data.id;
                var modelText = e.params.data.text;

                console.log('Model selected:', modelName); // Debug log

                $.get('/InforItem/GetRealCategoryByModel', { modelName: modelName }, function (realCategoryName) {
                    console.log('API response:', realCategoryName); // Debug log

                    if (realCategoryName) {
                        var $realCategorySelect = $('#searchRealCategorySelect');
                        var exists = $realCategorySelect.find("option[value='" + realCategoryName + "']").length > 0;
                        if (!exists) {
                            var option = new Option(realCategoryName, realCategoryName, true, true);
                            $realCategorySelect.append(option);
                        }
                        $realCategorySelect.val(realCategoryName).trigger('change');
                    }

                    // Đảm bảo Model vẫn được chọn
                    var $modelSelect = $('#searchModelSelect');
                    var existsModel = $modelSelect.find("option[value='" + modelName + "']").length > 0;
                    if (!existsModel) {
                        var optionModel = new Option(modelText, modelName, true, true);
                        $modelSelect.append(optionModel);
                    }
                    $modelSelect.val(modelName).trigger('change.select2');
                }).fail(function () {
                    console.error('API call failed'); // Debug log
                });
            });

            // Gán sự kiện clear
            $('#searchModelSelect').off('select2:clear').on('select2:clear', function () {
                $('#searchRealCategorySelect').val(null).trigger('change');
            });
        }

        // Khởi tạo lần đầu
        initModelSelect2();

        // Khi chọn lại Category, khởi tạo lại Model Select2
        $('#searchRealCategorySelect').on('change', function () {
            $('#searchModelSelect').val(null);
            initModelSelect2(); // Gọi lại hàm khởi tạo
        });

        // Reset buttons
        document.getElementById('resetSearchBtn')?.addEventListener('click', function () {
            window.location.href = '/InforItem';
        });

        document.getElementById('resetBtn')?.addEventListener('click', function () {
            if (window.jQuery) {
                $('#searchRealCategorySelect').val(null).trigger('change');
                $('#searchModelSelect').val(null).trigger('change');
            } else {
                document.getElementById('searchRealCategorySelect').value = '';
                document.getElementById('searchModelSelect').value = '';
            }

            // Reset input fields
            document.getElementById('searchMaintanceCycle').value = '';
            document.getElementById('searchDuration').value = '';
            document.getElementById('searchAlertMaintance').value = '';
            document.getElementById('searchAlertRenew').value = '';
        });

        // Submit form search
        document.getElementById('searchCategoryForm')?.addEventListener('submit', function (e) {
            e.preventDefault();
            const params = new URLSearchParams();
            const nameCategory = $('#searchModelSelect').val();
            const realCategoryName = $('#searchRealCategorySelect').val();
            const maintanceCycle = document.getElementById('searchMaintanceCycle').value;
            const duration = document.getElementById('searchDuration').value;
            const alertMaintance = document.getElementById('searchAlertMaintance').value;
            const alertRenew = document.getElementById('searchAlertRenew').value;

            if (nameCategory) params.append('name', nameCategory);
            if (realCategoryName) params.append('nameRealCategory', realCategoryName);
            if (maintanceCycle) params.append('maintanceCycle', maintanceCycle);
            if (duration) params.append('duration', duration);
            if (alertMaintance) params.append('alertMaintance', alertMaintance);
            if (alertRenew) params.append('alertRenew', alertRenew);

            window.location.href = '/InforItem?' + params.toString();
        });
    });

    document.getElementById('searchCategoryBtn')?.addEventListener('click', function () {
        document.getElementById('searchCategoryPopup').style.display = 'flex';
    });
    document.getElementById('closeSearchCategoryPopup')?.addEventListener('click', function () {
        document.getElementById('searchCategoryPopup').style.display = 'none';
    });

    // update
    document.querySelectorAll('.update-button').forEach(btn => {
        btn.addEventListener('click', function () {
            document.getElementById('updateIdCategory').value = btn.getAttribute('data-idcategory') || '';
            document.getElementById('updateModelName').value = btn.getAttribute('data-name') || '';
            document.getElementById('updateMaintanceCycle').value = btn.getAttribute('data-maintancecycle') || '';
            document.getElementById('updateDuration').value = btn.getAttribute('data-duration') || '';
            document.getElementById('updateAlertMaintance').value = btn.getAttribute('data-alertmaintance') || '';
            document.getElementById('updateAlertRenew').value = btn.getAttribute('data-alertrenew') || '';

            fetch('/InforItem/GetAllRealCategories')
                .then(res => res.json())
                .then(categories => {
                    const select = document.getElementById('updateRealCategorySelect');
                    select.innerHTML = '';
                    categories.forEach(cat => {
                        const opt = document.createElement('option');
                        opt.value = cat.idRealCategory;
                        opt.textContent = cat.name;
                        select.appendChild(opt);
                    });
                    // Thêm option Other
                    const otherOpt = document.createElement('option');
                    otherOpt.value = 'other';
                    otherOpt.textContent = 'Other...';
                    select.appendChild(otherOpt);

                    // Set selected value
                    select.value = btn.getAttribute('data-idrealcategory') || '';
                });

            document.getElementById('updateRealCategoryOther').style.display = 'none';
            document.getElementById('updateRealCategoryOther').value = '';

            document.getElementById('updatePopup').style.display = 'flex';
        });
    });

    // Xử lý submit form cập nhật
    document.getElementById('updateForm')?.addEventListener('submit', function (e) {
        e.preventDefault();
        const form = this;
        const formData = new FormData(form);

        const realCategorySelect = document.getElementById('updateRealCategorySelect');
        if (realCategorySelect.value === 'other') {
            formData.set('idRealCategory', '');
            formData.set('NewRealCategory', document.getElementById('updateRealCategoryOther').value);
        } else {
            formData.set('idRealCategory', realCategorySelect.value);
            formData.set('NewRealCategory', '');
        }

        fetch('/InforItem/Update', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message || 'Cập nhật thành công!');
                location.reload();
            })
            .catch(() => alert('Không thể kết nối server!'));
    });

    document.getElementById('closePopup')?.addEventListener('click', function () {
        document.getElementById('updatePopup').style.display = 'none';
    });
});