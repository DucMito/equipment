﻿function showDetail(idItem) {
    window.location.href = `/ManagerDevice/Detail/${idItem}`;
}

function bindPaginationEvents() {
    document.querySelectorAll('.page-btn[data-page]').forEach(function (el) {
        el.onclick = function (e) {
            e.preventDefault();
            if (this.disabled || this.classList.contains('active')) return;
            const page = this.getAttribute('data-page');
            if (page) {
                const url = new URL(window.location.href);
                url.searchParams.set('pageNumber', page);
                window.location.href = url.toString();
            }
        };
    });
}

function bindActionButtons() {
    document.querySelectorAll('.btn-toggle-status').forEach(btn => {
        btn.onclick = function () {
            if (!confirm("Bạn có chắc muốn chuyển trạng thái thiết bị này?")) return;
            const id = this.getAttribute('data-id');
            fetch(`/ManagerDevice/ToggleStatus/${id}`, { method: 'POST' })
                .then(res => {
                    if (!res.ok) throw new Error("Lỗi server");
                    return res.json();
                })
                .then(data => {
                    const statusCell = document.getElementById('status-' + id);
                    if (statusCell && data.status) {
                        statusCell.innerHTML = `<span class="status-${data.status.toLowerCase().replace(/ /g, "_")}">${data.status}</span>`;
                    } else {
                        alert("Chuyển trạng thái thất bại!");
                    }
                })
                .catch(() => alert("Không thể kết nối server hoặc lỗi server!"));
        };
    });


    document.querySelectorAll('.btn-update-device').forEach(btn => {
        btn.onclick = function () {
            const id = this.getAttribute('data-id');
            fetch(`/ManagerDevice/GetItemDetailJson?id=${id}`)
                .then(res => res.json())
                .then(data => {
                    document.getElementById('update_idItem').value = data.idItem;
                    document.getElementById('update_ItemName').value = data.itemName || '';
                    document.getElementById('update_status').value = data.status || '';
                    document.getElementById('update_activedDate').value = data.activedDate ? data.activedDate.substring(0, 10) : '';
                    document.getElementById('update_maintanceDate').value = data.maintanceDate ? data.maintanceDate.substring(0, 10) : '';
                    document.getElementById('update_renewDate').value = data.renewDate ? data.renewDate.substring(0, 10) : '';
                    document.getElementById('update_serialNumber').value = data.serialNumber || '';
                    document.getElementById('update_supplier').value = data.supplier || '';
                    document.getElementById('update_contractor').value = data.contractor || '';
                    document.getElementById('update_idCategory').value = data.idCategory || '';
                    document.getElementById('update_realCategoryName').value = data.realCategoryName || '';
                    document.getElementById('update_comment').value = data.comment || '';

                    // Set warehouse và load area tương ứng
                    const warehouseSelect = document.getElementById('update_warehouse');
                    const areaSelect = document.getElementById('update_idArea');
                    warehouseSelect.value = data.idWarehouse || '';
                    areaSelect.innerHTML = '<option value="">-- Chọn khu vực --</option>';
                    if (data.idWarehouse) {
                        fetch(`/ManagerDevice/GetAreasByWarehouse?idWarehouse=${data.idWarehouse}`)
                            .then(res => res.json())
                            .then(areas => {
                                areas.forEach(area => {
                                    const opt = document.createElement('option');
                                    opt.value = area.idArea;
                                    opt.textContent = area.name;
                                    areaSelect.appendChild(opt);
                                });
                                areaSelect.value = data.idArea || '';
                            });
                    }

                    document.getElementById('updateDeviceModal').style.display = 'block';
                });
        };
    });


    document.getElementById('closeUpdateModal').onclick = function () {
        document.getElementById('updateDeviceModal').style.display = 'none';
    };


    document.getElementById('update_image').onchange = function (e) {
        const [file] = e.target.files;
        if (file) {
            document.getElementById('preview_image').src = URL.createObjectURL(file);
        }
    };

    document.getElementById('updateDeviceForm').onsubmit = async function (e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);

        const res = await fetch('/ManagerDevice/UpdateDevice', {
            method: 'POST',
            body: formData
        });
        const result = await res.json();
        alert(result.message);
        if (result.success) location.reload();
    };


    document.querySelectorAll('.btn-delete-device').forEach(btn => {
        btn.onclick = async function () {
            if (!confirm('Bạn có chắc muốn xóa thiết bị này?')) return;
            const id = this.getAttribute('data-id');
            const res = await fetch(`/ManagerDevice/DeleteDevice/${id}`, { method: 'POST' });
            if (res.ok) {
                alert('Đã xóa thành công!');
                location.reload();
            } else {
                alert('Xóa thất bại!');
            }
        };
    });


    document.querySelectorAll('.btn-detail').forEach(btn => {
        btn.onclick = function () {
            const id = this.getAttribute('data-id');
            showDetail(id);
        };
    });
}

function trimFormInputs() {
    document.getElementById('filterLocation').value = document.getElementById('filterLocation').value.trim();
    document.getElementById('filterSerialNumber').value = document.getElementById('filterSerialNumber').value.trim();
    document.getElementById('filterSupplier').value = document.getElementById('filterSupplier').value.trim();
    document.getElementById('filterContractor').value = document.getElementById('filterContractor').value.trim();
}

document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM Content Loaded');
    
    const modelSelect = document.getElementById('filterDeviceName');
    if (modelSelect) {
        window.originalCategories = [];
        const options = modelSelect.querySelectorAll('option:not(:first-child)');
        options.forEach(option => {
            window.originalCategories.push({
                name: option.value,
                text: option.textContent
            });
        });
        console.log('Stored original categories:', window.originalCategories.length);
    }
    
    bindPaginationEvents();
    bindActionButtons();

    const urlParams = new URLSearchParams(window.location.search);
    const hasFilters = urlParams.has('filterDeviceName') || 
                      urlParams.has('filterRealCategory') || 
                      urlParams.has('filterLocation') || 
                      urlParams.has('filterSerialNumber') || 
                      urlParams.has('filterSupplier') || 
                      urlParams.has('filterContractor');
    
    if (hasFilters) {
        document.getElementById('deviceFilterForm').style.display = 'flex';
    }

    document.getElementById('showFilterForm').addEventListener('click', function () {
        document.getElementById('deviceFilterForm').style.display = 'flex';
    });
    document.getElementById('hideFilterForm').addEventListener('click', function () {
        document.getElementById('deviceFilterForm').style.display = 'none';
    });

    document.getElementById('clearFilterForm').addEventListener('click', function () {
        console.log('Clearing filter form...');

        document.getElementById('filterDeviceName').value = '';
        document.getElementById('filterLocation').value = '';
        document.getElementById('filterSerialNumber').value = '';
        document.getElementById('filterSupplier').value = '';
        document.getElementById('filterContractor').value = '';
        document.getElementById('filterRealCategory').value = '';
        document.getElementById('filterType').value = '';
        if (window.jQuery) {
            $('#filterDeviceName').val('').trigger('change');
            $('#filterRealCategory').val('').trigger('change');
        }
        const modelSelect = document.getElementById('filterDeviceName');
        
        if (window.originalCategories) {
            const firstOption = modelSelect.querySelector('option:first-child');
            modelSelect.innerHTML = '';
            if (firstOption) {
                modelSelect.appendChild(firstOption);
            }
            window.originalCategories.forEach(category => {
                const option = new Option(category.name, category.name, false, false);
                modelSelect.appendChild(option);
            });
            
            if (window.jQuery) {
                $('#filterDeviceName').trigger('change');
            }
        }

        console.log('Filter form cleared successfully (no page reload)');
    });

  
    document.getElementById('update_warehouse').addEventListener('change', function () {
        const idWarehouse = this.value;
        const areaSelect = document.getElementById('update_idArea');
        areaSelect.innerHTML = '<option value="">-- Chọn khu vực --</option>';
        if (!idWarehouse) return;
        fetch(`/ManagerDevice/GetAreasByWarehouse?idWarehouse=${idWarehouse}`)
            .then(res => res.json())
            .then(areas => {
                areas.forEach(area => {
                    const opt = document.createElement('option');
                    opt.value = area.idArea;
                    opt.textContent = area.name;
                    areaSelect.appendChild(opt);
                });
            });
    });


    document.getElementById('closeUpdateModal').onclick = function () {
        document.getElementById('updateDeviceModal').style.display = 'none';
    };


    document.getElementById('updateDeviceForm').onsubmit = async function (e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);

        if (!formData.get('warehouse')) {
            formData.delete('warehouse');
        }

        if (!formData.get('idArea')) {
            formData.set('idArea', '');
        }

        try {
            const res = await fetch('/ManagerDevice/UpdateDevice', {
                method: 'POST',
                body: formData
            });
            const result = await res.json();
            alert(result.message);
            if (result.success) location.reload();
        } catch (error) {
            alert('Có lỗi xảy ra khi cập nhật!');
            console.error('Error:', error);
        }
    };


    document.querySelectorAll('.filter-btn[data-status]').forEach(btn => {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.filter-btn[data-status]').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const status = this.getAttribute('data-status');
            const url = new URL(window.location.href);
            url.searchParams.delete('filterDeviceName');
            url.searchParams.delete('filterLocation');
            url.searchParams.delete('filterSerialNumber');
            url.searchParams.delete('filterSupplier');
            url.searchParams.delete('filterContractor');
            url.searchParams.delete('filterRealCategory');
            url.searchParams.delete('filterType');


            if (status) {
                url.searchParams.set('status', status);
            } else {
                url.searchParams.delete('status');
            }
            url.searchParams.set('pageNumber', 1);
            window.location.href = url.toString();
        });
    });

    document.querySelectorAll('.btn-maintenance').forEach(btn => {
        btn.onclick = function () {
            const id = this.getAttribute('data-id');
            document.getElementById('maint_idItem').value = id;
            document.getElementById('maint_date').value = new Date().toISOString().slice(0, 10);
            document.getElementById('maint_extend').value = 0;
            ['maint_status', 'maint_reason', 'maint_budgetEstimate', 'maint_type', 'maint_image', 'maint_reasonManager'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
            document.getElementById('maint_status').value = 'Đang bảo dưỡng';
            document.getElementById('maintenanceModal').style.display = 'block';
        };
    });

    // Gán sự kiện cho nút đóng modal bảo dưỡng
    var closeBtn = document.getElementById('closeMaintenanceModal');
    if (closeBtn) {
        closeBtn.onclick = function () {
            document.getElementById('maintenanceModal').style.display = 'none';
        };
    }

    // Gán sự kiện submit cho form bảo dưỡng
    var maintForm = document.getElementById('maintenanceForm');
    if (maintForm) {
        maintForm.onsubmit = async function (e) {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);

            ['status', 'reason', 'type', 'reasonManager'].forEach(field => {
                if (!formData.get(field) || formData.get(field).trim() === '') {
                    formData.set(field, 'No data');
                }
            });
            if (!formData.get('extend')) formData.set('extend', 0);
            const res = await fetch('/ManagerDevice/CreateMaintanceRequest', {
                method: 'POST',
                body: formData
            });
            const result = await res.json();
            alert(result.message);
            if (result.success) location.reload();
        };
    }

    initializeSelect2AndFiltering();
});
function initializeSelect2AndFiltering() {
    // Wait for jQuery and Select2 to be ready
    if (typeof window.jQuery === 'undefined') {
        console.log('jQuery not loaded yet, retrying...');
        setTimeout(initializeSelect2AndFiltering, 100);
        return;
    }

    const $ = window.jQuery;

    // Initialize Select2 for model dropdown
    if ($('.select2-model').length) {
        $('.select2-model').select2({
            placeholder: "Chọn hoặc tìm model...",
            allowClear: true,
            width: 'resolve'
        });
        console.log('Select2 initialized for model dropdown');
    }

    // Initialize Select2 for real category dropdown
    if ($('.select2-realcategory').length) {
        $('.select2-realcategory').select2({
            placeholder: "Chọn loại thiết bị...",
            allowClear: true,
            width: 'resolve'
        });
        console.log('Select2 initialized for real category dropdown');
    }

    // ===== SETUP DYNAMIC FILTERING AFTER SELECT2 IS READY =====
    setTimeout(() => {
        setupDynamicFiltering();
        console.log('Dynamic filtering setup completed');
        
        // ===== RESTORE SELECTED VALUES FROM URL =====
        restoreFilterValuesFromURL();
    }, 300);
}

// ===== NEW FUNCTION: RESTORE FILTER VALUES FROM URL =====
function restoreFilterValuesFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Restore Model selection
    const filterDeviceName = urlParams.get('filterDeviceName');
    if (filterDeviceName) {
        $('#filterDeviceName').val(filterDeviceName).trigger('change');
        console.log('Restored Model filter:', filterDeviceName);
    }
    
    // Restore RealCategory selection
    const filterRealCategory = urlParams.get('filterRealCategory');
    if (filterRealCategory) {
        $('#filterRealCategory').val(filterRealCategory).trigger('change');
        console.log('Restored RealCategory filter:', filterRealCategory);
    }
    
    // Restore other text inputs
    const filterLocation = urlParams.get('filterLocation');
    if (filterLocation) {
        document.getElementById('filterLocation').value = filterLocation;
    }
    
    const filterSerialNumber = urlParams.get('filterSerialNumber');
    if (filterSerialNumber) {
        document.getElementById('filterSerialNumber').value = filterSerialNumber;
    }
    
    const filterSupplier = urlParams.get('filterSupplier');
    if (filterSupplier) {
        document.getElementById('filterSupplier').value = filterSupplier;
    }
    
    const filterContractor = urlParams.get('filterContractor');
    if (filterContractor) {
        document.getElementById('filterContractor').value = filterContractor;
    }
    
    const filterType = urlParams.get('filterType');
    if (filterType) {
        document.getElementById('filterType').value = filterType;
    }
}

// ===== DYNAMIC FILTERING FUNCTIONS - SAME AS BEFORE =====
function setupDynamicFiltering() {
    console.log('Setting up dynamic filtering...');
    
    // Remove existing event listeners to prevent duplicates
    $('#filterDeviceName').off('change.dynamicFilter');
    $('#filterRealCategory').off('change.dynamicFilter');
    
    // Add event listeners with namespace to prevent duplicates
    $('#filterDeviceName').on('change.dynamicFilter', function () {
        const selectedCategoryName = this.value;
        console.log('Model changed to:', selectedCategoryName);

        if (selectedCategoryName) {
            updateRealCategoryFromModel(selectedCategoryName);
        } else {
            // Prevent infinite loop - temporarily remove event listener
            $('#filterRealCategory').off('change.dynamicFilter');
            $('#filterRealCategory').val('').trigger('change');
            // Re-add event listener
            setTimeout(() => setupRealCategoryListener(), 100);
        }
    });

    setupRealCategoryListener();
}

function setupRealCategoryListener() {
    $('#filterRealCategory').off('change.dynamicFilter');
    $('#filterRealCategory').on('change.dynamicFilter', function () {
        const selectedRealCategoryId = this.value;
        console.log('RealCategory changed to:', selectedRealCategoryId);

        // Prevent update if this change was triggered by Model selection
        if ($(this).data('skipTrigger')) {
            $(this).removeData('skipTrigger');
            return;
        }

        if (selectedRealCategoryId) {
            updateModelsFromRealCategory(selectedRealCategoryId);
        } else {
            resetModelDropdown();
        }
    });
}

function updateRealCategoryFromModel(categoryName) {
    console.log('Fetching RealCategory for model:', categoryName);

    fetch(`/ManagerDevice/GetRealCategoryByCategory?categoryName=${encodeURIComponent(categoryName)}`)
        .then(res => res.json())
        .then(realCategory => {
            console.log('Got RealCategory:', realCategory);

            if (realCategory) {
                // Set flag to prevent triggering Model update
                $('#filterRealCategory').data('skipTrigger', true);
                $('#filterRealCategory').val(realCategory.idRealCategory).trigger('change');
            } else {
                $('#filterRealCategory').data('skipTrigger', true);
                $('#filterRealCategory').val('').trigger('change');
            }
        })
        .catch(err => {
            console.error('Error fetching real category:', err);
            $('#filterRealCategory').data('skipTrigger', true);
            $('#filterRealCategory').val('').trigger('change');
        });
}

function updateModelsFromRealCategory(idRealCategory) {
    console.log('Fetching Categories for RealCategory:', idRealCategory);

    fetch(`/ManagerDevice/GetCategoriesByRealCategory?idRealCategory=${idRealCategory}`)
        .then(res => res.json())
        .then(categories => {
            console.log('Got Categories:', categories);

            const modelSelect = $('#filterDeviceName');
            const currentValue = modelSelect.val();

            // Temporarily remove event listener to prevent triggering
            modelSelect.off('change.dynamicFilter');

            // Clear current options except "Tất cả"
            modelSelect.find('option:not(:first)').remove();

            // Add filtered categories
            categories.forEach(category => {
                const option = new Option(category.name, category.name, false, false);
                modelSelect.append(option);
            });

            // If the previously selected value is still available, keep it selected
            if (categories.some(cat => cat.name === currentValue)) {
                modelSelect.val(currentValue);
            } else {
                modelSelect.val('');
            }

            // Trigger Select2 refresh
            modelSelect.trigger('change');
            
            // Re-add event listener
            setTimeout(() => {
                setupModelListener();
            }, 100);
        })
        .catch(err => {
            console.error('Error fetching categories:', err);
        });
}

function setupModelListener() {
    $('#filterDeviceName').off('change.dynamicFilter');
    $('#filterDeviceName').on('change.dynamicFilter', function () {
        const selectedCategoryName = this.value;
        console.log('Model changed to (after filter):', selectedCategoryName);

        if (selectedCategoryName) {
            updateRealCategoryFromModel(selectedCategoryName);
        } else {
            $('#filterRealCategory').data('skipTrigger', true);
            $('#filterRealCategory').val('').trigger('change');
        }
    });
}

function resetModelDropdown() {
    console.log('Resetting model dropdown');

    const modelSelect = $('#filterDeviceName');
    const currentValue = modelSelect.val();

    const url = new URL(window.location.href);
    url.searchParams.delete('filterRealCategory');
    if (!currentValue) {
        url.searchParams.delete('filterDeviceName');
    }
    window.location.href = url.toString();
}

function filterTableByStatus(status) {
    const rows = document.querySelectorAll('.device-table tbody tr');
    rows.forEach(row => {
        const statusCell = row.querySelector('td[id^="status-"] span');
        if (!status || !statusCell || statusCell.textContent.trim() === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

$('#filterDeviceName').on('select2:clear', function () {
    // Chỉ xóa giá trị, không reload, không submit
    $('#filterDeviceName').val('').trigger('change.select2');
});

$('#filterRealCategory').on('select2:clear', function () {
    $('#filterRealCategory').val('').trigger('change.select2');
});
