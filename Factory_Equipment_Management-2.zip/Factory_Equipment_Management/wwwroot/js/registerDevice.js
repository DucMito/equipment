﻿document.addEventListener("DOMContentLoaded", function () {

    if (window.jQuery) {
        $('#add_category').select2({
            width: '100%',
            placeholder: "-- Chọn tên thiết bị --",
            allowClear: true
        });
    }

    if (window.jQuery) {
        $('#add_realCategory').select2({
            width: '100%',
            placeholder: "-- Chọn loại thiết bị --",
            allowClear: true
        });
    }

    var btnAddDevice = document.getElementById('btnAddDevice');
    var addDeviceModal = document.getElementById('addDeviceModal');
    var closeAddDeviceModal = document.getElementById('closeAddDeviceModal');

    if (btnAddDevice && addDeviceModal && closeAddDeviceModal) {
        btnAddDevice.onclick = function () {
            document.body.classList.add('modal-open');
            addDeviceModal.style.display = 'flex';

            var form = document.getElementById('addDeviceForm');
            if (form) form.reset();

            var imagePreview = document.getElementById('add_image_preview');
            if (imagePreview) imagePreview.src = '';
            var imageInput = document.getElementById('add_image');
            if (imageInput) imageInput.value = '';
            var typeInput = document.getElementById('add_type');
            if (typeInput) typeInput.value = '';
            var dangKiemInput = document.getElementById('add_dangKiem');
            if (dangKiemInput) dangKiemInput.value = '';
            var contractorInput = document.getElementById('add_contractor');
            if (contractorInput) contractorInput.value = '';
            var serialNumberInput = document.getElementById('add_serialNumber');
            if (serialNumberInput) serialNumberInput.value = '';
            var supplierInput = document.getElementById('add_supplier');
            if (supplierInput) supplierInput.value = '';

            if (window.jQuery) {
                $('#add_category').val('').trigger('change');
            }
        };
        closeAddDeviceModal.onclick = function () {
            document.body.classList.remove('modal-open');
            addDeviceModal.style.display = 'none';
        };
        window.onclick = function (event) {
            if (event.target === addDeviceModal) {
                addDeviceModal.style.display = 'none';
            }
        };
    }

    // Hiển thị alert khi thêm thiết bị thành công/thất bại
    var alertMsg = document.getElementById('alert-message-data');
    if (alertMsg && alertMsg.value) {
        alert(alertMsg.value);
    }

    if (window.jQuery) {
        $('#add_category').on('change', async function () {
            const categoryId = $(this).val();
            const realCategoryInput = document.getElementById('add_realCategory');
            const idRealCategoryInput = document.getElementById('add_idRealCategory');
            const maintainceCycleInput = document.getElementById('add_maintainceCycle');
            const renewCycleInput = document.getElementById('add_renewCycle');
            const alertMaintainceInput = document.getElementById('add_alertMaintaince');
            const alertRenewInput = document.getElementById('add_alertRenew');
            const durationInput = document.getElementById('add_duration');
            const imagePreview = document.getElementById('add_image_preview');
            const typeInput = document.getElementById('add_type');
            const dangKiemInput = document.getElementById('add_dangKiem');

            if (!categoryId) {
                // Xóa dữ liệu nếu chưa chọn
                if (realCategoryInput) realCategoryInput.value = '';
                if (idRealCategoryInput) idRealCategoryInput.value = '';
                if (maintainceCycleInput) maintainceCycleInput.value = '';
                if (renewCycleInput) renewCycleInput.value = '';
                if (alertMaintainceInput) alertMaintainceInput.value = '';
                if (alertRenewInput) alertRenewInput.value = '';
                if (durationInput) durationInput.value = '';
                if (imagePreview) imagePreview.src = '';
                if (typeInput) typeInput.value = '';
                if (dangKiemInput) dangKiemInput.value = '';
                return;
            }
            try {
                const res = await fetch(`/RegisterDevice/GetCategoryInfo?categoryId=${categoryId}`);
                if (!res.ok) {
                    alert('Không lấy được thông tin thiết bị!');
                    return;
                }
                const data = await res.json();
                if (realCategoryInput) realCategoryInput.value = data.realCategoryName || '';
                if (idRealCategoryInput) idRealCategoryInput.value = data.idrealCategory || '';
                if (maintainceCycleInput) maintainceCycleInput.value = data.maintanceCycle || '';
                if (renewCycleInput) renewCycleInput.value = data.renewCycle || data.duration || '';
                if (alertMaintainceInput) alertMaintainceInput.value = data.alertMaintance || '';
                if (alertRenewInput) alertRenewInput.value = data.alertRenew || '';
                if (durationInput) durationInput.value = data.duration || '';
                // Xử lý ảnh hex sang base64 để preview
                if (imagePreview) {
                    if (data.image && data.image !== "No data") {
                        function hexToBase64(hex) {
                            if (!hex) return "";
                            const bytes = [];
                            for (let c = 0; c < hex.length; c += 2)
                                bytes.push(parseInt(hex.substr(c, 2), 16));
                            return "data:image/png;base64," + btoa(String.fromCharCode.apply(null, bytes));
                        }
                        imagePreview.src = hexToBase64(data.image);
                    } else {
                        imagePreview.src = "";
                    }
                }
                if (typeInput) typeInput.value = data.type === 1 ? "Tài sản cố định" : (data.type === 0 ? "Tài sản log" : "");
                if (dangKiemInput) dangKiemInput.value = data.dangKiem ? data.dangKiem.substring(0, 10) : '';
            } catch (e) {
                alert('Lỗi khi lấy thông tin thiết bị!');
            }
        });

        // Khi chọn Loại thiết bị, load lại danh sách Tên thiết bị
        $('#add_realCategory').on('change', async function () {
            var realCategoryId = $(this).val();
            var $categorySelect = $('#add_category');
            $categorySelect.empty().append('<option value="">-- Chọn tên thiết bị --</option>');
            if (!realCategoryId) {
                $categorySelect.val('').trigger('change');
                return;
            }
            try {
                const res = await fetch(`/RegisterDevice/GetCategoriesByRealCategory?realCategoryId=${realCategoryId}`);
                if (!res.ok) return;
                const data = await res.json();
                data.forEach(function (item) {
                    $categorySelect.append(`<option value="${item.idCategory}">${item.name}</option>`);
                });
                $categorySelect.val('').trigger('change');
            } catch (e) {
                alert('Không lấy được danh sách tên thiết bị!');
            }
        });
    }
    var addDeviceForm = document.getElementById('addDeviceForm');
    if (addDeviceForm) {
        addDeviceForm.addEventListener('submit', function (e) {
            e.preventDefault();

            var formData = new FormData(addDeviceForm);

            // Lấy file ảnh (nếu có)
            var imageInput = document.getElementById('add_image');
            if (imageInput && imageInput.files && imageInput.files.length > 0) {
                formData.set('Image', imageInput.files[0]);
            }

            // Lấy ngày đăng kiểm (nếu có)
            var dangKiemInput = document.getElementById('add_dangKiem');
            if (dangKiemInput && dangKiemInput.value) {
                formData.set('DangKiemDate', dangKiemInput.value);
            }

            // Lấy contractor, serialNumber, supplier
            var contractorInput = document.getElementById('add_contractor');
            if (contractorInput) {
                formData.set('Contractor', contractorInput.value);
            }
            var serialNumberInput = document.getElementById('add_serialNumber');
            if (serialNumberInput) {
                formData.set('SerialNumber', serialNumberInput.value);
            }
            var supplierInput = document.getElementById('add_supplier');
            if (supplierInput) {
                formData.set('Supplier', supplierInput.value);
            }

            fetch('/RegisterDevice/Create', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(res => res.json())
                .then(data => {
                    alert(data.message);
                    if (data.success) {
                        window.location.reload();
                    }
                })
                .catch(() => alert('Không thể kết nối server!'));
        });
    }
});