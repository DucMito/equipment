﻿namespace Factory_Equipment_Management.ViewModel
{
    public class InforItemViewModel
    {
        // Category
        public int? IdCategory { get; set; }
        public string Name { get; set; }
        public float? MaintanceCycle { get; set; }
        public float? Duration { get; set; }
        public double? AlertMaintance { get; set; }
        public double? AlertRenew { get; set; }

        // RealCategory
        public int idRealCategory { get; set; }
        public string nameRealCategory { get; set; }
        public string NewRealCategory { get; set; } // Dùng khi thêm mới RealCategory

        // Các trường hỗ trợ UI (nếu cần)
        // (Không còn trường nào của Item)
    }
}