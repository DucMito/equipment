﻿namespace Factory_Equipment_Management.ViewModel
{
    public class RegisterDeviceRequestModel
    {
        public int idRegisterDeviceRequest { get; set; }
        public DateTime date { get; set; }
        public string status { get; set; }
    }

    public class RegisterDeviceViewModel
    {
        public List<RegisterDeviceListItemViewModel> DeviceList { get; set; }  // Thêm dòng này

        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}