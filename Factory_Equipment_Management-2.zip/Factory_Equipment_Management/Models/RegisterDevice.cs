﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Factory_Equipment_Management.Models
{
    public class RegisterDevice
    {
        public int idRegisterDevice { get; set; }
        public int idCategory { get; set; }
        public string name { get; set; }
        public int num { get; set; }
        public string image { get; set; }
        public int idRegisterDeviceRequest { get; set; }
        public int maintanceCycle { get; set; }
        public int renewCycle { get; set; }
        public string po { get; set; }
        public int alertMaintance { get; set; }
        public int alertRenew { get; set; }
        public DateTime? dangKiem { get; set; }
        public bool type { get; set; }
        public int idRealCategory { get; set; }
        public string realCategoryName { get; set; }

        // Navigation property: Thiết bị thuộc về một yêu cầu đăng ký
        [ForeignKey("idRegisterDeviceRequest")]
        public RegisterDeviceRequest RegisterDeviceRequest { get; set; }

        public RegisterDevice() { }

        public RegisterDevice(int idRegisterDevice, int idCategory, string name, int num, string image, int idRegisterDeviceRequest,
            int maintanceCycle, int renewCycle, string po, int alertMaintance, int alertRenew, DateTime? dangKiem, bool type,
            int idRealCategory, string realCategoryName)
        {
            this.idRegisterDevice = idRegisterDevice;
            this.idCategory = idCategory;
            this.name = name;
            this.num = num;
            this.image = image;
            this.idRegisterDeviceRequest = idRegisterDeviceRequest;
            this.maintanceCycle = maintanceCycle;
            this.renewCycle = renewCycle;
            this.po = po;
            this.alertMaintance = alertMaintance;
            this.alertRenew = alertRenew;
            this.dangKiem = dangKiem;
            this.type = type;
            this.idRealCategory = idRealCategory;
            this.realCategoryName = realCategoryName;
        }
    }
}