﻿namespace Factory_Equipment_Management.Models
{
    public class TranferHistory
    {
        public int idTranferHistory { get; set; }
        public int? sender { get; set; }
        public int? receiver { get; set; }
        public DateTime date { get; set; }
        public int idTranferRequest { get; set; }
        public string senderType { get; set; }
        public string receiverType { get; set; }

        public TranferHistory() { }

        public TranferHistory(int idTranferHistory, int? sender, int? receiver, DateTime date, int idTranferRequest, string senderType, string receiverType)
        {
            this.idTranferHistory = idTranferHistory;
            this.sender = sender;
            this.receiver = receiver;
            this.date = date;
            this.idTranferRequest = idTranferRequest;
            this.senderType = senderType;
            this.receiverType = receiverType;
        }

    }
}
