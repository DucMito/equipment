﻿namespace Factory_Equipment_Management.Models
{
    public class Category
    {
        public int idCategory { get; set; }
        public string name { get; set; }
        public int idrealCategory { get; set; }

        // Thêm 2 trường alertMaintance và alertRenew
        public double? alertMaintance { get; set; }
        public double? alertRenew { get; set; }

        public float duration { get; set; }
        public float maintanceCycle { get; set; }



    }
}
