﻿using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace Factory_Equipment_Management.Models
{
    public class YourDbContext : DbContext
    {
        public YourDbContext(DbContextOptions<YourDbContext> options) : base(options) { }

        public DbSet<Manager> Managers { get; set; }
        public DbSet<PIC> PICs { get; set; }
        public DbSet<Staff> Staffs { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<RealCategory> RealCategories { get; set; }
        public DbSet<Warehouse> Warehouses { get; set; }
        public DbSet<Area> Areas { get; set; }
        public DbSet<Token> Tokens { get; set; }
        public DbSet<TranferRequest> TranferRequests { get; set; }
        public DbSet<TranferRequestDetail> TranferRequestDetails { get; set; }
        public DbSet<TranferHistory> TranferHistories { get; set; }
        public DbSet<MaintanceRequest> MaintanceRequests { get; set; }
        public DbSet<MaintanceHistory> MaintanceHistories { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<NonActiveEverItem> NonActiveEverItems { get; set; }
        public DbSet<Sessions> Sessions { get; set; }
        public DbSet<RegisterDevice> RegisterDevices { get; set; }
        public DbSet<RegisterDeviceRequest> RegisterDeviceRequests { get; set; }

        // Thêm các DbSet khác nếu cần




        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Manager>().ToTable("manager").HasKey(m => m.idManager);
            modelBuilder.Entity<Staff>().ToTable("staff").HasKey(s => s.idStaff);
            modelBuilder.Entity<PIC>().ToTable("pic").HasKey(p => p.idPIC);
            modelBuilder.Entity<Category>().ToTable("category").HasKey(c => c.idCategory);
            modelBuilder.Entity<RealCategory>().ToTable("realcategory").HasKey(rc => rc.idRealCategory);
            modelBuilder.Entity<Warehouse>().ToTable("warehouse").HasKey(w => w.idWarehouse);
            modelBuilder.Entity<Area>().ToTable("area").HasKey(a => a.idArea);
            modelBuilder.Entity<Token>().ToTable("token").HasKey(t => t.id);
            modelBuilder.Entity<TranferRequest>().ToTable("tranferrequest").HasKey(tr => tr.idTranferRequest);
            modelBuilder.Entity<TranferRequestDetail>().ToTable("tranferrequestdetail").HasKey(trd => trd.idTranferRequestDetail);
            modelBuilder.Entity<TranferHistory>().ToTable("tranferhistory").HasKey(th => th.idTranferHistory);
            modelBuilder.Entity<MaintanceRequest>().ToTable("maintancerequest").HasKey(mr => mr.idMaintanceRequest);
            modelBuilder.Entity<MaintanceHistory>().ToTable("maintancehistory").HasKey(mh => mh.idMaintanceHistory);
            modelBuilder.Entity<Item>().ToTable("item").HasKey(i => i.idItem);
            modelBuilder.Entity<NonActiveEverItem>().ToTable("nonactive_ever_item").HasKey(n => n.idNonActive_ever_item);
            modelBuilder.Entity<Sessions>().ToTable("sessions").HasKey(s => s.sid);
           
            modelBuilder.Entity<CheckHistory>().ToTable("checkhistory").HasKey(ch => ch.idCheck);
            modelBuilder.Entity<Category>().Property(c => c.maintanceCycle).HasColumnName("maintaneceCycle"); // Đảm bảo tên cột khớp với cơ sở dữ liệu
            modelBuilder.Entity<Item>().Property(i => i.idCategory).IsRequired(false);

            modelBuilder.Entity<RegisterDeviceRequest>().ToTable("registerdevicerequest").HasKey(rdr => rdr.idRegisterDeviceRequest);
            modelBuilder.Entity<RegisterDevice>().ToTable("registerdevice").HasKey(rd => rd.idRegisterDevice);
            modelBuilder.Entity<RegisterDeviceRequest>().ToTable("registerdevicerequest").HasKey(rdr => rdr.idRegisterDeviceRequest);

            modelBuilder.Entity<RegisterDevice>().Property(rd => rd.idRealCategory).HasColumnName("idRealCategory");
            modelBuilder.Entity<RegisterDevice>().Property(rd => rd.realCategoryName).HasColumnName("realCategoryName");
        }
        // Thêm các cấu hình quan hệ nếu cần
    }
}