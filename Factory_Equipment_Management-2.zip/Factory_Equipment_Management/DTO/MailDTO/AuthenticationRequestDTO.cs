namespace Factory_Equipment_Management.DTO.MailDTO
{
    public class AuthenticationRequestDTO
    {
        public string UserName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}