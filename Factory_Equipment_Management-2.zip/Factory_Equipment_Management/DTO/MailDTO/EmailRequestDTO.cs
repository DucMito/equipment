namespace Factory_Equipment_Management.DTO.MailDTO
{
    public class EmailRequestDTO
    {
        public string SystemName { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public string EmailContent { get; set; } = string.Empty;
        public List<string> SendTo { get; set; } = new List<string>();
        public List<string> Cc { get; set; } = new List<string>();
    }
}